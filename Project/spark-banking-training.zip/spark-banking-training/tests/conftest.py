"""Shared pytest fixtures for the bankjobs test suite.

session-scoped: the JVM starts ONCE for the whole test run, not once per
test. Starting a SparkSession costs several seconds, paying that cost once
instead of per test keeps `pytest tests/` fast.
"""
import os
import sys

# Make `import bankjobs` work with no PYTHONPATH set, the same trick every
# lab file uses for `import bank_session`.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "labs"))

import pytest
from pyspark.sql import SparkSession


@pytest.fixture(scope="session")
def spark():
    session = (
        SparkSession.builder
        .appName("bankjobs-tests")
        .master("local[2]")
        .config("spark.sql.shuffle.partitions", 2)   # small and fast, this fixture never touches real data volume
        .getOrCreate()
    )
    session.sparkContext.setLogLevel("ERROR")
    yield session
    session.stop()
