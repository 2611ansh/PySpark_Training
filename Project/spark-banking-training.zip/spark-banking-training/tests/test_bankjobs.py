"""Tests for the bankjobs package. See docs/15_packaging.md for why
transform() (pure) and run() (IO) are split, and why that split is what
makes these tests possible with no file on disk.
"""
import pytest

from bankjobs.config import load_config
from bankjobs.jobs.daily_kpi import ACCOUNT_SCHEMA, TXN_SCHEMA, transform


def _txn(txn_id, account_id, txn_ts, amount, status="SUCCESS"):
    """One transactions row, the columns transform() does not use are
    filled with harmless placeholders so the row matches TXN_SCHEMA."""
    return (txn_id, account_id, txn_ts, amount, "INR", "UPI", "GROCERY",
            "DEBIT", "", status, "DEV1", "Mumbai")


def _account(account_id, branch_code):
    return (account_id, "CUST1", "SAVINGS", branch_code, "2020-01-01", "ACTIVE", 1000.0, "INR")


def _build_fixture(spark):
    txns = spark.createDataFrame([
        _txn("TXN1", "ACC1", "2026-09-01 10:00:00", 100.0),
        _txn("TXN2", "ACC1", "2026-09-01 11:00:00", 50.0),
        _txn("TXN3", "ACC2", "2026-09-01 09:00:00", 200.0, status="FAILED"),   # excluded
        _txn("TXN4", "ACC2", "2026-09-02 09:00:00", 300.0),
        _txn("TXN5", "ACC1", "2026-09-01 12:00:00", 25.0),
    ], TXN_SCHEMA)
    accounts = spark.createDataFrame([
        _account("ACC1", "BR01"),
        _account("ACC2", "BR02"),
    ], ACCOUNT_SCHEMA)
    return txns, accounts


def test_transform_aggregates_per_branch_per_day(spark):
    txns, accounts = _build_fixture(spark)
    result = transform(txns, accounts).collect()

    by_key = {(r.branch_code, r.txn_date): r for r in result}
    assert (("BR01", "2026-09-01") in by_key)
    assert (("BR02", "2026-09-02") in by_key)
    assert len(result) == 2                     # only two (branch, day) groups exist


def test_transform_sums_and_counts_correctly(spark):
    txns, accounts = _build_fixture(spark)
    row = {(r.branch_code, r.txn_date): r for r in transform(txns, accounts).collect()}[("BR01", "2026-09-01")]
    assert row.txn_count == 3                   # TXN1, TXN2, TXN5
    assert row.total_amount == 175.0             # 100 + 50 + 25
    assert row.active_accounts == 1              # only ACC1


def test_transform_drops_non_success_status(spark):
    txns, accounts = _build_fixture(spark)
    result = transform(txns, accounts).collect()
    # TXN3 (FAILED, ACC2, 2026-09-01) must not appear anywhere in the output
    assert ("BR02", "2026-09-01") not in {(r.branch_code, r.txn_date) for r in result}


def test_load_config_dev_defaults():
    # No spark fixture needed here: JobConfig is plain Python, so testing
    # it needs no JVM startup at all.
    config = load_config(env="dev")
    assert config.raw_path == "data/raw"
    assert config.transactions_path() == "data/raw/transactions"


def test_load_config_explicit_argument_wins():
    config = load_config(env="dev", raw_path="/tmp/custom_raw")
    assert config.raw_path == "/tmp/custom_raw"


def test_load_config_unknown_env_raises():
    with pytest.raises(ValueError):
        load_config(env="not_a_real_env")


def test_job_config_output_path_joins_correctly():
    config = load_config(env="dev", warehouse_path="data/warehouse")
    assert config.output_path("daily_kpi") == "data/warehouse/gold/daily_kpi"
