"""AtliQ Bank pipeline: ingest -> curate -> publish.

Three tasks. You choose the date. No schedule, no catchup, no surprises.

Run it:
  1. Unpause the DAG
  2. Click the play button
  3. It runs for RUN_DATE below

To run a different day, either change RUN_DATE, or use
"Trigger DAG w/ config" and paste:   {"run_date": "2026-09-02"}

Available dates in this course: 2026-09-01, 2026-09-02, 2026-09-03
"""
from airflow import DAG
from airflow.operators.bash import BashOperator
import pendulum

# ---------------------------------------------------------------------
# EDIT THESE THREE
# ---------------------------------------------------------------------
PROJECT = "/home/hraseed/projects/pyspark-training-test/spark-banking-training"
PYTHON = "/home/hraseed/projects/pyspark-training-test/.venv/bin/python"
RUN_DATE = "2026-09-01"

# ---------------------------------------------------------------------
# Nothing below needs editing
# ---------------------------------------------------------------------
SCRIPT = f"{PROJECT}/labs/17_lab_pipeline.py"

# Use RUN_DATE above, unless a date was passed in the trigger config.
DATE = '{{ dag_run.conf.get("run_date", "' + RUN_DATE + '") }}'


def cmd(step):
    """The shell command for one step.

    A task gets a fresh shell, so we call the venv python by full path and
    set PYTHONPATH so `import bank_session` works.
    """
    return (f"PYTHONPATH={PROJECT}/src PYSPARK_PYTHON={PYTHON} "
            f"{PYTHON} {SCRIPT} --step {step} --run-date {DATE}")


with DAG(
    dag_id="bank_pipeline",
    description="ingest -> curate -> publish for one date",
    schedule=None,                                       # manual only
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),  # required, never used
    catchup=False,
    tags=["atliq-bank"],
    doc_md=__doc__,
) as dag:

    ingest = BashOperator(task_id="ingest", bash_command=cmd("ingest"))

    # curate exits non-zero if too many rows are rejected.
    # That exit code is the data quality gate, so publish is then skipped.
    curate = BashOperator(task_id="curate", bash_command=cmd("curate"))

    publish = BashOperator(task_id="publish", bash_command=cmd("publish"))

    ingest >> curate >> publish
