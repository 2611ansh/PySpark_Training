# AtliQ Bank Airflow lab

Working material for [Module 17](../docs/17_airflow_basics.md) and
[Module 18](../docs/18_airflow_lab.md). Full explanations live in those
two docs, this file is the copy-paste quickstart.

Target version: **Apache Airflow 2.10.5**, Python 3.11 or 3.12,
LocalExecutor, SQLite (swap to Postgres if more than one person shares
the install, see Module 18 section 4.1).

**Airflow was not run in the sandbox that built this course.** The DAG
is compile-checked (`python -m py_compile`) and desk-checked against the
Airflow 2.10 API, not run live. Run this quickstart on your own WSL2
machine to see it for real.

## 1. One-time setup

Run these in WSL2 Ubuntu, **not** inside the PySpark venv, and not in
Windows PowerShell.

```bash
# a SEPARATE venv from the PySpark one, see Module 18 section 1 for why
python3 -m venv ~/airflow-venv
source ~/airflow-venv/bin/activate

pip install "apache-airflow==2.10.5" \
  --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-2.10.5/constraints-3.11.txt"

export AIRFLOW_HOME=~/airflow
export AIRFLOW__CORE__DAGS_FOLDER=/path/to/spark-banking-training/airflow/dags
export AIRFLOW__CORE__LOAD_EXAMPLES=false

airflow db migrate

airflow users create \
  --username admin --password admin \
  --firstname Bank --lastname Trainee \
  --role Admin --email admin@example.com
```

Then edit the three constants at the top of `dags/bank_pipeline.py`,
`PROJECT`, `PYTHON` and `RUN_DATE`, for your own machine.

## 2. Start Airflow

```bash
export AIRFLOW_HOME=~/airflow
export AIRFLOW__CORE__DAGS_FOLDER=/path/to/spark-banking-training/airflow/dags
airflow standalone
```

Open [http://localhost:8080](http://localhost:8080) in your Windows
browser. If you skipped `users create`, the generated password is
printed near the top of the `standalone` startup log.

## 3. Run the DAG

In the UI: unpause `bank_pipeline`, then click the play button (Trigger
DAG). This runs it for whatever date `RUN_DATE` is set to.

To choose a different date without editing the file, use **Trigger DAG
w/ config** instead, and paste:

```json
{"run_date": "2026-09-02"}
```

Only `2026-09-01`, `2026-09-02` and `2026-09-03` have data. This DAG has
no schedule, `schedule=None`, so it never runs on its own, only when you
trigger it.

Watch the Grid view. Three tasks, `ingest`, `curate`, `publish`, run one
after another.

## 4. What is in this folder

| Path | What |
|---|---|
| `dags/bank_pipeline.py` | The one DAG. `BashOperator`, three tasks, the DQ gate, no schedule |

Nothing else lives under `airflow/`. The DAG calls
`labs/17_lab_pipeline.py` once per step and contains no PySpark code
itself.

## 5. Forcing the DQ gate to fail

Edit `cmd()` in `bank_pipeline.py` to append `--dq-threshold 0` for one
test run, save, and trigger the DAG again. Expected: `curate` fails,
`publish` shows SKIPPED (not FAILED), and the DAG run overall shows
FAILED. Undo the edit afterward. See Module 18 section 9 for the full
walkthrough.

## 6. Everyday commands

| Task | Command |
|---|---|
| List DAGs | `airflow dags list` |
| Check the DAG parses | `airflow dags list-import-errors` |
| Test one task without scheduling it | `airflow tasks test bank_pipeline ingest 2026-09-01` |
| Stop everything | `Ctrl+C` in the `airflow standalone` terminal |
