# Module 17: Airflow basics

After this module you can read any Airflow DAG, explain why a run's
logical date is not the moment it actually executed, and know which
operator to reach for when a bank job needs orchestrating.

## Why this matters in a bank

Every bank running batch already has a scheduler: Control-M, Autosys,
Tivoli, or a wall of cron jobs and a runbook nobody fully trusts. Moving
to Spark does not remove that need, it adds to it: more jobs, more
dependencies between them, more people who need to see what ran without
SSHing into a box at 2 AM. Airflow does not replace Spark or your
judgment about what "done" means for a business day. It replaces the
crontab, the shell script that chains five other shell scripts, and the
spreadsheet someone keeps of "which job depends on which". Get this
module right and a DAG becomes something an auditor, a new joiner and
2 AM-you can all read the same way. That is the whole point of
orchestration in a regulated environment: not speed, traceability.

This module is conceptual, about 40 minutes. There is no notebook for
it. Airflow is something you install, configure and trigger from the
command line and a browser, not something you explore cell by cell, so
unlike the notebooks under `notebooks/` that come before the `.py` labs,
there is nothing to open in a notebook here.

## 1. What Airflow is, and what it is not

| Airflow is | Airflow is not |
|---|---|
| A scheduler with dependency graphs, retries and a UI | A processing engine, like Spark or a database |
| A way to say "run C only after A and B succeed" | A place to `groupBy` or join 180,000 rows |
| A place to see the history of every run of every job | A message queue or a streaming engine |
| Python code that describes work | The thing that does the work. That is Spark, in this course |

A task in an Airflow DAG almost always tells something else to run: a
Spark job, a shell script, a SQL statement. A task that directly loads a
DataFrame inside the Airflow worker itself is close to always a mistake.
The lab DAG in module 18 only shells out to `labs/17_lab_pipeline.py`.
Airflow never touches a DataFrame.

```python
BashOperator(
    task_id="ingest",
    bash_command="python labs/17_lab_pipeline.py --step ingest --run-date 2026-09-01",
)
```

That is the entire shape of a task in this course: a thin wrapper around
a real Spark job, nothing Spark-specific inside the DAG file itself.

## 2. Airflow versus the schedulers you already run

The concepts map across almost one to one. The vocabulary does not. This
is the single most useful table in this module.

| What you call it today | Control-M / Autosys | cron | Airflow |
|---|---|---|---|
| A unit of work | Job | one crontab line | Task |
| A group of related jobs | Box / Job stream | a script calling other scripts | DAG |
| When it runs | Calendar, scheduling table | 5-field cron expression | `schedule`, a cron string, a preset, or `None` for manual only |
| "Run B only after A" | Condition, predecessor/successor | you write it into the script | `>>`, a dependency edge |
| Reprocessing a past date | Rerun / rerun-from | manual re-invocation | Backfill, or a manual trigger with a chosen date |
| "Skip today, box on hold" | Hold | comment out the crontab line | Pause the DAG |
| Where state is tracked | Control-M's own database | nowhere, usually a log file | the metadata database |
| Alerting on failure | Built-in paging | you write it yourself, or get nothing | `on_failure_callback` |
| A parameter shared across jobs | Global Variables table | environment variables | Airflow Variables, or config passed at trigger time |

The real difference worth sitting with: Control-M and Autosys are
calendar-first. You attach a job to a calendar and the scheduler works
out when to run it. Airflow is code-first. The schedule is one argument
in a Python file, and any calendar exception (month-end, a holiday) is a
branch you write, not a screen you configure. More power, more
responsibility, in the same file.

**Migrating an existing box, roughly in order:**

| Step | What to do |
|---|---|
| 1 | List every job in the box. Decide the DAG boundary first, usually one DAG per business process |
| 2 | For each job, write down what makes it safe to rerun today. Fix whatever does not, section 8, before it becomes a task |
| 3 | Reproduce calendar exceptions (month-end, holidays) as explicit Python logic, not a comment in a runbook |
| 4 | Reproduce cross-box dependencies as a dependency edge, or a sensor waiting on the other DAG |
| 5 | Wire the failure callback to the bank's real paging system before the first production DAG goes live |
| 6 | Run the new DAG alongside the old scheduler for at least one full cycle before retiring it |

## 3. Architecture: the moving parts

| Component | What it does |
|---|---|
| Scheduler | Reads parsed DAGs, decides which tasks are ready, queues them |
| DAG processor | Parses every `.py` file in `dags_folder` into DAG objects, on a timer |
| Executor | Decides HOW a queued task launches: a subprocess, a Celery worker, a pod |
| Worker | The process that actually runs your task's code |
| Webserver | Serves the UI: Grid view, Graph view, logs, Admin screens |
| Metadata database | Every DAG run, task state, Variable, Connection. The single source of truth |
| Triggerer | Runs deferrable operators in an async loop, outside a worker slot |

A `standalone` install (module 18 uses this) runs all of these as one
combined process, for convenience. A production install runs them
separately, usually on separate machines.

## 4. Executors

| Executor | How tasks run | Use it when |
|---|---|---|
| SequentialExecutor | one task at a time, SQLite only | never, except the first smoke test |
| LocalExecutor | multiple subprocesses, same machine | this course's WSL2 lab, single-machine batch |
| CeleryExecutor | tasks queued to a broker, picked up by worker processes, possibly many machines | a real bank deployment, more DAGs than one box can run |
| KubernetesExecutor | every task in its own pod | already running Kubernetes, need per-task isolation |

Module 18 uses **LocalExecutor** with **SQLite**. Fine for one learner on
one laptop, wrong the moment two people share the same install. SQLite
locks the whole file on write.

## 5. Core concepts, quick reference

| Concept | What it is |
|---|---|
| DAG | a Python object describing tasks and the order they run in. A template, not a running thing |
| DAG run | one concrete execution of that template |
| Task | one node in the DAG, always an instance of an operator |
| Operator | the class that knows HOW to do one kind of work. `BashOperator` runs a shell command |
| Sensor | a special operator that waits for a condition instead of doing work |
| XCom | how one task passes a SMALL value to another: a row count, a path, never a DataFrame |
| Connection | how to reach an external system: a host, a login, looked up by an id string |
| Variable | a small named config value, readable from any DAG, editable from the UI with no redeploy |
| Trigger rule | the condition deciding whether a task runs, given its upstream tasks' states. Default `all_success` |

If two tasks need to share a lot of data, they share a **path**
(`data/warehouse/pipeline/silver/dt=...`), the same medallion pattern
module 04 teaches. The small thing passed through XCom, if anything, is
that path, not the data itself.

Our lab DAG's tasks pass no XCom at all. Each step reads the previous
step's output straight off disk, using the run date every task shares.

## 6. Logical date versus actual run time

This is general Airflow knowledge, worth knowing before you meet it in a
real deployment. **Our lab DAG in module 18 avoids this entirely, by not
using a schedule.** `bank_pipeline.py` sets `schedule=None`: it never
runs on its own, only when you click the play button or trigger it from
the CLI, so there is no gap between "the date this run is for" and "the
moment it executed" to reason about. Read this section as background for
the day you do attach a schedule to a bank DAG, not as something module
18's lab makes you deal with.

On a scheduled DAG, Airflow separates **the period of data a run
represents** from **the moment that run actually executes**, and the two
are frequently not the same day. Those calendar-first tools do not make
this distinction at all: the job runs when the calendar says it runs.

| Field | Meaning |
|---|---|
| `logical_date` (older docs say `execution_date`, same value) | Identifies WHICH scheduled interval this run is for. Not the run's real start time |
| `data_interval_start` / `data_interval_end` | The period of data this run should cover |
| The run's actual start time | Whenever the scheduler really launched it |

A daily schedule does not mean "run at midnight". It means "produce one
run per 24-hour interval, once that interval has fully elapsed". A daily
DAG's first run does not execute ON `start_date`, it executes one full
interval LATER.

**Worked example**, so the idea is concrete. A DAG on cron `"0 2 * * *"`
(02:00 IST daily), reading this course's own three days of transaction
data:

| Cron fires at (IST) | `logical_date` | Raw file this run reads |
|---|---|---|
| 2026-09-02 02:00 | 2026-09-01 02:00 | `dt=2026-09-01.csv` |
| 2026-09-03 02:00 | 2026-09-02 02:00 | `dt=2026-09-02.csv` |
| 2026-09-04 02:00 | 2026-09-03 02:00 | `dt=2026-09-03.csv` |

Read the first row out loud: the run that physically executes at 2 AM on
September 2nd is FOR September 1st's data. That is the "yesterday's
file, processed today" pattern every bank's night batch already follows.

> **The template trap.** In a DAG template, `{{ ds }}` renders
> `logical_date` in UTC, always, no matter what timezone your schedule
> is written in. On a `"0 2 * * *"` schedule declared in IST, `{{ ds }}`
> can render as the wrong calendar day, because 02:00 IST is still the
> previous day in UTC. If a task's date genuinely must be UTC-safe,
> render it from `data_interval_start` with an explicit format instead of
> trusting `{{ ds }}` blindly, for example
> `{{ data_interval_start.in_timezone("Asia/Kolkata").format("YYYY-MM-DD") }}`.
> Our lab DAG sidesteps this entire problem: it takes its date from the
> `RUN_DATE` constant, or from the trigger config, never from a
> template.

| `catchup` setting | What happens when a scheduled DAG is unpaused with a `start_date` in the past |
|---|---|
| `True` (the historic default) | Airflow creates a run for EVERY interval between `start_date` and now, back to back |
| `False` | skips straight to the most recent interval and starts from there |

`catchup=True` is exactly like discovering a month of missed Autosys
jobs and letting the scheduler fire all of them immediately, rarely what
anyone wants by accident. Our lab DAG has no schedule at all, so
`catchup` and `start_date` never come into play for it: `start_date` is
still a required field on the DAG object, but with `schedule=None` it is
never actually used to decide when anything runs.

**Backfill** is the deliberate opposite of catchup: explicitly asking
Airflow to (re)run a specific past date range on a scheduled DAG.

```bash
airflow dags backfill some_scheduled_dag --start-date 2026-09-01 --end-date 2026-09-03
```

The direct equivalent of a Control-M manual rerun for a date range. It
only works cleanly if every task is idempotent, section 8. Our lab DAG
has no schedule to backfill against: to reprocess a range of dates with
it, you trigger it once per date instead, each time with a different
`run_date` in the config, exactly what module 18's exercises have you do.

## 7. Operators a bank will use

| Operator | Import | For |
|---|---|---|
| `BashOperator` | `airflow.operators.bash` | run any shell command. The simplest way to call a PySpark script |
| `PythonOperator` | `airflow.operators.python` | run a Python function in-process, keep it light |
| `SparkSubmitOperator` | `airflow.providers.apache.spark.operators.spark_submit` | submit through a Spark connection, the real cluster path in a full deployment |
| `EmptyOperator` | `airflow.operators.empty` | a no-op placeholder, a join point, a milestone marker |
| `FileSensor` | `airflow.sensors.filesystem` | wait for a file to exist. This course's stand-in for "did the core banking export land" |

Our lab DAG uses only `BashOperator`. `SparkSubmitOperator` is worth
knowing by name for a real cluster deployment, where a task submits
through a Spark connection instead of a plain shell command, but it adds
a moving part (a connection to configure) this course's lab does not
need.

`FileSensor` with `mode="reschedule"` releases its worker slot between
checks instead of blocking it the whole time it waits.

| Sensor mode | Behaviour | Use it when |
|---|---|---|
| `poke` (default) | holds its worker slot for the entire wait | a short wait, seconds, where the overhead of rescheduling is not worth it |
| `reschedule` | releases the worker slot between checks, goes back into the queue | any wait measured in minutes. A bank's overnight file drop is exactly this |

A dozen DAGs each waiting on a file in `poke` mode can pin down a dozen
worker slots doing nothing but sleeping. `reschedule` is a one-word fix.

## 8. Idempotency: the rule that makes reprocessing safe

A task must produce the SAME correct result no matter how many times it
runs for the same date. Not "runs without error twice", the same output.
This is not an Airflow feature, it is a discipline every task's own code
follows, and it is what makes retries, manual reruns and backfills safe
instead of dangerous.

```python
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
df.write.mode("overwrite").partitionBy("dt").parquet(path)
```

With dynamic partition overwrite, writing a DataFrame that only contains
`dt=2026-09-01` rows replaces ONLY that partition folder. Every other
date is untouched. Rerun the same date ten times, or reprocess three
dates in any order, and every partition ends up holding exactly the rows
for its own date, every time. Plain `.mode("overwrite")` with no dynamic
mode set wipes EVERY partition, silently deleting every other date's
output. `labs/17_lab_pipeline.py` sets this on every write for exactly
this reason.

| Trap | Why it breaks reprocessing | Fix |
|---|---|---|
| `.mode("append")` on a reprocessed partition | rerun the same day twice, every row appears twice | overwrite the partition, never append to one you might rerun |
| Reading `datetime.now()` instead of the passed run date | rerunning an old date silently processes the wrong day's data | always derive dates from the passed argument, never wall-clock time |

## 9. Retries, callbacks, and connections

| Setting | What it does | A sane bank default |
|---|---|---|
| `retries` | how many times to retry a failed task before giving up | 2 to 3, for a task calling something external |
| `retry_delay` | wait between retries | 5 minutes, not instant, not an hour |
| `execution_timeout` | kill the task if it runs longer than this | always set one. An unbounded Spark job should never run all night unnoticed |
| `on_failure_callback` | a function called once a task's retries are exhausted | where you actually page someone: Slack, email, a ticket |

```python
def on_task_failure(context: dict) -> None:
    ti = context["task_instance"]
    print(f"FAILED: {ti.dag_id}.{ti.task_id}, see {ti.log_url}")
```

Wire `on_failure_callback` once, in shared code, and every DAG that sets
it gets consistent alerting for free, instead of every DAG author
inventing their own message format.

A **connection** stores how to reach an external system: a host, a
login, a connection type, looked up by a short id string. Never write a
password or host as a literal in a DAG file. A DAG file is Python
source, checked into version control, readable by anyone with
`dags_folder` access. A connection's id never changes even if the
credential behind it moves to a real secrets manager later. That
indirection is the entire point.

## 10. Best practices

| Practice | Why |
|---|---|
| Keep DAG files light, no heavy computation at parse time | the DAG processor re-parses every file in `dags_folder` on a timer, forever |
| One DAG per business process | smaller DAGs fail independently, are easier to read, and rerun without dragging unrelated work along |
| Name tasks and DAGs for the business process, not the technology | `curate`, not `task_2`. The next engineer reads the Graph view, not your memory |
| Always derive dates from an explicit argument, never `datetime.now()` inside a task | section 6 and 8, the single most common source of "ran the wrong day" bugs |
| Set `max_active_runs=1` on a resource-heavy DAG | stops a second run from launching on top of a slow one on a laptop-sized box |

## 11. Reading what you see in the UI

| What you see | Likely cause | Where to look |
|---|---|---|
| Task stuck in `scheduled`, never `queued` | executor has no free slots | Admin -> Pools, or the DAG's `max_active_runs` |
| Task fails instantly, log is nearly empty | the DAG file itself failed to import, not a real task failure | `airflow dags list-import-errors` |
| Task log says "Dependencies not met" | an upstream task did not succeed, or a trigger rule was not satisfied | the Graph view, check upstream task states |
| A DAG never appears in the UI at all | wrong `dags_folder`, or an exception even before DAG parsing | `airflow config get-value core dags_folder` |
| A DAG run shows success with tasks you did not expect to see | you are looking at an old run's row, not the latest one | sort by start time in the Grid view, not row order |

Module 18 covers the install-specific issues. This table is about
reading a DAG that is already running.

## The lab

`labs/17_lab_pipeline.py --step <ingest|curate|publish> --run-date <date>`
is the script module 18's DAG calls. It has no `get_spark("lab-17")`
walkthrough shape like earlier labs, because a scheduler needs to call it
once per step, not run it top to bottom in one go.

| `--step` | Reads | Writes | Notable |
|---|---|---|---|
| `ingest` | `data/raw/transactions/dt=<date>.csv` | `data/warehouse/pipeline/bronze/dt=<date>/` | adds `ingest_ts`, fails loudly if the raw file is missing |
| `curate` | that day's bronze partition | `data/warehouse/pipeline/silver/dt=<date>/` | dedups by `txn_id`, cleans `channel`, THE DATA QUALITY GATE |
| `publish` | that day's silver partition | `data/warehouse/pipeline/gold/dt=<date>/` | one row per channel per day |

The data quality gate lives entirely in `curate`'s own exit code: a
negative-amount reject rate above `--dq-threshold` prints `DQ GATE
FAILED` and exits 1. No custom Airflow operator, no extra task, just the
script's own exit code, which is exactly the whole gate module 18's DAG
relies on.

## Common mistakes

| Mistake | Real cause | Fix |
|---|---|---|
| "It ran on the wrong date" | confusing `datetime.now()` inside a task with the date the run is actually for | always read the date from the passed argument, never wall-clock time |
| "Rerunning broke my table" | `.mode("append")`, or `.mode("overwrite")` with no dynamic mode | dynamic partition overwrite, section 8 |
| "My DAG doesn't show up" | a Python exception raised while the DAG file was parsed | `airflow dags list-import-errors`, module 18 covers this |
| Trusting `{{ ds }}` on a non-UTC schedule | `{{ ds }}` always renders in UTC | render from `data_interval_start` with an explicit timezone, section 6 |
| Treating an Airflow task as a place to do real Spark work | convenient in the moment | shell out to a real Spark job, keep the task a thin wrapper |

## Exercises

1. Run all three steps of `labs/17_lab_pipeline.py` for `2026-09-01`, in
   order. Confirm each prints `finished OK (exit 0)`.

2. Force the DQ gate to fail without touching any data:
   `--step curate --run-date 2026-09-01 --dq-threshold 0`. Confirm it
   prints `DQ GATE FAILED` and exits 1.

3. Run `ingest` and `curate` for `2026-09-01`, then again for
   `2026-09-02`. Confirm `data/warehouse/pipeline/bronze/` now has two
   `dt=` partitions, and rerunning `2026-09-01` a second time still
   leaves exactly two.

4. Using section 6's worked table, write out by hand what `{{ ds }}`
   would render as, in UTC, for a DAG run that physically executes at
   02:00 IST on 2026-09-05, on the same daily schedule.

5. Without touching any data, list which of section 9's settings
   (`retries`, `retry_delay`, `execution_timeout`, `on_failure_callback`)
   you would raise, lower, or leave alone for a job that calls an
   external core banking API known to be occasionally slow for a minute
   or two.

## Key points

- The vocabulary you already know maps almost one to one, section 2 is
  worth bookmarking.
- Airflow orchestrates, it never processes data itself.
- On a scheduled DAG, a run's logical date is the date it is FOR, not
  the date it actually ran, and `{{ ds }}` always renders that date in
  UTC. Our lab DAG has no schedule, so it never faces this.
- Idempotent tasks, dynamic partition overwrite, are what make a rerun
  or a backfill safe instead of a second thing to be afraid of.
- The data quality gate is nothing more than an exit code. Module 18
  reads it with Airflow's default trigger rule, no custom operator
  needed.
- Module 18 picks up exactly where this module stops: installing
  Airflow, and running `labs/17_lab_pipeline.py` through the one lab
  DAG.
