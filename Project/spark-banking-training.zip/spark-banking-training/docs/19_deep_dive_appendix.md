# Module 19: Deep dive appendix

This module has no lab and no companion script. It is reference reading
for the trainer, not a walkthrough for the room. Read it once, in full,
before teaching the course, so a hard question does not need "let me
check and get back to you". Keep it open during the live session and
answer from section 12 directly when a question matches one already
written out.

## Why this matters in a bank

A banking IT audience with a Hadoop or Teradata background asks precise,
mechanical questions: not "is Spark fast", but "what exact bytes are on
the wire when a Python UDF runs", or "what log line tells me a container
was killed for memory, and how is that different from a heap OOM". This
module answers the questions an experienced engineer asks once the basics
from modules 02 and 14 are settled.

---

## 1. Catalyst, phase by phase

### 1.1 The four phases

Every query, SQL text or DataFrame calls, goes through the same four
phases before it becomes a physical plan. `explain(True)` prints the
result of phases 1 to 3 directly, phase 4 only shows up as the `*(N)`
codegen markers on the physical plan.

| Phase | Input | What happens | Output |
|---|---|---|---|
| 0. Parse | SQL text or DataFrame calls | SQL goes through a grammar parser, DataFrame calls build the tree directly, nothing is checked against a catalog yet | Unresolved logical plan |
| 1. Analysis | Unresolved logical plan | Column and table references are resolved against the catalog, types are checked. A missing column surfaces here as `AnalysisException` | Resolved logical plan |
| 2. Logical optimisation | Resolved logical plan | Rule-based rewrites run in named batches, each rule applied until the plan stops changing | Optimised logical plan |
| 3. Physical planning | Optimised logical plan | Strategies turn each logical operator into candidate physical operators, a cost model picks one | Physical plan |
| 4. Code generation | Physical plan | Tungsten fuses adjacent operators into one generated Java class, compiled at runtime | Bytecode that actually runs |

### 1.2 Rules worth knowing by name

| Rule | Batch | What it does |
|---|---|---|
| `ResolveReferences` | Analysis | matches every unresolved column to a real column. A typo fails HERE, as `AnalysisException`, before optimisation runs at all |
| `ColumnPruning` | Logical Optimization | removes any column not needed higher up the tree |
| `PushDownPredicate` | Logical Optimization | moves a `Filter` as close to the source as it can safely go |
| `ConstantFolding` | Logical Optimization | evaluates an expression made entirely of literals once, at plan time |
| `CombineFilters` | Logical Optimization | merges two adjacent `Filter` nodes into one |
| `ReorderJoin` | Logical Optimization | reorders a chain of inner joins so smaller joins run first |
| `CostBasedJoinReorder` | Logical Optimization, gated by `spark.sql.cbo.enabled` (default false) | uses real table statistics, not just size estimates, only runs once `ANALYZE TABLE` has been run |

### 1.3 Why the cost-based optimiser is usually off

`spark.sql.cbo.enabled` defaults to `false`. Even turned on, the cost
model needs statistics nobody collects until `ANALYZE TABLE` is run by
hand.

| Command | Collects |
|---|---|
| `ANALYZE TABLE t COMPUTE STATISTICS` | row count and size, at the table level |
| `ANALYZE TABLE t COMPUTE STATISTICS FOR COLUMNS c1, c2` | per column distinct count, min, max, null count |

Without this, Spark's only size signal is bytes on disk. Every filter and
join above a scan then guesses a rough default selectivity, and that
guess compounds across a few chained joins, easily off by an order of
magnitude. This is exactly why AQE, module 02, is more reliable day to
day than the static cost-based optimiser: AQE reacts to the REAL,
measured size of a shuffle's output, not a guess made before any data was
read.

### 1.4 Watching a rule actually fire

| Setting | What it does |
|---|---|
| `spark.sql.planChangeLog.level` | the log level Catalyst uses when a rule changes the plan, `trace` by default |
| `spark.sql.planChangeLog.rules` | a comma list restricting output to specific rule names, for example `PushDownPredicate` |

Setting the level alone is not enough, the underlying logger for
Catalyst's rule executor also needs enabling in the logging configuration
or nothing reaches the console. Once both are set, every rule that
changed the plan prints its name and the plan before and after, the
fastest way to answer "which rule did that" instead of comparing the
parsed plan to the final plan and guessing.

### 1.5 Injecting custom rules

`SparkSessionExtensions`, set via `spark.sql.extensions`, is the
supported way to add rules without forking Spark.

| Injection method | Adds |
|---|---|
| `injectResolutionRule` | an Analyzer rule, alongside `ResolveReferences` |
| `injectOptimizerRule` | a Logical Optimization rule, alongside `PushDownPredicate` |
| `injectPlannerStrategy` | a physical planning strategy |
| `injectCheckRule` | a validation rule that can fail analysis with a custom error |

Table format extensions (module 11) use exactly this mechanism to add
their own SQL syntax and rules on top of stock Spark.

---

## 2. Tungsten and code generation

### 2.1 `UnsafeRow`, byte by byte

A row inside Tungsten is a flat byte array, not a JVM object with one
field per column. Every field costs exactly 8 bytes in a fixed region,
whatever its declared type, with variable-length data (strings) packed
into a separate region after it.

| Region | Content |
|---|---|
| Null bit set | one bit per field, set if that field is null |
| Fixed-length values | 8 bytes per field, a real value or a pointer into the next region |
| Variable-length values | the real bytes of every string or array field |

No object headers, no pointer chasing. Every field is read by computing a
fixed offset, which is what makes a tight generated loop over these rows
fast.

### 2.2 Off-heap memory

`spark.memory.offHeap.enabled` (default `false`) controls whether
Tungsten's memory pages come from the JVM heap or from memory allocated
directly outside it. Two real benefits: no per-object JVM overhead (a
normal Java object carries a 12 to 16 byte header on top of its data), and
off-heap pages are never scanned by the garbage collector at all.

### 2.3 Whole-stage codegen

`WholeStageCodegenExec` fuses a chain of adjacent operators (a filter, a
project, a hash aggregate) into ONE generated Java class, one tight loop,
no virtual method call between operators, no intermediate row
materialised between each step. `explain()` marks each fused unit with a
`*(N)` prefix, two operators sharing the same `N` are fused together.

**The 8000-byte method limit.** The JVM's JIT refuses to compile any
single method larger than roughly 8000 bytes, it still runs, but only
interpreted, never compiled to native code. `spark.sql.codegen.hugeMethodLimit`
(default 65535) is the threshold Catalyst checks before committing to a
generated method. A wide banking reporting query with forty computed
columns is a realistic way to hit this.

### 2.4 What breaks the codegen chain

| Operator or situation | Why |
|---|---|
| A Python or pandas UDF (`BatchEvalPython`/`ArrowEvalPython`) | rows leave `UnsafeRow` format entirely, cross a process boundary to Python and back |
| Any shuffle (`Exchange`) | a shuffle boundary always ends one codegen region and starts a fresh one |
| A legacy `UserDefinedAggregateFunction` | never given native codegen support |
| `.rdd` or `mapPartitions` on a DataFrame | drops out of Catalyst's operator tree entirely |

A plain Scala/Java UDF still runs INSIDE the generated code, it does not
break codegen by itself, because it never leaves the JVM. Reading
`explain()` for `*(N)` markers tells you not just that codegen is
happening, but where it stops, which is exactly where to look first when
a query is slower than its shape suggests.

---

## 3. The shuffle, physically

Module 02 already covered what a shuffle costs. This section covers what
is actually on disk.

### 3.1 Shuffle writers

| Writer | Chosen when | What it does |
|---|---|---|
| `BypassMergeSortShuffleWriter` | partition count at or below 200 (default), no map-side aggregation | writes one small file per output partition, no sort, cheapest for few destinations |
| `UnsafeShuffleWriter` | serializer supports relocation (true for `UnsafeRowSerializer`, so almost every Spark SQL shuffle) | sorts a cache-aware pointer array by partition id, never deserializes a record to compare it |
| `SortShuffleWriter` | anything needing map-side combining, or a serializer that does not support relocation | deserializes into an `ExternalSorter`, spills to disk when memory runs out |

Most real Spark SQL shuffles run through `UnsafeShuffleWriter` above the
bypass threshold, `BypassMergeSortShuffleWriter` below it.

### 3.2 Map output files

Since Spark 1.4, one map task produces exactly TWO files, not one per
reduce partition.

| File | Content |
|---|---|
| `shuffle_<id>_<mapId>_0.data` | every destination partition's output, concatenated in order |
| `shuffle_<id>_<mapId>_0.index` | byte offsets marking where each partition's segment starts and ends |

A reduce task reads the index file, finds its byte range, and reads only
that range. This two-file design is what keeps shuffle file count from
exploding, the old hash-based shuffle wrote M times N files on a big
shuffle.

### 3.3 The `MapOutputTracker`

The driver holds the single authoritative record of which map task
produced which shuffle partition. This is exactly the mechanism behind a
stage retry: a reduce task that cannot fetch a block raises
`FetchFailedException`, the driver marks that executor's outputs
unavailable, and resubmits only the LOST map tasks, not the whole stage.

### 3.4 Fetch behaviour

| Setting | Default | Controls |
|---|---|---|
| `spark.reducer.maxSizeInFlight` | 48MB | max outstanding remote fetch size per reduce task |
| `spark.shuffle.io.maxRetries` | 3 | retries for a failed remote block fetch before `FetchFailedException` |

A transient network blip on a busy cluster is common enough that these
retries matter, without them one dropped connection looks identical to a
lost executor.

### 3.5 Push-based shuffle, briefly

On a very large shuffle, tens of thousands of tasks, every reduce task
fetching small blocks from a huge number of distinct map outputs becomes
the real bottleneck, independent of skew. `spark.shuffle.push.enabled=true`
(3.2+) has map tasks additionally PUSH their blocks to remote shuffle
services ahead of time, which merge blocks for the same reduce partition
into a few larger files. A reduce task then mostly reads a handful of
merged files instead of thousands of small fetches. Best-effort by design,
any block that fails to push is still fetched the ordinary way, so
correctness never depends on it. Worth knowing exists, not worth
demonstrating on a laptop-scale dataset.

### 3.6 The external shuffle service

By default, an executor serves its own shuffle files from its own JVM.
Releasing an idle executor (dynamic allocation) then risks destroying
shuffle output a later stage needs. The external shuffle service, a
process outside any one executor's lifecycle, solves this by serving
shuffle files independent of which executors are alive.
`spark.shuffle.service.enabled=true` is a practical prerequisite for
`spark.dynamicAllocation.enabled=true` in most real deployments.

---

## 4. Scheduling and execution

### 4.1 The three layers

| Component | Runs where | Job |
|---|---|---|
| `DAGScheduler` | Driver | cuts stage boundaries at every shuffle, submits stages once parents finish, retries a stage on `FetchFailedException` |
| `TaskScheduler` | Driver | decides which executor runs which task, respects locality, drives speculation |
| `SchedulerBackend` | Driver, one per cluster manager | talks to YARN/Kubernetes/Standalone, ships tasks to executors |

### 4.2 Locality levels

Checked from most to least preferred: `PROCESS_LOCAL`, `NODE_LOCAL`,
`RACK_LOCAL`, `NO_PREF`, `ANY`. `spark.locality.wait` (default 3s) is how
long the scheduler waits for a better-locality slot before downgrading.

### 4.3 Speculative execution

`spark.speculation` (default `false`): once a task runs much slower than
the stage's median, Spark launches a duplicate on a different executor.

| Helps | Hurts |
|---|---|
| A genuinely slow NODE holding back one task for reasons unrelated to its data | Data skew, the duplicate is equally slow, wasting a second executor for nothing |
| | A non-idempotent write, two copies can both partially perform it before one is killed |

Fix skew with module 14's tools before ever reaching for speculation.

### 4.4 Task retry vs stage retry

| | Task retry | Stage retry |
|---|---|---|
| Trigger | any task failure | specifically `FetchFailedException` |
| Scope | only the one failed task | the whole map stage whose output is lost |
| Governed by | `spark.task.maxFailures` (default 4) | the DAGScheduler's own retry limit |
| Cost | cheap, one partition | can be expensive, already-finished tasks recompute |

"One task failed" and "a whole earlier stage had to recompute" look
similar in a log, only the second means real extra work happened.

### 4.5 Barrier mode and `excludeOnFailure`

`rdd.barrier()` launches every task in a stage together, as one
all-or-nothing gang, built for distributed ML frameworks (Horovod-on-Spark
is the canonical example) that need every worker alive at once to
coordinate directly. If any one task in a barrier stage fails, the WHOLE
stage restarts together, a materially different model from the ordinary
per-task retry in section 4.4. Essentially nothing in a banking ETL
pipeline uses this, worth recognising the name if it appears in a
vendor's ML integration.

`spark.excludeOnFailure.enabled` (the modern name, `spark.blacklist.enabled`
before Spark 3.1) temporarily stops sending new tasks to a node after a
run of failures concentrated there, on the theory that failures clustered
on one machine point to a hardware problem, not a data problem. Matters on
a large, long-running shared cluster with occasional bad nodes, nothing to
demonstrate on a single-node teaching sandbox.

---

## 5. Memory management, precisely

Module 02 and module 14 covered the memory MODEL at a working level. This
section fills in the mechanics.

### 5.1 The unified memory manager

An executor's heap (`spark.executor.memory`) splits into three regions.

| Region | Size | Purpose |
|---|---|---|
| Reserved | fixed 300MB | Spark's own bookkeeping |
| User memory | `(heap - 300MB) * (1 - spark.memory.fraction)` | your own objects, anything not Spark-managed |
| Unified region | `(heap - 300MB) * spark.memory.fraction` (default 0.6) | split between execution and storage |

Inside the unified region, execution memory (shuffles, joins, sorts) can
forcibly evict cached blocks from storage's borrowed space when it needs
more. Storage can borrow free execution space too, but the one thing that
NEVER happens: storage evicting execution memory a task is actively
using. When execution still is not enough, Spark spills to local disk,
not a crash, a job that runs far longer than its data size suggests.

### 5.2 Executor memory overhead

`spark.executor.memoryOverhead` (default the larger of 10% of executor
memory or 384MB) is memory the cluster manager reserves OUTSIDE the JVM
heap entirely.

| Lives in overhead | Why |
|---|---|
| Python worker processes | each is a separate OS process, the JVM has no visibility into it |
| Netty's off-heap network buffers | deliberately off-heap to avoid extra copies |
| JVM metaspace | class metadata lives outside the regular object heap |

A PySpark job with real UDF usage runs a genuinely separate Python
process per executor core, and that memory comes entirely out of
overhead, never out of `spark.executor.memory`. This is the single most
common memory-sizing mistake moving a PySpark-heavy job onto a cluster
sized like an old JVM-only job.

### 5.3 The four OOM signatures

| OOM type | Where it dies | The log line | Real cause | Real fix |
|---|---|---|---|---|
| Driver OOM | the driver JVM | `OutOfMemoryError: Java heap space`, often right after `.collect()` | too much data pulled to the driver | never `.collect()` a large DataFrame, write output instead |
| Executor JVM OOM | one executor JVM | `OutOfMemoryError: Java heap space`, that executor's own log | one task's working set exceeds `spark.executor.memory` | fix skew first, module 14, raise memory only after |
| Container killed (overhead OOM) | the whole container, OUTSIDE the JVM | YARN: `Container killed... exceeding memory limits`, no JVM stack trace at all | `memoryOverhead` too small for real off-heap usage | raise `spark.executor.memoryOverhead`, never `spark.executor.memory` |
| Python worker OOM | a separate Python process, below the executor | `Python worker exited unexpectedly`, not a Java heap error | a pandas UDF using more memory than the Python process has | set `spark.executor.pyspark.memory` explicitly |

The overhead OOM is the one most often misdiagnosed, the instinct is to
search JVM logs, and there is no stack trace there to find, the evidence
is in the cluster manager's own logs.

---

## 6. PySpark internals

### 6.1 How the Python driver talks to the JVM

`SparkContext` launches the actual Spark JVM as a subprocess, and that
JVM starts a Py4J gateway on a local, authenticated socket. Every
DataFrame or SQL call in Python is serialized into "call this method on
this Java object", sent over the socket, executed on the JVM side, and a
reference comes back. This is why ordinary DataFrame and SQL PySpark code
runs at native JVM speed, the row-by-row work never crosses into Python,
only this occasional, cheap plan-building call does.

### 6.2 How a Python UDF actually executes

A row-at-a-time Python UDF cannot use the driver-side Py4J socket at all,
that is for occasional plan-building calls, not millions of rows. On the
EXECUTOR, at task time:

1. The executor spawns a separate Python worker OS process.
2. The pickled function travels to that worker.
3. Row data is pickled and written across a local socket to the worker.
4. The worker runs the function, pickles results, writes them back.
5. The executor unpickles the results and repacks them as `UnsafeRow`s.

Every row pays this pickle, socket, unpickle round trip twice. This is
exactly the cost `BatchEvalPython` represents in an explain plan, made
concrete at the process level.

### 6.3 Worker reuse and Arrow batches

`spark.python.worker.reuse` (default `true`) keeps a spawned Python
worker alive between tasks instead of paying interpreter startup cost
again on every task.

A pandas UDF (`@pandas_udf`, shows as `ArrowEvalPython`) serializes a
whole BATCH of rows at once using Apache Arrow's columnar format instead
of one row at a time. `spark.sql.execution.arrow.maxRecordsPerBatch`
(default 10,000) controls the batch size. This removes the per-row cost
entirely, which is the real reason a pandas UDF outperforms a
row-at-a-time UDF by a wide margin at real data volume.

### 6.4 `PYSPARK_PYTHON` mismatches

The driver and every executor must run the SAME Python version for
pickled objects to travel correctly. A driver on 3.11 shipping a closure
to an executor on 3.8 fails, often with an opaque pickling error, not a
clear version message. `PYSPARK_PYTHON` must point to the identical
Python executable, or an identical packed environment, everywhere. This
is exactly why module 15's `venv-pack`/`conda-pack` approach matters
beyond shipping third-party libraries, it guarantees this consistency
across the whole cluster.

---

## 7. Deployment modes

### 7.1 Client vs cluster, and which one to schedule

| | Client mode | Cluster mode |
|---|---|---|
| Driver runs | on the machine that ran `spark-submit` | on the cluster itself |
| Submitting machine loses network | the whole job dies with it | unaffected, driver was never there |
| Log visibility | streams live to the terminal | read from the cluster manager's UI |
| Right for | interactive work, a notebook, watching a query live | any unattended, orchestrator-triggered job, module 17 and 18's exact case |

The concrete banking failure client mode invites for a SCHEDULED job: an
edge node gets rebooted for patching at 2am mid-run, and the job dies
with it, with nothing in the cluster manager's view to explain why.
Cluster mode removes this risk entirely.

### 7.2 YARN vs Kubernetes vs Standalone

| | YARN | Kubernetes | Standalone |
|---|---|---|---|
| Multi-tenancy | mature, queue-based, familiar to a Hadoop background | namespace and quota based, increasingly mature | weak, built for a Spark-only cluster |
| Typical bank fit | safe choice if already running Hadoop/YARN | the right target when the platform is standardising on Kubernetes | rare, mostly a small proof of concept |

The realistic decision for most teams: stay on YARN if it is already
running well, move to Kubernetes as part of a deliberate platform
standardisation, not a Spark-specific initiative on its own.

### 7.3 Dynamic allocation, briefly

| Setting | Default | Meaning |
|---|---|---|
| `spark.dynamicAllocation.enabled` | `false` | turns the mechanism on |
| `spark.dynamicAllocation.minExecutors` / `maxExecutors` | 0 / infinite | floor and ceiling |
| `spark.dynamicAllocation.executorIdleTimeout` | 60s | an idle executor is released after this long |

Requires the external shuffle service, section 3.5, or releasing an idle
executor risks destroying shuffle output a later stage still needs.

---

## 8. Adaptive Query Execution, precisely

Module 02 already showed AQE change a plan. This section is the mechanism
underneath that change.

### 8.1 Why AQE exists at all

Section 1.3 already made the core point: the static optimiser plans
everything up front, from size estimates that can be an order of
magnitude wrong after a few chained joins. AQE's answer is to stop
planning everything up front. A query is broken into stages at shuffle
boundaries anyway (section 3), and AQE re-optimises the REMAINING plan
after each stage actually finishes, using the real, measured size of that
stage's output, not a guess made before any data was read.

### 8.2 The three re-optimisations that matter

| Optimisation | Gated by | What it does |
|---|---|---|
| Coalescing shuffle partitions | `spark.sql.adaptive.coalescePartitions.enabled` (default true) | merges many small post-shuffle partitions into fewer, right-sized ones, instead of running thousands of tiny tasks |
| Converting a sort-merge join to a broadcast join | `spark.sql.adaptive.autoBroadcastJoinThreshold` | if a shuffle's REAL output turns out small enough, AQE swaps the join strategy after the fact, something the static planner could never do because it never saw the real size |
| Handling a skewed join | `spark.sql.adaptive.skewJoin.enabled` (default true) | splits an abnormally large shuffle partition into several smaller ones before the join reads it, module 14's skew fix, happening automatically |

### 8.3 Where AQE cannot help

AQE only re-optimises AFTER a shuffle has already run and produced real
statistics. A query with no shuffle at all (a single table scan and
filter) gives AQE nothing to react to. A query whose very FIRST join is
already badly skewed still pays the cost of that first, un-optimised
shuffle, AQE only prevents the skew from compounding into every join
after it. This is precisely why module 14's manual techniques (broadcast
hints, salting) still matter, AQE is a safety net for the joins after the
first one, not a replacement for understanding why the first one is slow.

---

## 9. The catalog, briefly

A banking audience arriving from Hive or Teradata already thinks in terms
of a metastore. Spark's catalog is the same idea, smaller.

| Concept | What it is |
|---|---|
| `spark.catalog` | the Python-side handle to metadata: `listTables()`, `listColumns()`, `tableExists()` |
| In-memory catalog | the default, metadata lives only for this `SparkSession`'s lifetime, gone when the process exits |
| Hive metastore catalog | `enableHiveSupport()` on the builder, metadata persists in an external metastore database, shared across sessions and clusters |
| `spark_catalog` | the name of whichever catalog implementation is currently the default one, table formats (module 11) often replace what this name points to |

This course's own `get_spark()` never calls `enableHiveSupport()`, every
lab's tables exist only as Parquet paths on disk, read back by path, not
by a persisted table name. A real bank deployment almost always runs a
Hive metastore (or a table format's own catalog, module 11) precisely so
a table survives past one Spark application's lifetime and is visible to
every team's cluster, not just the one that wrote it.

---

## 10. Write commits, and why some writes are not atomic

### 10.1 `FileOutputCommitter` v1 vs v2

`mapreduce.fileoutputcommitter.algorithm.version` controls how a job's
output actually lands in its target directory.

| | v1, the safe default | v2, faster, opt-in |
|---|---|---|
| Task commit | each task writes to its own temp directory | each task renames its output directly into the final directory as soon as it succeeds |
| Job commit | the driver renames every task's output into place, AFTER all tasks succeed | no separate job commit of consequence |
| A job that fails partway | the final directory is never touched until every task succeeds | the final directory can already hold SOME tasks' output with no way to tell if the job finished |

For a regulated, reconciled banking output, where a downstream process
might read a table the moment it appears to finish, v1's atomic-at-the-job
guarantee is usually worth the slower commit. Moving to v2 for speed
should be a deliberate, understood choice.

### 10.2 Non-atomic writes on object storage

Unlike HDFS's rename (a cheap, metadata-only operation, exactly what
makes v1's final rename pass cheap on HDFS), a "rename" on S3 or ADLS is a
server-side copy followed by a delete, neither cheap nor atomic. This is
why real object-storage deployments need a purpose-built committer
instead of the classic `FileOutputCommitter`, on top of, not instead of,
the v1 vs v2 choice above.

### 10.3 Idempotent and exactly-once batch patterns

| Pattern | How it works |
|---|---|
| Dynamic partition overwrite | a retried write only replaces the partitions it actually produced, module 04 and 17 |
| MERGE, keyed on a business key | a rerun matches existing rows by key and updates them in place, module 11 |
| A batch control table | check a control table for whether this batch id already committed, before writing again |
| Write-to-staging, then atomic swap | write to a new location, verify row counts, THEN atomically point "current" at it, so a mid-write failure never leaves a half-written table visible |

The common thread: none of these rely on "the job only runs once". All
four make a SECOND, identical run produce the identical result, which is
the only definition of exactly-once that survives contact with a real,
retried production schedule.

---

## 11. Determinism traps that break a rerun

A function whose result can differ between two runs of the SAME code over
the SAME input data is a trap the moment a job gets retried, backfilled,
or rerun after a failure, all routine events in a scheduled pipeline.

| Function or pattern | The trap | The fix |
|---|---|---|
| `monotonically_increasing_id()` | values depend on partition id and count, a rerun after a partition change assigns different ids to different rows | never use it as a durable key, persist a real generated key instead |
| `rand()` / `randn()` with no seed | two runs return different values, even a task retry within the SAME run can differ | always pass a fixed `seed` |
| `collect_list()` / `collect_set()` | row order inside the array is not guaranteed unless the input was sorted first | `orderBy()` before the aggregate, or `sort_array()` after |
| An unstable sort on a non-unique key | rows tied on the key have no guaranteed relative order, and it can change between runs | add a genuinely unique secondary sort key |
| `first()` / `last()` with no explicit ordering | means "whichever row Spark happened to process first", not a business meaning | only trust these inside a window with an explicit `ORDER BY` |

**Why a retried task can double-write.** Spark's retry model guarantees
the COMPUTATION eventually produces a correct result. It says nothing
about a SIDE EFFECT a task already performed before failing for an
unrelated reason, a lost executor, a speculative duplicate. If that side
effect was a raw insert or a plain file append with no commit protocol
behind it, a retried task can perform it TWICE, and Spark has no way to
know. Prevention is always the same shape module 04, 11 and 17 already
teach: dynamic partition overwrite, a `MERGE` keyed on a real business
key, or an explicit dedup step, never "the job only runs once".

---

## 12. Twenty four hard questions, and the confident answer

| # | Question | Answer |
|---|---|---|
| 1 | Why did my filter written after a join end up running before it in the plan? | `PushDownPredicate` moved it, section 1.2, `explain(True)` shows the rewrite |
| 2 | Why does a typo'd column name fail before any data is read? | It fails in the Analysis phase, `ResolveReferences`, before optimisation or execution ever start |
| 3 | Why is the cost-based optimiser not helping my join order? | It defaults off, and even on, needs `ANALYZE TABLE` statistics that likely were never collected, section 1.3 |
| 4 | Why does `explain()` show several `*(N)` stages instead of one? | A shuffle, a Python UDF, or an unsupported operator broke the codegen chain, section 2.4 |
| 5 | Why is my UDF so much slower than the built-in function it replaces? | The built-in stays inside generated JVM code, the UDF crosses a process boundary to Python and back, section 6.2 |
| 6 | Why did a pandas UDF fix the slowness a row UDF had? | Arrow batches remove the per-row pickle cost entirely, section 6.3 |
| 7 | Why did my job die with no stack trace anywhere in the Spark logs? | Almost certainly a container-level OOM, check the cluster manager's own logs, section 5.3 |
| 8 | Why does raising `spark.executor.memory` not fix a YARN "container killed" error? | That error is an overhead OOM, outside the JVM heap entirely, raise `memoryOverhead` instead |
| 9 | Why did a PySpark job need much more memory than the same job in Scala? | Every Python UDF spawns a separate OS process, its memory comes from overhead, not the JVM heap, section 5.2 |
| 10 | Why do two runs of the same job produce different row order? | An aggregate or sort with no explicit, unique ordering, section 11, add one |
| 11 | Why did a backfill for last month accidentally use this month's exchange rate? | The job read `datetime.now()` or a mutable table's current state instead of the run's own date, section 11 |
| 12 | Why did rerunning a failed day duplicate rows instead of fixing them? | `.mode("append")`, or `.mode("overwrite")` with no dynamic partition mode, module 17 section 8 |
| 13 | Why is a shuffle with a tiny number of partitions still slow? | Check for skew, one huge partition dominates wall time even with few partitions, module 14 |
| 14 | Why did one lost executor cause a much bigger stage to redo work? | Its shuffle output was needed downstream, a `FetchFailedException` triggered a STAGE retry, not just a task retry, section 4.4 |
| 15 | Why does the external shuffle service matter for dynamic allocation? | Without it, releasing an idle executor can destroy shuffle output a later stage still needs, section 3.6 |
| 16 | Why did a scheduled job silently die when someone rebooted an edge node? | It ran in client mode, the driver lived on that edge node, cluster mode avoids this, section 7.1 |
| 17 | Why does my driver and executor need the exact same Python version? | Pickled closures and objects depend on matching Python and library versions to deserialize correctly, section 6.4 |
| 18 | Why is speculative execution making a skewed job slower, not faster? | The duplicate task is equally skewed, it wastes a second executor for no benefit, fix skew instead, section 4.3 |
| 19 | Why did `monotonically_increasing_id()` give a row a different id after a rerun? | It depends on partition id and count, never durable across reprocessing, section 11 |
| 20 | Why does a wide 40-column reporting query fall back to interpreted execution? | It likely hit the JIT's method size limit, `hugeMethodLimit`, section 2.3 |
| 21 | Why does `first()` on an ungrouped DataFrame give a different row each run? | No explicit ordering, "first" means whatever Spark happened to process first, section 11 |
| 22 | Why does a job that used to fit in memory suddenly spill to disk after a data volume increase? | Execution memory ran out even after borrowing storage's unused share, section 5.1, Spark spills rather than crashing |
| 23 | Why did AQE not fix a slow join that was skewed from the very first shuffle? | AQE reacts after a shuffle finishes, it cannot fix the cost of the first, un-optimised shuffle itself, section 8.3 |
| 24 | Why did a table this job wrote disappear the moment the SparkSession stopped? | No `enableHiveSupport()`, the in-memory catalog holds metadata only for that session's lifetime, section 9 |

## Key points

- Catalyst has four phases, a column typo fails in Analysis, before
  optimisation or codegen ever run.
- Codegen fuses operators into one loop, a shuffle or a Python UDF always
  breaks the chain.
- Four distinct OOM signatures exist, and the fix for each is different,
  confusing them wastes a real incident's worth of time.
- AQE re-optimises after a shuffle finishes, using real measured sizes,
  it is a safety net for later joins, not a fix for the first one.
- A retried Spark task guarantees a correct computation, never a
  once-only side effect, idempotent writes are the only real fix.
- Section 9 is written to be read from, live, during a training session,
  not memorised in advance.
