# Module 15: Packaging PySpark applications

After this module you can turn a script into a small, tested, installable
Python package, and run it two real ways: as a module and through
`spark-submit`.

## Why this matters in a bank

A script that only runs correctly from one laptop, in one folder, is not a
production job, it is a liability with a due date. The day that job needs
to run in UAT instead of dev, or a fix needs to go through change control,
"email me the file" is not an acceptable answer in a regulated bank.
Packaging is what makes a job testable before it ships, reproducible
across environments, and traceable to a version.

## 1. Why a folder of loose scripts fails in production

| Problem | What goes wrong |
|---|---|
| No tests | a change has no automated way to prove it did not break the numbers, only manual re-running |
| No versioning | "which version is running in prod right now" has no good answer |
| No reuse | two scripts hand-roll the same logic and drift apart the moment one gets fixed |
| No config separation | a path or threshold gets hardcoded, so "run this in UAT" means editing the file |

Every lab file in this course, modules 01 to 14, does exactly the right
thing for teaching: one concept, one file, easy to read on a projector.
`bankjobs/`, the package this module builds, is that same course's answer
to what changes once a job has to survive a second environment and a
second person maintaining it.

## 2. Project layout, file by file

```
labs/bankjobs/
  __init__.py       package marker, __version__
  __main__.py        entry point: argparse, logging, exit codes, dispatch
  config.py           the ONLY place a path or environment default lives
  jobs/
    __init__.py        JOB_REGISTRY: job name -> job module
    daily_kpi.py        transform() [pure] + run() [does the IO]
  pyproject.toml      package metadata, the bankjobs console script
```

| File | Job |
|---|---|
| `__init__.py` | marks the folder as an importable package, carries `__version__` |
| `__main__.py` | the only place argument parsing, logging setup and exit codes live |
| `config.py` | the only place a path or environment default lives |
| `jobs/daily_kpi.py` | the business logic, split into a pure `transform()` and an IO `run()` |
| `pyproject.toml` | what turns this folder into something `pip` understands |

`bankjobs` reads transactions and accounts from `data/raw/` directly and
writes one row per branch per day to `data/warehouse/gold/daily_kpi/`. It
does not depend on Lab 04's own bronze, silver or gold output: it is a
small, standalone package, meant to be run from the project root on its
own, exactly like it would be deployed anywhere else.

## 3. `spark-submit` flags that matter

| Flag | What it does |
|---|---|
| `--master` | `local[N]`, `yarn`, `k8s://...`, `spark://host:port`, where the job runs |
| `--deploy-mode` | `client` (driver runs where you launched spark-submit) or `cluster` (driver runs on the cluster) |
| `--py-files` | ship extra Python code: a `.zip`, an `.egg`, or a `.py` file, added to every executor's `sys.path` |
| `--files` | ship non-code files, a small lookup CSV, alongside the job |
| `--conf` | set any `spark.*` setting for this run, repeatable |
| `--packages` | fetch a Maven coordinate at submit time, needs network access, see module 12 |
| positional | `<script>.py` first, then your own application's arguments |

**Argument order is the single most common mistake.** Every `spark-submit`
flag goes before the script path. Every argument after the script path is
yours. Put an application argument before the script path and
`spark-submit` tries to parse it as its own flag and fails.

```bash
spark-submit --master local[2] --py-files labs/bankjobs.zip \
  labs/bankjobs/__main__.py --job daily_kpi --env dev
```

Run from the project root, exactly the way Lab 15 runs it: `local[2]` and
`--py-files labs/bankjobs.zip` belong to `spark-submit`, everything after
`labs/bankjobs/__main__.py` belongs to `bankjobs`'s own `argparse`.

**Client vs cluster mode.** `client` mode is what this module's demo uses,
the driver runs right here, logs stream live to the terminal. `cluster`
mode hands the driver itself to the cluster manager, the right choice for
an unattended scheduled job, at the cost of losing the live log stream.

## 4. Shipping Python dependencies, three ways

| Method | How | Best for |
|---|---|---|
| `--py-files` zip | zip your own pure Python code, ship with `--py-files` | small pure-Python packages like `bankjobs`, no third-party wheel needed |
| `venv-pack` / `conda-pack` + `--archives` | build a full virtualenv locally, pack it, ship with `--archives`, unpack on each executor | real third-party dependencies on a cluster with no internet access |
| A custom Docker image | bake Python, PySpark and every dependency into the image | Kubernetes-native Spark clusters, image builds already part of the pipeline |

A bank cluster with no outbound internet cannot use `--packages` at all.
That leaves `venv-pack`/`conda-pack` or a Docker image as the two
realistic choices for real third-party dependencies. `--py-files` alone
only ships code, never a compiled extension or a third-party wheel.

## 5. `pyproject.toml`, and why it needs one extra section

```toml
[project]
name = "bankjobs"
version = "0.1.0"

[project.scripts]
bankjobs = "bankjobs.__main__:main"

[tool.setuptools]
packages = ["bankjobs", "bankjobs.jobs"]

[tool.setuptools.package-dir]
bankjobs = "."
"bankjobs.jobs" = "jobs"
```

`pyproject.toml` lives inside `bankjobs/` itself, so this one folder is
both the project root and the package root, a layout automatic package
discovery does not expect (it normally looks for the package as a
SUBFOLDER of the project root). The `[tool.setuptools]` section tells it
exactly where each package's source lives instead of guessing.
`[project.scripts]` means installing the built wheel also creates a plain
`bankjobs` command on PATH, equivalent to `python -m bankjobs`, with no
need to remember the internal file layout at all.

## 6. Config management

`config.py` implements a strict precedence, lowest to highest:

1. a per-environment default (`dev`/`uat`/`prod`, `uat` and `prod` are
   illustrative `s3a://` placeholders here, never runnable in this
   sandbox)
2. an environment variable (`BANKJOBS_RAW_PATH`, `BANKJOBS_WAREHOUSE_PATH`,
   `BANKJOBS_SHUFFLE_PARTITIONS`)
3. an explicit command-line argument, always wins

```python
@dataclass(frozen=True)
class JobConfig:
    env: str
    raw_path: str
    warehouse_path: str
    shuffle_partitions: int = 8
```

`frozen=True` makes a `JobConfig` immutable once built, nothing downstream
can silently change the path a job is reading from mid-run. Every field is
typed and visible in one place, instead of scattered `config.get("x",
default)` calls with the default duplicated wherever it is needed.

Paths default to plain relative paths (`data/raw`), never a path computed
from `__file__`. A path computed relative to the script's own file works
perfectly under `python script.py` and quietly breaks once that same code
runs from inside a zip, because Python resolves `__file__` differently
inside a zip archive. The fix used here is simpler: never compute a path
that way at all, run from the project root, or pass `--raw-path`
explicitly.

**Secrets never appear in a default or a command-line argument.** A job
that genuinely needs a database password reads it from an environment
variable at the moment it is needed, never baked into `JobConfig`, never
logged.

## 7. Logging properly

```
2026-09-14 07:21:22,046 level=INFO correlation_id=6a6bf44f302d logger=bankjobs.daily_kpi msg=reading transactions from data/raw/transactions
2026-09-14 07:21:22,046 level=INFO correlation_id=6a6bf44f302d logger=bankjobs.daily_kpi msg=wrote 108 rows to data/warehouse/gold/daily_kpi
2026-09-14 07:21:22,047 level=INFO correlation_id=6a6bf44f302d logger=bankjobs.main msg=job=daily_kpi SUCCEEDED, 108 rows, 7.58s
```

Every log line carries the same `correlation_id`, a fresh id generated
once per run. In a shared log file collecting output from every scheduled
job on a cluster, that id is what lets someone pull exactly one run's
lines out of millions, instead of guessing from a timestamp.

**What to log**: job name, environment, correlation id, row counts,
elapsed time, success or failure, always. **Never** log a full customer
record or an account number "just for debugging": logs usually have
weaker access control than the data they describe.

## 8. Testing PySpark: separating logic from IO

`jobs/daily_kpi.py` splits into two functions on purpose:

```python
def transform(txns: DataFrame, accounts: DataFrame) -> DataFrame:
    """Pure: DataFrame in, DataFrame out. No file path, no config."""
    ...

def run(spark: SparkSession, config: JobConfig) -> int:
    """IO: reads using config, calls transform(), writes, returns a count."""
    ...
```

`transform()` never touches a file path or a config object. That is what
makes it testable with five hand-built rows, no file on disk, nothing
beyond a `SparkSession` fixture and a DataFrame. If the logic and the IO
stayed mixed together, testing the aggregation would need a real file on
disk every single time.

**The pytest fixture** (`tests/conftest.py`), session-scoped so the JVM
starts once for the whole test run:

```python
@pytest.fixture(scope="session")
def spark():
    session = SparkSession.builder.appName("bankjobs-tests").master("local[2]").getOrCreate()
    yield session
    session.stop()
```

**A test against `transform()`**, built rows in, checked rows out:

```python
def test_transform_sums_and_counts_correctly(spark):
    txns, accounts = _build_fixture(spark)
    row = ...  # look up the ("BR01", "2026-09-01") group
    assert row.txn_count == 3
    assert row.total_amount == 175.0
```

Verified, this course's own suite:

```
tests/test_bankjobs.py::test_transform_aggregates_per_branch_per_day PASSED
tests/test_bankjobs.py::test_transform_sums_and_counts_correctly PASSED
tests/test_bankjobs.py::test_transform_drops_non_success_status PASSED
tests/test_bankjobs.py::test_load_config_dev_defaults PASSED
tests/test_bankjobs.py::test_load_config_explicit_argument_wins PASSED
tests/test_bankjobs.py::test_load_config_unknown_env_raises PASSED
tests/test_bankjobs.py::test_job_config_output_path_joins_correctly PASSED
7 passed in 16.38s
```

Notice the config tests need no `spark` fixture at all: `JobConfig` and
`load_config()` are plain Python, and testing them as plain Python, no JVM
startup, is exactly the point of keeping config separate from both IO and
Spark.

## 9. Error handling and exit codes

```python
try:
    row_count = job_module.run(spark, config)
except Exception:
    logger.exception("job=%s FAILED after %.2fs", args.job, elapsed)
    spark.stop()
    return 1
else:
    logger.info("job=%s SUCCEEDED, %d rows, %.2fs", args.job, row_count, elapsed)
    spark.stop()
    return 0
```

Three distinct exit codes for three distinct failure shapes:

| Exit code | Meaning |
|---|---|
| 0 | the job ran and wrote its output |
| 1 | the job raised an exception, caught and logged here |
| 2 | a bad command-line argument, argparse's own code, never even builds a `SparkSession` |

A scheduler like Airflow or cron only ever sees one integer, never log
text. Getting this right is the entire contract between this package and
whatever schedules it, module 17 and 18 next.

## 10. Running `bankjobs`, both ways

```bash
# as a module, from the project root
python -m bankjobs --job daily_kpi --env dev

# via spark-submit, shipping the code as a zip
spark-submit --master local[2] --py-files labs/bankjobs.zip \
  labs/bankjobs/__main__.py --job daily_kpi --env dev
```

Both write the same 108 rows (36 branches times 3 days) to
`data/warehouse/gold/daily_kpi/`, verified in Lab 15.

## 11. CI/CD outline

A packaged job is what makes this pipeline possible at all. A loose script
has no artifact to lint, test or version in the first place.

| Step | What happens |
|---|---|
| Lint | `ruff` or `flake8` over `bankjobs/`, fail the pipeline on a lint error |
| Test | `pytest tests/ -v`, section 8, fail the pipeline on any red test |
| Build | `python -m build --wheel`, produces a versioned `.whl` artifact |
| Publish | push the wheel to an internal package index, tagged with a commit hash |
| Deploy | the scheduler's job definition (an Airflow DAG, module 17 and 18) points `spark-submit --py-files` at the new version, usually through a UAT run first |

## 12. What changes moving from dev to a real environment

Nothing in `jobs/daily_kpi.py` changes at all. Only `config.py`'s `uat` and
`prod` defaults, or the environment variables and arguments overriding
them, do. That is the whole point of section 6's precedence rules: the
business logic never needs to know or care which environment it is
running in.

| In this course | In a real bank deployment |
|---|---|
| `dev` reads `data/raw/` on a laptop | `uat`/`prod` read from `s3a://` or HDFS, set once in `config.py` |
| `local[*]` master, hardcoded in the demo | `--master yarn` or a Kubernetes master, passed by `spark-submit`, not the script |
| A password, if any, would come from an environment variable | the same environment variable, backed by the bank's own secrets manager |
| `python -m pytest` run by hand | the same command, run by a CI pipeline on every commit |

## The lab

| Step | Shows |
|---|---|
| 1 | Why a folder of loose scripts is not a production job |
| 2 | The `bankjobs/` package layout on disk |
| 3 | Running it as a module: `python -m bankjobs` |
| 4 | What landed in `data/warehouse/gold/daily_kpi/` |
| 5 | Zipping the package and running the real `spark-submit --py-files` command |
| 6 | Config precedence: one environment variable, no code change |
| 7 | Running `pytest tests/`, all seven tests |

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| Computing a default path relative to `__file__` | works under `python script.py`, nobody tested it packaged | pass paths explicitly, or run from the project root, section 6 |
| An application argument before the script path in `spark-submit` | assuming argument order does not matter | it does, section 3, everything before the script path belongs to `spark-submit` |
| Mixing IO and business logic in one function | faster to write the first version that way | split `transform()` (pure) from `run()` (IO), section 8 |
| A new `SparkSession` per test | copying a habit from an unrelated example | one session-scoped fixture for the whole run |
| Logging a full row or an account number "for debugging" | debugging pressure in the moment | log row counts and correlation ids, never PII |
| Relying on `--packages` on a real bank cluster | works fine on a laptop with internet | most bank clusters have no outbound internet, section 4 |

## Exercises

1. Run `labs/15_lab_packaging.py` and confirm all seven steps print exit
   code 0.

2. Add a second job, `channel_mix` (total amount and count per channel,
   no branch grouping), as `bankjobs/jobs/channel_mix.py`, with its own
   `transform()`/`run()` split. Register it in `jobs/__init__.py`'s
   `JOB_REGISTRY` and confirm `python -m bankjobs --job channel_mix`
   works without touching `__main__.py` at all.

3. Write one test for your new job's `transform()`, with hand-built
   fixture rows, following section 8's pattern.

4. Set `BANKJOBS_WAREHOUSE_PATH=/tmp/bankjobs_out` and rerun
   `python -m bankjobs --job daily_kpi`. Confirm the output lands under
   `/tmp/bankjobs_out/gold/daily_kpi` instead of `data/warehouse/`, with
   no code change.

## Key points

- A package beats a loose script the moment a job needs to survive a
  second environment or a second person.
- `transform()`/`run()` splits pure logic from IO, and that split is what
  makes PySpark code testable without a real file.
- Config precedence (default, then env var, then argument) means the same
  code runs in dev, UAT and prod with zero edits.
- Exit codes, not log text, are the entire contract between a packaged job
  and whatever schedules it.
