# Module 14: Performance Tuning

What you can do after this module: measure a slow query instead of
guessing at it, name the four most common causes of a slow Spark job, fix
skew on branch BR011 three different ways, explain what Adaptive Query
Execution actually changes, and know why too many small files costs real
time on read.

```bash
./run.sh labs/14_lab_tuning.py
```

Every number this module's lab prints is measured live, from that exact
run, not a canned example. Re-run it and the numbers will differ slightly,
that is expected, the pattern each one demonstrates will not.

## Why this matters in a bank

"The job is slow" is not useful information on its own. A batch reporting
job that used to finish in 20 minutes and now takes 3 hours is a real
production incident in a bank, month-end close, regulatory reporting and
fraud detection all depend on jobs finishing inside a fixed window. The
skill this module builds is turning "it feels slow" into a specific,
measured cause, and applying the one fix that matches it, not a guess.

## 1. Method: measure, change one thing, measure again

| Step | Do this |
|---|---|
| 1. Measure | time the query, or read the Spark UI's Stages tab, before changing anything |
| 2. Identify | is it shuffle-bound, spill-bound, skew-bound, or genuinely a lot of real data? |
| 3. Fix | apply the ONE change that matches what you identified |
| 4. Re-measure | the same way, and keep the before and after number |

Changing three settings at once and re-running means you learn nothing
about which one actually helped. Every section below follows this same
four-step shape, with `Lab 14`'s own real numbers as the proof.

## 2. Reading the Spark UI: symptom to cause

| Symptom | Likely cause | Where to look |
|---|---|---|
| One job takes far longer than the others | find its slowest STAGE first, a job is too coarse a unit | Jobs tab, click in, Stages tab |
| One task in a stage takes far longer than the rest | skew on the shuffle or join key | Stages tab, task duration max vs median, Section 4 |
| Shuffle read/write bytes are large relative to input size | an avoidable wide shuffle, often a join that should broadcast | SQL tab's plan, count the Exchange nodes |
| `memoryBytesSpilled` or `diskBytesSpilled` above zero | not enough execution memory for a sort, aggregate, or join | widen shuffle partitions, or genuinely add memory |
| Many tiny tasks, overhead dominates | too many partitions for the data volume | check `spark.sql.shuffle.partitions` against real data size |
| Few, very large tasks | too few partitions, or uneven partition sizes | `repartition`, or let AQE coalesce/split |

## 3. The big four: skew, spill, shuffle volume, small files

Almost every slow Spark job traces back to one, often several, of these
four. `Lab 14` demonstrates the two this course's data was built to show
directly (skew, small files), plus shuffle volume and shuffle partition
count as the same demo's other side.

## 4. Skew, detected: BR011 holds about 22 percent of every branch-keyed join

`Lab 14`, Step 1, joins transactions to `accounts.csv` (broadcast, it is
small) and groups by `branch_code`:

```python
skewed = txns.join(F.broadcast(accounts.select("account_id", "branch_code")), "account_id")
skewed.groupBy("branch_code").count().orderBy(F.desc("count")).show(5)
```

BR011 alone carries roughly 10 times an average branch's share of this
key, by design, see Module 00's data generator. Every downstream shuffle
keyed on `branch_code` sends that share to ONE reduce task, while the
other 35 branches split the rest across the remaining tasks. That one
oversized task is the straggler that keeps a whole stage running long
after every other task has already finished.

## 5. Skew, measured directly: row counts per output partition

`Lab 14`, Step 3, makes the skew visible without needing the Spark UI at
all, `spark_partition_id()` reports which physical partition each row
landed in after a repartition keyed on `branch_code`:

```python
by_branch = skewed.repartition(8, "branch_code")
sizes = by_branch.withColumn("pid", F.spark_partition_id()).groupBy("pid").count()
```

The lab's own run showed roughly an 8-to-9x gap between the largest and
smallest of the 8 partitions, BR011's rows landing almost entirely in one
of them. That ratio, not a vague "it feels slow", is the number to trust.

## 6. Skew fix: salting

Salting spreads one hot key across N buckets by adding a random "salt"
column on the large side, so the key that used to be one value
(`BR011`) becomes N different values (`BR011` with salt 0 through 7):

```python
N = 8
salted = skewed.withColumn("salt", (F.rand(seed=42) * N).cast("int"))
by_salted = salted.repartition(8, "branch_code", "salt")
```

`Lab 14`'s own run: the skew ratio from Section 5 dropped from about 8.7x
to about 1.9x after salting, while the total row count stayed exactly the
same, salting changes HOW the data is spread across partitions, never how
many rows exist. Salting's real payoff scales with a real cluster's core
count, more partitions means more room to spread N buckets without two of
them still landing on the same physical partition by chance. On a small
laptop-scale run, expect the ratio to improve clearly even if wall-clock
time barely moves, task-scheduling overhead dominates at this tiny scale
far more than the residual skew does.

## 7. Skew fix: broadcast, the right fix when the small side is small

Section 4's join already broadcasts `accounts`, which is exactly why the
skew shows up on the GROUP BY afterward, not on the join itself. When
BOTH sides of a join are small enough to broadcast, skew on the join key
stops being a question at all, neither side needs to be shuffled and
partitioned by that key in the first place. Reach for AQE's skew join
handling or salting only when both sides are genuinely too large to
broadcast.

## 8. Shuffle partition count: 200 vs 8, same query

`Lab 14`, Step 2, runs the exact same aggregation with
`spark.sql.shuffle.partitions` set to 200, then to 8:

```python
spark.conf.set("spark.sql.shuffle.partitions", "200")
# ... run, time it ...
spark.conf.set("spark.sql.shuffle.partitions", "8")
# ... run again, time it ...
```

The lab's own run: about 3.8 seconds at 200 partitions, about 0.4 seconds
at 8. 200 tasks for a result with only 36 distinct branch codes is pure
scheduling overhead, most of those tasks do almost no real work but still
pay a fixed per-task cost. This is exactly why `bank_session.get_spark()`
sets `shuffle_partitions=8` by default instead of Spark's factory default
of 200.

## 9. AQE, and `get_spark(aqe=...)`

Adaptive Query Execution re-plans parts of a query at runtime, once it has
seen the real size of a shuffle, instead of trusting only the plan built
before anything ran. Its most visible effect: **coalescing**, merging many
small post-shuffle partitions down to as few as the data actually needs.

`Lab 14`, Step 5, restarts the Spark session with `get_spark(aqe=False)`
then `get_spark(aqe=True)`, because `aqe` is a build-time choice on the
session in this course, not something a lab flips mid-query with
`spark.conf.set`:

```python
spark.stop()                                     # aqe is set when the session is built
spark = get_spark("lab-14-tuning-aqe", aqe=True, shuffle_partitions=200)
```

With AQE on, Spark coalesces the 200 planned partitions down toward the
number the actual shuffle size needs, after seeing that size at runtime,
something a static, aqe=False plan can never do because it only ever sees
the plan, not the real data. AQE ships enabled by default since Spark 3.2,
and this module's advice is the same as every real production Spark team's:
leave it on, only turn it off to isolate a specific static-planner
behaviour for teaching, exactly what Steps 1 through 4 do on purpose.

## 10. Small files: write-time cause, read-time cost

`Lab 14`, Step 6, writes the same rows two ways, then reads both back with
the same filter:

```python
wide = channel_txns.repartition(40)              # exaggerated on purpose
wide.write.mode("overwrite").parquet(many_path)
wide.coalesce(3).write.mode("overwrite").parquet(few_path)
```

Same rows, same query, the only difference is how many files they were
split across. Every file, however small, costs a fixed amount of
list-and-open overhead before Spark reads a single row from it. On HDFS
this is the classic "small file problem" that drowns the NameNode in
metadata, on a lake the same cost falls on file listing and open-file
overhead instead. `coalesce()` before a write, or a periodic compaction job
(Delta's `OPTIMIZE`, Iceberg's `rewrite_data_files`, Module 11), is the
standard fix.

## 11. Spill: the fourth of the big four

Spill happens when execution memory, a sort, a hash aggregate, a join's
build side, does not fit in the memory Spark set aside for it, so Spark
writes partial state to local disk and merges it back later. It is not a
crash, it silently turns memory-speed work into disk-speed work, with no
error anywhere in the log. The two fields that show it directly, on the
Stages tab: `memoryBytesSpilled` and `diskBytesSpilled`, both above zero
means spill happened. On this course's small, laptop-scale data, expect
both to read `0.0 MB`, that is the correct, honest result at this data
size, not a sign the check is broken. The fix, once real spill shows up on
real data: widen `spark.sql.shuffle.partitions` so each task handles less
data, or resolve the skew that put far more data than expected into one
task in the first place, Sections 4 through 7, before assuming the answer
is simply more memory.

## 12. Shuffle volume: the same numbers again, a different lens

Sections 4 through 7's four runs already prove the shuffle volume point
directly, without any new code: the broadcast join in Section 7 does not
just fix skew, it removes the shuffle of the large side entirely, nothing
about `branch_code` needs to be partitioned across executors once
`branches` already lives on every one of them. Less shuffle volume is very
often the real reason a "tuned" query is faster, more than any change in
raw parallelism.

## 13. Partitioning: the calls that control it

| Call or setting | Controls | Notes |
|---|---|---|
| `spark.sql.files.maxPartitionBytes` | max size of one INPUT split when reading files | default 128MB |
| `spark.sql.shuffle.partitions` | number of REDUCE partitions after a shuffle | Section 8 |
| `repartition(n)` | full reshuffle to exactly n partitions | can increase or decrease, fixes skew |
| `coalesce(n)` | merges existing partitions in place | only decreases, no shuffle, does NOT fix skew |
| `repartitionByRange(n, col)` | reshuffles into n partitions ordered by a range on `col` | keeps sorted data roughly sorted across output files |

The distinction between `repartition()` and `coalesce()` matters more than
it looks: `coalesce()` is cheap exactly because it avoids a shuffle, but
that same lack of a shuffle means it can only merge existing partitions
together, it cannot fix an already-uneven distribution, only
`repartition()` can genuinely redistribute skewed data.

## 14. Memory: three OOM signatures

| OOM type | Typical signature | Typical fix |
|---|---|---|
| Driver OOM | driver process dies, often after a `.collect()` | never `.collect()` a big DataFrame, page results or write instead |
| Executor OOM | one executor dies, task retries, job eventually fails | fix the underlying skew first, Sections 4 through 7, only then raise memory |
| Overhead OOM | container killed by the cluster manager, not a normal Spark stack trace | raise `spark.executor.memoryOverhead`, not `spark.executor.memory` |

The overhead OOM is the one most often misdiagnosed, because the error
never shows up as a Spark or JVM stack trace, it shows up in the cluster
manager's own logs instead, and it is the most common surprise for a team
moving a PySpark-heavy job onto a cluster sized for a JVM-only workload.

## 15. A debugging checklist

1. Find the slowest STAGE inside the slowest job, Section 2.
2. Check that stage's shuffle read/write bytes, large relative to source
   size means shuffle-bound.
3. Check `memoryBytesSpilled` and `diskBytesSpilled`, non-zero means
   spill-bound, Section 11.
4. Check that stage's task duration, max versus median, a big gap means
   skew-bound, Sections 4 through 7.
5. Apply the ONE fix that matches what you found, then re-measure the same
   way before trying a second fix.

## 16. Join tuning: hints

| Hint | Forces | Use when |
|---|---|---|
| `F.broadcast(df)` or `/*+ BROADCAST(t) */` | broadcast hash join | one side is small, default threshold 10MB |
| `/*+ MERGE(t1, t2) */` | sort-merge join | both sides are large, usually already the default |
| `/*+ SHUFFLE_HASH(t) */` | shuffle hash join | one side fits in memory per partition but is over the broadcast threshold |

A join hint documents intent as much as it forces a plan. Even when the
optimiser would already have chosen a broadcast join, writing
`F.broadcast(accounts)` explicitly, as every lab in this course does,
means the next person reading the code does not have to guess.

## 17. Caching, briefly

`.cache()` (`MEMORY_AND_DISK`, its default storage level) keeps a
DataFrame's computed result around across multiple actions, instead of
recomputing its full lineage every time. Worth it once the same DataFrame
feeds two or more actions, like `Lab 14`'s Step 1 caching `skewed` before
both counting it and grouping it. Not worth it for a DataFrame used only
once, caching still pays the cost of computing and storing it, with
nothing to amortise that cost against. Always `.unpersist()` once a cached
DataFrame is no longer needed, `Lab 14` does this right after Step 4.

## 18. Configuration that actually matters

| Setting | Default | Change it when |
|---|---|---|
| `spark.sql.shuffle.partitions` | 200 | almost always, size it to your data, this course sets 8 |
| `spark.sql.adaptive.enabled` | true, Spark 3.2+ | leave on, see Section 9 |
| `spark.sql.autoBroadcastJoinThreshold` | 10MB | raise deliberately for a known-safe, slightly bigger table |
| `spark.sql.files.maxPartitionBytes` | 128MB | lower for many small files needing more parallelism |
| `spark.sql.sources.partitionOverwriteMode` | static | set `dynamic` before any job that should replace only the partitions it wrote, see Lab 04 |
| `spark.executor.memory` | cluster default | size to the biggest single task's real working set |
| `spark.sql.parquet.compression.codec` | snappy | set `zstd` when storage cost matters more than a small write-time cost |

## The lab

`labs/14_lab_tuning.py`:

| Step | Shows |
|---|---|
| 1 | The skew: BR011's share of every branch-keyed join |
| 2 | Shuffle partition count, 200 vs 8, timed |
| 3 | Skew measured directly with `spark_partition_id()` |
| 4 | Salting: row count unchanged, skew ratio improved |
| 5 | `get_spark(aqe=False)` vs `get_spark(aqe=True)`, same query |
| 6 | Small files: 40 files vs 3, same read, timed both ways |

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| Adding executor memory before checking for skew | guessing instead of measuring | check task duration max vs median first, Section 5, memory rarely fixes skew alone |
| Leaving `shuffle.partitions` at 200 on small data | never revisited Spark's factory default | size it to the data, or trust AQE's coalescing, Section 9 |
| Assuming salting alone will show a big wall-clock win on a laptop | forgetting scale matters | trust the skew RATIO on small data, Section 6, wall-clock needs real cluster parallelism to show clearly |
| Writing with `repartition()` right before a write, without thinking about file count | not connecting partition count to file count | `coalesce()` before a write when partition count was set for compute, not for output file size |
| Turning AQE off in production "to be safe" | copying this module's teaching demos, which disable it deliberately to isolate an effect | leave AQE on everywhere except a deliberate isolated test like this lab's |

## Exercises

1. Run the lab and record the skew ratio before and after salting from
   your own run. Is it close to this doc's Section 6 numbers?

2. Change Step 2's shuffle partition counts from 200/8 to 400/4 and
   re-run. Does the gap between them grow, shrink, or stay about the same?

3. In Step 6, change `repartition(40)` to `repartition(100)` and re-run.
   Does the read+filter time for the "many files" case get worse?

4. Using Section 2's symptom table, write down what you would check FIRST
   if a real AtliQ Bank job suddenly took 4 hours instead of its usual 30
   minutes, before changing any setting.

## Key points

- Measure first, identify the specific cause, apply one fix, re-measure.
  Guessing wastes a deploy cycle and sometimes makes things worse.
- BR011's skew is real and by design in this course's data, and it shows
  up differently depending on whether the small side of a join can
  broadcast, Sections 4 and 7.
- Salting fixes the skew RATIO, provably, even when wall-clock time barely
  moves on a small, laptop-scale run.
- AQE coalesces shuffle partitions at runtime, after seeing real data
  size, something a static plan can never do. Leave it on.
- Small files cost a fixed per-file overhead on every read, `coalesce()`
  before a write is the simple fix, a table-format compaction command is
  the ongoing one, see Module 11.
