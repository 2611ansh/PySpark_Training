# Module 10: Window functions

After this module you can write a correct window spec, avoid the
default frame trap, and use window functions to solve five real banking
problems: deduplication, running balance, velocity checks, and
reactivation detection.

## Why this matters in a bank

Almost every interesting question a bank asks about a transaction feed
is a window function question: what is this account's balance right
now, has this account moved unusually fast, when did this account last
do anything at all. This is the module where the rest of the course
comes together on real analytics, so the lab spends more time here than
almost anywhere else.

## The window spec and its frame

A window spec has three parts: `PARTITION BY`, which rows see each
other, `ORDER BY`, what order, and a FRAME, how far back and forward
from the current row the calculation looks.

```python
w = Window.partitionBy("account_id").orderBy("txn_ts")
```

That alone is not enough to know what a function like `sum()` will
compute. The FRAME decides that, and Spark picks a default frame you did
not ask for the moment you add an `ORDER BY`. The next two sections are
both about that one fact.

### ROWS vs RANGE, and why ties matter

`ROWS` counts PHYSICAL rows up to the current one. `RANGE` counts every
row whose ORDER BY VALUE is less than or equal to the current row's
value, tied values included, regardless of their physical position.

```python
w_rows = Window.partitionBy("account_id").orderBy("amount") \
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
w_range = Window.partitionBy("account_id").orderBy("amount") \
    .rangeBetween(Window.unboundedPreceding, Window.currentRow)
```

On four rows for one account with amounts `100, 100, 200, 300`:

| amount | sum_rows | sum_range |
|---|---|---|
| 100 | 100 | 200 |
| 100 | 200 | 200 |
| 200 | 400 | 400 |
| 300 | 700 | 700 |

The two tied `100` rows disagree under `ROWS`, 100 then 200, because
`ROWS` only cares about physical position. They AGREE under `RANGE`,
both 200, because `RANGE` treats every row with the same order value as
arriving "at the same time". Whenever the ORDER BY column can have
ties, and a timestamp with second precision on a busy feed absolutely
can, this difference is not academic.

## The default frame trap

This is the single most common window function mistake, and it is
silent: no error, no warning, just a wrong number.

```python
w_no_order = Window.partitionBy("account_id")
w_with_order = Window.partitionBy("account_id").orderBy("txn_ts")

txns.withColumn("avg_all", F.avg("amount").over(w_no_order))
txns.withColumn("avg_running_TRAP", F.avg("amount").over(w_with_order))
```

With NO `ORDER BY`, the default frame is the WHOLE partition, so
`avg_all` really is that account's overall average, the same value on
every row. The MOMENT an `ORDER BY` is added, even just to make ties
stable or to satisfy a function that requires ordering like `lag()`, the
default frame silently changes to `RANGE UNBOUNDED PRECEDING TO CURRENT
ROW`. `avg()` quietly becomes a RUNNING average, a completely different
number, with no error to flag it.

```python
avg_all           955.34   955.34   955.34   955.34   955.34
avg_running_TRAP   393.84  1952.15  1468.66  1142.66  1044.01
```

The fix is to be explicit whenever an aggregate should cover the WHOLE
partition, not a running total, even if you also need an `ORDER BY` for
another function in the same query:

```python
Window.partitionBy("account_id").orderBy("txn_ts") \
    .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
```

## Ranking: row_number, rank, dense_rank

Three ranking functions, three different answers on tied values, all
using the same window spec.

```python
w = Window.partitionBy("account_id").orderBy(F.desc("amount"))
ranked = (txns
    .withColumn("rn", F.row_number().over(w))
    .withColumn("rk", F.rank().over(w))
    .withColumn("drk", F.dense_rank().over(w)))
```

| Function | Two tied rows get | The rank after a tie |
|---|---|---|
| `row_number()` | different numbers, 1 and 2, broken arbitrarily by physical order | continues normally, 3 next |
| `rank()` | the same number, both get 1 | skips: the next distinct value gets 3, not 2 |
| `dense_rank()` | the same number, both get 1 | does not skip: the next distinct value gets 2 |

`row_number()` is what the dedup and QUALIFY-replacement patterns in
this course use, because it guarantees exactly one row per partition
gets `= 1`. `rank()` and `dense_rank()` matter when you want to know
someone's actual COMPETITION rank, for example "this branch is the 3rd
busiest", where ties should share a place.

## Offset functions: lag, lead, first, last

`lag()` looks backward, `lead()` looks forward, both by a number of ROWS
within the partition's order, defaulting to one row:

```python
w = Window.partitionBy("account_id").orderBy("txn_ts")
with_neighbours = (deduped
    .withColumn("prev_amount", F.lag("amount").over(w))
    .withColumn("next_amount", F.lead("amount").over(w))
    .withColumn("first_amount", F.first("amount").over(w))
    .withColumn("last_amount", F.last("amount").over(w)))
```

`first()` and `last()` need the same frame caution as any other
aggregate: with the default frame after an `ORDER BY`, `last()` returns
the CURRENT row's own value, not the partition's true last value, which
surprises almost everyone the first time. Use an explicit
`rowsBetween(unboundedPreceding, unboundedFollowing)` when you want the
partition's actual first or last value, not a running one.

## Deduplicating with row_number()

This course's transaction feed replays about 0.4% of rows verbatim.
`row_number()`, partitioned by the business key, keeps exactly one row
per key:

```python
dedup_window = Window.partitionBy("txn_id").orderBy(F.monotonically_increasing_id())
deduped = (txns.withColumn("rn", F.row_number().over(dedup_window))
    .filter("rn = 1").drop("rn"))
```

`ORDER BY monotonically_increasing_id()` here just breaks ties
consistently; since the duplicate rows are EXACT copies of each other,
which one survives does not matter. When duplicates are NOT exact
copies, for example two versions of the same txn_id with different
`status`, order by whatever column tells you which version is more
recent or more trustworthy instead, so `rn = 1` keeps the right one on
purpose, not by accident.

## Running account balance

The classic accumulating window: CREDIT adds, DEBIT subtracts, ordered
by time, summed from the start of the account's history to the current
row.

```python
w_balance = Window.partitionBy("account_id").orderBy("txn_ts") \
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)

signed = deduped.withColumn("signed_amount",
    F.when(F.col("txn_type") == "CREDIT", F.col("amount")).otherwise(-F.col("amount")))
balances = signed.withColumn("running_balance", F.sum("signed_amount").over(w_balance))
```

This is `ROWS`, not `RANGE`, and deliberately so: two transactions at
the exact same timestamp on the same account are still two separate
events that both affect the balance, one after the other, not one
combined event. Deduplicate first, always, before computing a running
balance. Duplicate rows are DOUBLE money moving in this calculation, not
a cosmetic issue.

## Balance as of a given date

The same running balance answers a second, equally common question:
what was this account's balance on a specific past date, not just its
balance right now.

```python
as_of = "2026-09-02"
w_latest = Window.partitionBy("account_id").orderBy(F.desc("txn_ts"))
balance_as_of = (balances
    .filter(f"txn_ts <= '{as_of} 23:59:59'")
    .withColumn("rn", F.row_number().over(w_latest))
    .filter("rn = 1")
    .select("account_id", "running_balance"))
```

Filtering first, then keeping each account's most recent remaining row
with `row_number()`, answers "as of" questions without recomputing
anything: the running balance column already has the right value
sitting in it, the filter and rank just pick out the right row.
`groupBy(...).agg(F.last(...))` looks like a shortcut for the same
thing, but `last()` inside a plain aggregate has no guaranteed row
order to work from and can silently return the wrong row; `row_number()`
does not have that problem, because its order is explicit.

## Velocity check: transactions in the last 10 minutes

A velocity check needs a real TIME window, not a fixed number of rows.
Ten transactions in ten minutes is suspicious; ten transactions spread
across three days is not, even though both are "the last 10 rows".
`RANGE`, with a number of SECONDS as the bound, gives a real trailing
time window:

```python
w_velocity = Window.partitionBy("account_id").orderBy("txn_epoch").rangeBetween(-600, 0)
velocity = (deduped.withColumn("txn_epoch", F.col("txn_ts").cast("long"))
    .withColumn("txns_last_10min", F.count("*").over(w_velocity)))
alerts = velocity.filter("txns_last_10min >= 3")
```

`txn_epoch` casts the timestamp to seconds since 1970, an ordinary
number `RANGE` can do arithmetic on. `-600` to `0` means "from 600
seconds before this row's timestamp, up to this row". A `ROWS` frame
here would be wrong: it would count a fixed number of ROWS regardless of
how much real time they span, which for an account with gaps in its
activity gives a meaningless answer.

## One more case: reactivation after a dormancy gap

`lag()` looks at THIS partition's previous row, in the order you
specified. The gap since then is itself a signal worth measuring:

```python
w_account_time = Window.partitionBy("account_id").orderBy("txn_ts")
gaps = deduped.withColumn("prev_txn_ts", F.lag("txn_ts").over(w_account_time)) \
    .withColumn("gap_hours",
        (F.col("txn_ts").cast("long") - F.col("prev_txn_ts").cast("long")) / 3600)
reactivations = gaps.filter("gap_hours > 24")
```

On this course's three day feed, a gap over 24 hours, a full day of
silence followed by activity, flags about 0.4% of rows, a small enough
set to be a real signal rather than routine overnight inactivity. The
right threshold in production depends entirely on the account type: a
dormant savings account reactivating after months is a very different
signal from a current account that is simply quiet on weekends.

## The lab

`labs/10_lab_windows.py`, 75 minutes.

| Step | What it shows |
|---|---|
| 1 | A window spec and its frame: ROWS vs RANGE, on tied values |
| 2 | The default frame trap: ORDER BY silently changes the frame |
| 3 | Deduplicating the duplicate txn_id rows with row_number() |
| 4 | Running account balance |
| 5 | Velocity check: transactions per account in the last 10 minutes |
| 6 | One more case: reactivation after a dormancy gap, with lag() |

Run it:

```bash
./run.sh labs/10_lab_windows.py
```

The lab reads the RAW transaction feed, not Lab 04's silver layer:
silver is already deduplicated, and step 3 needs the duplicate txn_id
rows still present to deduplicate them itself.

## Performance: every window is a shuffle unless the data already agrees

`PARTITION BY` means Spark has to get every row for the same key onto
the same worker before it can compute anything, which is a shuffle,
exactly like a `groupBy`. Two things make this expensive in practice.

| Problem | What happens |
|---|---|
| No `PARTITION BY` at all | Spark treats the WHOLE DataFrame as one partition, one worker does all the work, everyone else sits idle |
| One key dominates, e.g. `BR011`'s 22% of accounts | that one worker does far more work than the rest, the whole stage waits for it |

Pre-aggregating before a window function, when the final answer does not
need row-level detail, avoids shuffling the full row set at window-function
time:

```python
daily_totals = txns.groupBy("account_id", "posting_date").agg(F.sum("amount").alias("day_total"))
w = Window.partitionBy("account_id").orderBy("posting_date")
running = daily_totals.withColumn("running_total", F.sum("day_total").over(w))
```

Running the window over one row per account per day is far cheaper than
running it over every individual transaction, when a daily granularity
answers the question.

## Window functions in SQL syntax

Every window function in this module has a SQL equivalent, and named
windows avoid repeating the same `PARTITION BY ... ORDER BY ...` several
times in one query:

```sql
SELECT account_id, txn_ts, amount,
       SUM(amount) OVER w AS running_total,
       ROW_NUMBER() OVER w AS rn
FROM v_txns
WINDOW w AS (PARTITION BY account_id ORDER BY txn_ts)
```

## Common mistakes

| Mistake | Real cause | Fix |
|---|---|---|
| An average that should be constant per group changes row to row | the default frame trap: an `ORDER BY` was added, silently switching the frame | add an explicit `rowsBetween(unboundedPreceding, unboundedFollowing)` whenever the aggregate should cover the whole partition |
| A running balance is double what it should be | duplicate rows were not removed before the balance calculation | always dedup with `row_number()` before any running total |
| A velocity check flags almost every account | used `ROWS` instead of `RANGE` for a time-based window, counting a fixed number of rows regardless of the time they span | use `rangeBetween` with a numeric, time-based bound, on a numeric column like an epoch |
| `row_number()` keeps the WRONG version of a duplicate | ordered by an arbitrary column when the duplicates were not exact copies | order by whichever column identifies the correct version to keep, for example the latest status |
| A window function job is far slower than expected | no `PARTITION BY`, or a partition key with heavy skew, like the 22% branch in this course's data | check `.groupBy(partition_key).count()` for skew before trusting a window's runtime |

## Exercises

1. Change the velocity check's window from 10 minutes to 2 minutes.
   Report how the number of alerted accounts changes, and explain in
   one sentence why a shorter window should always flag fewer or the
   same number of accounts, never more.

2. Compute each account's running COUNT of transactions, not running
   balance, using the same `ROWS UNBOUNDED PRECEDING` frame. Confirm the
   final row's count for a sample account matches that account's total
   transaction count from a plain `.groupBy("account_id").count()`.

3. Rewrite the reactivation query to only flag a gap as a reactivation
   if the transaction that ends the gap is CREDIT, on the idea that a
   dormant account suddenly receiving money is a more specific signal
   than any transaction at all. Report how the alert count changes.

4. Using the "one more case" pattern, build a new check: flag any
   account whose SINGLE transaction is more than 5x its own average
   transaction amount, using `avg()` over the whole partition, the
   correct, explicit frame from the default frame trap section.

## Key points

- ROWS counts physical rows. RANGE counts by order value, so tied values move together. Pick deliberately.
- Adding an ORDER BY silently changes the default frame. Be explicit with rowsBetween whenever an aggregate should cover the whole partition.
- Always deduplicate with row_number() before a running balance, or duplicates become double-counted money.
- A velocity or time-based check needs RANGE on a numeric time column, not ROWS.
- Every PARTITION BY is a shuffle. Check for skew, and pre-aggregate when row-level detail is not the actual question.
