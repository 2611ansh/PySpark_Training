# Module 06: RDDs and UDFs

After this module you can say when an RDD is still the right tool, prove
`reduceByKey` beats `groupByKey` with real numbers, and pick the right
kind of UDF instead of reaching for a Python UDF by habit.

## Why this matters in a bank

Most PySpark code in this course never touches an RDD or writes a UDF.
The DataFrame API and its built-in functions cover almost everything.
But two situations still come up in a bank's Spark jobs: a feed in a
format no DataFrame reader understands, like a fixed-width mainframe
extract, and a scoring rule that genuinely needs a Python or numpy
function with no Spark built-in equivalent, like a model someone already
wrote and validated in pandas. This module is about handling both
without slowing every job down by accident. Knowing the ladder in this
module, built-in, `expr()`, pandas UDF, plain Python UDF, is the single
habit most likely to save a slow pipeline from a full rewrite.

## What an RDD actually is

An RDD, Resilient Distributed Dataset, is a distributed list of Python
objects. No columns, no schema, no query optimiser. Every DataFrame is
built on an RDD underneath, but the DataFrame API adds a schema and a
planner on top that make it far faster for anything row-and-column
shaped.

```python
numbers = sc.parallelize(range(1, 11), 4)     # spread over 4 partitions
evens = numbers.filter(lambda n: n % 2 == 0)
squared = evens.map(lambda n: n * n)
squared.collect()                              # [4, 16, 36, 64, 100]
```

`map` and `filter` on an RDD run arbitrary Python, one element at a
time. That flexibility is also the cost: Spark cannot see inside a
Python lambda the way it can see inside `F.col("amount") > 50000`, so it
cannot push down, reorder, or skip any of it.

### Every DataFrame has one underneath

`df.rdd` gives you the DataFrame's rows as Python `Row` objects. It is
slow for exactly the reason above: Spark has to leave its fast, columnar
in-memory format and box every row as a Python object first.

```python
sample_df = spark.range(5).withColumn("sq", F.col("id") * F.col("id"))
sample_df.rdd.map(lambda row: row["sq"]).collect()   # [0, 1, 4, 9, 16]
```

Use `df.rdd` to understand what is happening underneath a DataFrame, not
as a normal part of a pipeline. If you find yourself reaching for it in
real code, there is almost always a DataFrame built-in that does the
same job faster.

## When you still genuinely reach for an RDD

The one common case in a bank: a format that is not rows and columns at
all. A fixed-width mainframe extract, one field per character range, has
no delimiter for a DataFrame reader to split on.

```python
mainframe_line = "AC100234SAVINGS   00125000"
account_id = mainframe_line[0:8]
balance = int(mainframe_line[18:]) / 100
```

Parse lines like that with `sc.textFile(...).map(...)`, turn the result
into tuples or dicts, and only then build a DataFrame with
`spark.createDataFrame(parsed_rdd, schema)`. The RDD's job is just to
get you to a schema Spark can optimise around; it should not be where
the rest of the pipeline lives.

The other common case: an expensive setup cost that should happen ONCE
per worker, not once per row, for example opening a connection to a
scoring service. `mapPartitions` hands you an iterator over an entire
partition, so the setup runs once and every row in that partition reuses
it:

```python
def score_partition(rows):
    client = open_scoring_connection()      # once per partition, not once per row
    for row in rows:
        yield (row.txn_id, client.score(row.amount))

scored = txns.rdd.mapPartitions(score_partition)
```

A plain `.map()` would open a new connection for every single row.

## reduceByKey vs groupByKey

Both compute the same thing here: a total amount per account. They move
very different amounts of data across the network to get there.

```python
account_amount = pairs.map(lambda f: (f[1], float(f[3])))   # (account_id, amount)
reduced = account_amount.reduceByKey(lambda a, b: a + b)
grouped = account_amount.groupByKey().mapValues(sum)
```

| Method | What happens on each partition first |
|---|---|
| reduceByKey | sums ITS OWN keys locally, then sends ONE number per key across the network |
| groupByKey | sends EVERY row for a key across the network, then sums on the receiving side |

On this course's transaction feed, the lab measures this directly using
Spark's own UI, not an estimate:

| Method | Shuffle bytes measured |
|---|---|
| reduceByKey | about 443,000 |
| groupByKey | about 1,296,000, roughly 3x more |

### Measuring shuffle bytes yourself

The numbers above are not an estimate. Spark's own UI, the one at
`http://localhost:4040` while a job runs, keeps a REST API with exactly
this information per stage. The lab reads it directly:

```python
import json, urllib.request
ui, app_id = sc.uiWebUrl, sc.applicationId
stages = json.load(urllib.request.urlopen(f"{ui}/api/v1/applications/{app_id}/stages"))
shuffle_bytes = sum(s.get("shuffleWriteBytes", 0) for s in stages if s["stageId"] > before_max)
```

`before_max` is just the highest stage id seen before the action ran, so
the sum only counts stages THIS action produced. The same technique
works for any job, not just this lab, whenever "trust me, it shuffles
less" needs a real number behind it instead of a guess.

Both give the same answer, up to the last few decimal places: adding the
same floating point numbers in a different order can change the tail end
of a total, which is why the lab rounds to paise before comparing. The
rule: `reduceByKey` (or `aggregateByKey`, `combineByKey` for anything
more complex than a sum) whenever the operation can be combined locally
before it crosses the network. `groupByKey` only when you truly need
every individual value together, for example to compute a median.

## The UDF preference ladder

Four ways to compute the same rule, in the order you should try them.
The rule for this module: `amount > 50000 AND channel in (POS,
NETBANKING, IMPS)` marks a transaction HIGH risk, everything else LOW.

### 1. A built-in function, always try this first

```python
txns.withColumn("risk", F.when(
    (F.col("amount") > 50000) & F.col("channel").isin(HIGH_RISK_CHANNELS), "HIGH"
).otherwise("LOW"))
```

Built-ins run inside the JVM, in Spark's own columnar format. No
serialising to Python, no leaving the JVM, no per-row overhead. If a
built-in can express the rule, nothing else in this ladder beats it.

### 2. `expr()`, the same built-ins as a SQL string

```python
txns.withColumn("risk", F.expr(
    "CASE WHEN amount > 50000 AND channel IN ('POS','NETBANKING','IMPS') "
    "THEN 'HIGH' ELSE 'LOW' END"))
```

Same plan, same speed as a built-in. Reach for `expr()` when the
condition is naturally a SQL string, for example when it comes from a
rules table or a config file instead of being hardcoded.

### 3. A pandas UDF, for real vector math

```python
@F.pandas_udf(StringType())
def risk_score_pandas(amount: pd.Series, channel: pd.Series) -> pd.Series:
    is_high = channel.isin(HIGH_RISK_CHANNELS)
    return pd.Series(["HIGH" if h and a > 50000 else "LOW" for a, h in zip(amount, is_high)])
```

A pandas UDF gets a whole pandas Series per batch, not one value at a
time, moved between the JVM and Python using Apache Arrow. Reach for
this only when the logic genuinely needs numpy or pandas, for example a
statistical function with no Spark equivalent. It needs Arrow, and Arrow
is sensitive to the exact JDK build on the machine running it. See
"Common mistakes" below before you rely on this on a room full of
different laptops.

### 4. A plain Python UDF, the last resort

```python
def risk_score_row(amount, channel):
    return "HIGH" if amount > 50000 and channel in HIGH_RISK_CHANNELS else "LOW"

risk_score_udf = F.udf(risk_score_row, StringType())
txns.withColumn("risk", risk_score_udf(F.col("amount"), F.col("channel")))
```

A plain Python UDF serialises EVERY ROW to Python and back, one row at a
time. It is correct, and it is the slowest option on this list by a wide
margin once the data is large. Use it only when nothing above can
express the rule at all.

## The benchmark: same score, four ways

Timed on this course's 180,720 row transaction feed, two cores:

| Preference | Seconds |
|---|---|
| 1 built-in | 0.20 |
| 2 expr() | 0.28 |
| 3 pandas UDF | 0.20 |
| 4 python UDF | 0.14 |

Your own numbers will differ run to run, this is a tiny dataset on a
laptop. The pattern that matters is not any single number here, it is
what happens as the data grows: built-in and `expr()` scale with Spark's
own execution engine, a pandas UDF scales close to that once Arrow batch
sizes are tuned, and a plain Python UDF's per-row cost gets steadily
worse the bigger the table gets. On a real multi-million row table the
gap between built-in and a plain Python UDF is usually 10x or more, not
the small gap you see on a laptop-sized sample.

## Converting between RDD and DataFrame

Two directions, both with a real cost.

```python
rdd_of_rows = df.rdd                                  # DataFrame -> RDD: boxes every row as a Python object
df_again = spark.createDataFrame(rdd_of_rows, schema)  # RDD -> DataFrame: needs an explicit schema back
```

Neither direction is free. `df.rdd` leaves Spark's columnar format
behind, and rebuilding a DataFrame from an RDD needs a schema, the same
way reading a CSV does. Round-tripping through an RDD in the middle of
an otherwise pure DataFrame pipeline is a common, avoidable source of
slowdown, usually left behind from code ported from an older Spark
version.

## Registering a UDF for use in SQL

Every UDF shown so far is called from the DataFrame API. The same
function works from `spark.sql(...)` once registered:

```python
spark.udf.register("risk_score_sql", risk_score_row, StringType())
spark.sql("SELECT txn_id, risk_score_sql(amount, channel) AS risk FROM v_txns")
```

The performance ladder does not change just because the call now looks
like SQL. A plain Python UDF registered this way is exactly as slow as
one called from `.withColumn(...)`, because it is the same function.

## UDF correctness traps

Wrong declared return type gives silent NULLs, not an error:

```python
@F.udf(StringType())        # declared as returning a string
def bad_udf(x):
    return x * 2            # actually returns a number

df.withColumn("y", bad_udf(F.col("id"))).show()   # y is NULL for every row, no exception
```

An exception inside a UDF kills the whole Spark TASK, not just the one
bad row:

```python
@F.udf(StringType())
def risky(amount):
    return "HIGH" if amount > 50000 else "LOW"    # crashes the task if amount is None

# fix: handle the edge case inside the UDF itself
@F.udf(StringType())
def safe(amount):
    if amount is None:
        return "UNKNOWN"
    return "HIGH" if amount > 50000 else "LOW"
```

A non-deterministic UDF, for example one that calls `random()`, can be
recomputed more than once for the same row when Spark retries a task,
producing a different answer the second time. Mark it explicitly if that
matters: `my_udf.asNondeterministic()`, and be aware Spark will avoid
some optimisations, like reusing the result across a filter and a
select, once a UDF is marked this way. None of this applies to built-ins
or `expr()`: Spark already knows exactly what they do.

## The lab

`labs/06_lab_rdd_udf.py`, 60 minutes.

| Step | What it shows |
|---|---|
| 1 | What an RDD is: parallelize, map, filter, and a DataFrame's own .rdd |
| 2 | reduceByKey vs groupByKey, with the shuffle bytes each one really moved |
| 3 | The recurring example: a risk score, defined once |
| 4 | Preference 1: a built-in function |
| 5 | Preference 2: expr() |
| 6 | Preference 3: a pandas UDF |
| 7 | Preference 4, last resort: a plain Python UDF, then all four, timed |

Run it:

```bash
./run.sh labs/06_lab_rdd_udf.py
```

The pandas UDF step is wrapped in a try/except. Different laptops in the
room can have different JDK builds, and Arrow, which pandas UDFs need,
is sensitive to that. If it is skipped on your machine, the built-in and
`expr()` steps still prove the main point of the ladder.

## Common mistakes

| Mistake | Real cause | Fix |
|---|---|---|
| A pandas UDF throws `UnsupportedOperationException` mentioning Arrow or `DirectByteBuffer` | the JVM's Java version and the Arrow library it shipped with do not agree | try `--add-opens=java.base/java.nio=ALL-UNNAMED` on the driver's Java options, or use a matching JDK build |
| A plain Python UDF is far slower than expected, even on a small table | Arrow was not used, or a batch-friendly alternative existed and was not used | check whether the same rule can be written with `F.when`, `expr()`, or a pandas UDF first |
| Two runs of `reduceByKey` vs `groupByKey` give "different" totals | comparing floats for exact equality, when the two methods sum in a different order | round before comparing, or compare with a small tolerance |
| A UDF returns NULL for every row, no error raised | the declared return type does not match what the Python function actually returns | log a few of the function's raw Python outputs and check them against the declared type by hand |
| `df.rdd` shows up in a hot path and the job is slow | reaching for RDD methods out of habit from an older codebase | replace with the DataFrame equivalent; almost everything commonly done on `df.rdd` has one |

## Exercises

1. Change the risk rule to also flag `channel = 'RTGS'` as automatically
   HIGH risk, in all four implementations. Confirm all four still agree
   on the total count of HIGH rows.

2. Time `reduceByKey` and `groupByKey` again, this time computing the
   MAXIMUM amount per account instead of the sum. Does the shuffle byte
   gap between the two get smaller, bigger, or stay about the same?
   Explain why in one sentence.

3. Break the pandas UDF on purpose: declare it `IntegerType()` while the
   function still returns strings. Run it and describe what you see: an
   error, or silent NULLs.

4. Write a `mapPartitions` version of the risk score rule that also
   counts, per partition, how many rows it scored, printed once per
   partition instead of once per row. Compare its total runtime against
   the plain Python UDF from step 7 of the lab.

## Key points

- Reach for an RDD only for formats a DataFrame reader cannot parse. Everything else belongs in the DataFrame API.
- `reduceByKey` combines locally before shuffling. `groupByKey` shuffles everything, then combines. Prefer `reduceByKey`.
- The UDF ladder: built-in first, `expr()` next, a pandas UDF for real vector math, a plain Python UDF only as a last resort.
- A pandas UDF needs Arrow, and Arrow is sensitive to the JDK build. Guard it, do not assume it will just work on every machine.
- Time your own rule on your own data before trusting any benchmark on a small sample, the gap between options grows with data size.
