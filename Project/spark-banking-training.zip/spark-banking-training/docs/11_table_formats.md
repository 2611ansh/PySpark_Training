# Module 11: Table Formats, Delta Lake and Apache Iceberg

What you can do after this module: explain why plain Parquet cannot safely
support upserts, create a Delta table and an Iceberg table on the banking
data, MERGE corrections into both, time travel to an earlier version of
each, read each format's metadata files directly, and run the maintenance
command each format needs.

Run the labs on your own laptop, not in this sandbox. See "Running these
labs" below before you start.

```bash
./run.sh labs/11_lab_delta.py
./run.sh labs/11b_lab_iceberg.py
```

## Why this matters in a bank

Lab 04 built bronze, silver and gold as plain Parquet, and Lab 04's own
reprocessing step used dynamic partition overwrite to replace one day at a
time. That works well for a nightly batch load where nobody else is reading
the table while it writes. A bank rarely stays in that world for long.
Corrections arrive daily (`txn_updates.csv` again, this time as an upsert
target, not just a batch to append). Regulators ask for the exact state of
a table as of a specific date, for an audit. Multiple jobs read a table
while another job is still writing the next version of it. Plain Parquet
answers none of these cleanly: there is no transaction log, no version
history, and no upsert, only whole-file or whole-partition overwrites. Delta
Lake and Apache Iceberg exist to close that gap without leaving the
Parquet file format itself, both still store your data as Parquet files
underneath everything in this module.

## 1. Why plain Parquet is not enough: the MERGE problem

Lab 04 and Module 12 both handle `txn_updates.csv` the same way: an
anti-join to drop rows about to be replaced, then a union of the new
versions.

```python
base_minus_updated = base.join(updates.select("txn_id"), "txn_id", "left_anti")
merged = base_minus_updated.unionByName(updates)
```

This is exactly what a `MERGE` statement does under the hood. The honest
limitation: it rewrites the whole target (or every partition touched),
there is no log protecting a concurrent reader from seeing a half-written
result, and there is no one-command undo if the update was wrong. On a
single nightly job with no concurrent readers, that limitation rarely
bites. The moment two jobs touch the same table, or an auditor asks "what
did this table look like last Tuesday", it does.

## 2. What "ACID on a data lake" actually means

A relational database gets ACID for free from one server holding one lock
table. A data lake is just files in folders, there is no server. Delta and
Iceberg each add their own transaction log on top of the files to get the
same guarantee:

| Guarantee | What it means here |
|---|---|
| Atomicity | a write either fully commits (a new log entry appears) or it never happened, no half-written table |
| Consistency | every reader sees one complete version at a time, never a mix of old and new files |
| Isolation | a writer in progress does not affect what a concurrent reader sees |
| Durability | once committed, a version survives a crash |

Both formats get here the same general way: write new Parquet data files,
then commit a small metadata file that says "the table now consists of
exactly these files". Nothing is ever edited in place. A reader always
starts by reading the current metadata pointer, so it always sees one
complete, consistent set of files.

## 3. Delta Lake: the transaction log

Every Delta table is a folder of Parquet data files plus a `_delta_log/`
folder. Each write appends one JSON file to that log:

```
_delta_log/
  00000000000000000000.json   <- version 0, the first write
  00000000000000000001.json   <- version 1, e.g. after a MERGE
  00000000000000000002.json   <- version 2
```

Each JSON file lists the files added and removed by that commit, plus
statistics. A reader opens the log, replays it to find the current set of
live files, and reads only those. `Lab 11a`, Step 2, lists this folder
directly on the table this module builds.

## 4. Delta Lake hands-on

`get_spark(delta=True)` in `bank_session.py` adds the Delta jar, the
`io.delta.sql.DeltaSparkSessionExtension`, and points `spark_catalog` at
Delta's own catalog. Never configure this by hand inside a lab.

Create a table exactly like writing Parquet, only the format string
changes:

```python
txns.write.format("delta").mode("overwrite").partitionBy("status").save(path)
```

MERGE needs Delta's own table handle, `DeltaTable`, not a plain DataFrame:

```python
from delta.tables import DeltaTable

target = DeltaTable.forPath(spark, path)
(target.alias("t")
 .merge(updates.alias("s"), "t.txn_id = s.txn_id")
 .whenMatchedUpdate(set={"status": "s.status"})
 .whenNotMatchedInsertAll()
 .execute())
```

Time travel reads an older version straight off the log, no restore step
needed:

```python
spark.read.format("delta").option("versionAsOf", 0).load(path)
```

Maintenance is two separate commands, for two separate problems. `OPTIMIZE`
compacts many small Parquet files into fewer, bigger ones (Module 14
covers why small files cost time to read). `VACUUM` physically deletes
files no live version of the table references any more:

```python
target.optimize().executeCompaction()
spark.sql(f"VACUUM delta.`{path}` RETAIN 168 HOURS")   # 7 days, the safe production default
```

`Lab 11a` runs `VACUUM` with a retention of 0 hours. That is for this demo
only, so the very next command has something to delete. Running `VACUUM`
with a short retention in production can delete files a long-running query
or a time-travel read still needs.

## 5. Apache Iceberg: catalogs, manifests and snapshots

An Iceberg table lives in a **catalog**, so it is addressed as
`catalog.database.table`, like `local.silver.txns`, and almost every
operation is plain SQL rather than a DataFrame writer call.
`get_spark(iceberg=True)` points the catalog named `local` at
`data/warehouse/iceberg/` on disk, a "Hadoop catalog", the simplest kind,
with no separate metastore server to run.

Every write produces a **snapshot**, and Iceberg tracks the current
snapshot through a small tree of metadata files:

```
metadata/
  v1.metadata.json     <- points at the current snapshot
  snap-...-1.avro      <- a manifest LIST for that snapshot
  <uuid>-m0.avro        <- a manifest, listing actual data files
data/
  status=SUCCESS/...    <- the Parquet data files themselves
```

`metadata.json` is the one file every reader opens first, the same job
`_delta_log`'s latest entry does for Delta. `Lab 11b`, Step 2, lists this
folder directly.

## 6. Apache Iceberg hands-on

Create a table with `CREATE TABLE ... AS SELECT`, the natural SQL way to
build a table from an existing query:

```sql
CREATE OR REPLACE TABLE local.silver.txns
USING iceberg
PARTITIONED BY (days(txn_ts))
AS SELECT * FROM raw_txns
```

`MERGE INTO` reads almost exactly like standard SQL, because it is:

```sql
MERGE INTO local.silver.txns t
USING txn_updates s
ON t.txn_id = s.txn_id
WHEN MATCHED THEN UPDATE SET t.status = s.status
WHEN NOT MATCHED THEN INSERT *
```

Time travel reads a specific snapshot, found from the table's own
`.snapshots` metadata table:

```sql
SELECT snapshot_id, committed_at, operation FROM local.silver.txns.snapshots
```

```python
old = spark.read.option("snapshot-id", first_snapshot).table("local.silver.txns")
```

Maintenance is a `CALL` to a system procedure, one for compaction and one
for cleanup, the same two jobs Delta's `OPTIMIZE` and `VACUUM` do:

```sql
CALL local.system.rewrite_data_files(table => 'silver.txns')
CALL local.system.expire_snapshots(
  table => 'silver.txns', older_than => TIMESTAMP '2026-09-01 00:00:00', retain_last => 1)
```

## 7. Hidden partitioning, an Iceberg-specific idea

Lab 11a partitions the Delta table by an explicit `status` column, exactly
like Lab 04's Parquet tables. Lab 11b instead partitions by
`days(txn_ts)`, with no extra column at all. Iceberg tracks the partition
value from `txn_ts` itself inside its manifests, so a query filtering on
`txn_ts` gets partition pruning automatically, and nobody ever needs to
remember to also filter on a separate `dt` column, or risk a query that
filters `txn_ts` but forgets `dt` and silently scans everything. Delta
gained a similar feature, generated columns, later, but explicit partition
columns remain Delta's more common pattern in most real code you will see.

## 8. Concurrent writers: what actually happens

Both logs exist for more than convenience. They are what makes it safe for
two jobs to write to the same table at once. Say job A starts a MERGE while
job B starts an OPTIMIZE on the same table:

| Step | Delta | Iceberg |
|---|---|---|
| Both jobs read the current version | each sees the same starting log entry | each sees the same starting snapshot |
| Both jobs write new data files | independent, no conflict yet, files are never edited in place | same |
| Both jobs try to commit | one commit wins first | one commit wins first |
| The second commit | fails with a concurrent modification error, or Delta retries it against the new version if the change is compatible | fails, the engine typically retries against the new snapshot |

The practical result: a writer never corrupts another writer's work, worst
case it has to retry. A reader that started before either commit keeps
seeing its own consistent snapshot throughout, it never sees a half-merged,
half-optimized table. This is the same guarantee Section 2 named, made
concrete.

## 9. Schema evolution, briefly

A bank's transaction feed adds a column eventually, a new `merchant_id`
field, say. Both formats allow adding a column without rewriting existing
data:

```sql
-- Delta
ALTER TABLE delta.`data/warehouse/delta/txns` ADD COLUMN merchant_id STRING

-- Iceberg
ALTER TABLE local.silver.txns ADD COLUMN merchant_id STRING
```

Old Parquet files simply return `NULL` for the new column when read, no
rewrite needed. Iceberg's advantage here is real but narrow: it tracks
columns by an internal ID, not by name, so renaming a column is also safe,
old files still map to the same ID under the new name. Delta added
column mapping to support the same safe rename more recently; check the
Delta version in use before relying on it.

## 10. Running these labs on your laptop

Both labs need a one-time download from Maven Central:

| Lab | Jar | Approximate size |
|---|---|---|
| `11_lab_delta.py` | `io.delta:delta-spark_2.12:3.1.0` | 25 MB |
| `11b_lab_iceberg.py` | `org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.2` | 35 MB |

`spark.jars.packages` in `bank_session.py` triggers this download the first
time `get_spark(delta=True)` or `get_spark(iceberg=True)` runs. Spark
caches the jars in `~/.ivy2`, so only the very first run of each lab needs
internet, every run after that works offline. This training sandbox has no
Maven access, so `11_lab_delta.py` and `11b_lab_iceberg.py` cannot run
here. They were checked with `python -m py_compile` and every API call in
them is copied from a pipeline that ran successfully on the client's own
laptop.

## 11. Delta Lake vs Apache Iceberg

| | Delta Lake | Apache Iceberg |
|---|---|---|
| Metadata | a JSON log, `_delta_log/` | a metadata tree: `metadata.json`, manifest lists, manifests |
| Table address | a file path, or a catalog table name | always `catalog.database.table` |
| Partitioning | explicit columns you choose and maintain | hidden, tracked from any column's real value |
| MERGE | `DeltaTable.merge()`, a Python/Scala API | `MERGE INTO`, plain SQL |
| Time travel | `versionAsOf` / `timestampAsOf` | snapshot ID or timestamp, via `.snapshots` |
| Compaction | `OPTIMIZE` | `CALL system.rewrite_data_files` |
| Cleanup | `VACUUM` | `CALL system.expire_snapshots` |
| Engine support | strongest on Spark and Databricks | built engine-neutral: Spark, Trino, Flink, Snowflake all read it natively |
| Typical adopter | a Spark-first or Databricks-centric shop | a shop running more than one query engine over the same lake |

Neither is simply "better". The rest of a bank's estate usually decides:
Databricks already in use points to Delta, a mix of engines (Trino or
Snowflake alongside Spark) points to Iceberg. Both solve the same MERGE,
time travel and small-file problem this module opened with.

## The lab

`labs/11_lab_delta.py`:

| Step | Shows |
|---|---|
| 1 | Write transactions as a Delta table, version 0 |
| 2 | List the `_delta_log/` JSON commit files |
| 3 | MERGE the corrections from `txn_updates.csv` |
| 4 | `history()` and time travel back to version 0 |
| 5 | `OPTIMIZE` then `VACUUM` |

`labs/11b_lab_iceberg.py`:

| Step | Shows |
|---|---|
| 1 | `CREATE TABLE ... AS SELECT`, with hidden partitioning by `days(txn_ts)` |
| 2 | List the `metadata/` folder: metadata.json and manifests |
| 3 | `MERGE INTO` the corrections from `txn_updates.csv` |
| 4 | List snapshots, time travel to the first one |
| 5 | `rewrite_data_files` then `expire_snapshots` |

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| Configuring Spark inside the lab file with `.config()` calls | copying an old script that predates `bank_session.py` | always call `get_spark(delta=True)` or `get_spark(iceberg=True)`, never hand-configure |
| Calling `VACUUM` with a short retention on a real table | copying this module's `RETAIN 0 HOURS` demo line into production | use the 7-day default (`RETAIN 168 HOURS`) unless you are certain nothing needs the older files |
| Trying `MERGE INTO` syntax on a Delta table, or `DeltaTable.merge()` on an Iceberg table | assuming the two formats share one API | Delta's merge is a Python/Scala call, Iceberg's is SQL, see Section 11's table |
| Forgetting `iceberg` tables need a database created first | Delta tables are just a path, no `CREATE DATABASE` needed | `CREATE DATABASE IF NOT EXISTS local.silver` before the first `CREATE TABLE` |
| Assuming these labs will run in this sandbox | no Maven access here | run them on your own laptop with internet, see Section 10 |

## Exercises

1. In `11_lab_delta.py`, change the MERGE's `whenMatchedUpdate` to also set
   `amount`, not just `status`. Confirm `history()` still shows exactly one
   new version for the MERGE.

2. In `11b_lab_iceberg.py`, after Step 4's time travel, run
   `DESCRIBE TABLE local.silver.txns` and find the partition spec. Confirm
   it names `txn_ts`, not a separate `dt` column, the hidden partitioning
   from Section 7.

3. Without running either lab, read Section 4's `MERGE` code and Section
   6's `MERGE INTO` and write out, in your own words, which line in each
   corresponds to "an existing `txn_id` gets its status corrected" and
   which to "a new `txn_id` gets inserted".

4. Using Section 11's comparison table, decide which format AtliQ Bank
   should pick if its lake already has Databricks in production, and which
   it should pick if it also runs Trino for ad hoc analyst queries.
   Justify each from one row of the table.

## Key points

- Plain Parquet has no transaction log, so it has no safe MERGE, no time
  travel, and no undo. Delta and Iceberg add exactly that log on top of
  Parquet files, nothing about the underlying data format changes.
- Delta's log is a sequence of JSON commits in `_delta_log/`. Iceberg's is
  a tree of metadata, manifest lists and manifests, and it always lives
  behind a catalog.
- MERGE, time travel and maintenance exist in both formats. Delta's API is
  Python/Scala method calls, Iceberg's is close to plain SQL.
- Iceberg's hidden partitioning tracks the partition value from a real
  column, so a query never needs a separate partition column to filter on.
- Neither jar is available in this sandbox. Both labs were compile-checked
  and built from a pipeline proven on the client's own laptop, run them
  there.
