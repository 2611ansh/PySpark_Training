# Module 05: Data models for a lakehouse

After this module you can design a star schema for banking data, name the
right fact type for a table, and build a Slowly Changing Dimension Type 2
for a customer dimension.

## Why this matters in a bank

A bank's data warehouse gets audited. When a regulator asks "what was this
customer's KYC status on the day of this transaction", the honest answer
needs the dimension row as it looked THAT DAY, not as it looks today.

A model that only keeps the current row for each customer cannot answer
that question. That single gap is why SCD Type 2 exists, and why this
module spends most of its time on it.

| Real question a bank gets asked | Needs |
|---|---|
| "What was this customer's risk rating when this loan was approved?" | the dimension row as it was on the approval date |
| "Show every customer whose segment changed in Q1" | a full history of segment changes, with dates |
| "This account's branch shows differently in two reports, why?" | a reconciliation between the fact's branch key and the dimension's history |
| "Prove this customer's KYC status for the auditor" | the exact row, and the exact date range, it was true for |

Every one of these fails with a Type 1, current-row-only dimension. None
of them need anything more exotic than SCD Type 2 done correctly.

## The grain: the first question every table answers

The grain is one sentence: what does a single row mean? Every join, every
`GROUP BY`, every reconciliation depends on getting this right first.

| Table | Grain |
|---|---|
| fact_transactions | one row per txn_id |
| fact_branch_daily | one row per branch_code per posting_date |
| fact_loan | one row per loan_id, columns update as the loan moves |
| dim_customer (SCD2) | one row per customer_id PER VERSION |

Get the grain wrong and two symptoms follow. A join that fans out and
silently multiplies rows, or an aggregate that undercounts because rows
you thought were separate were actually duplicates of the same grain.

## The star schema shape

A star schema puts one wide fact table in the middle. Narrow dimension
tables surround it. The fact table holds foreign keys into the
dimensions and the numbers you aggregate. Dimensions hold the
descriptive columns you filter and group by.

```
                 dim_customer
                      |
   dim_branch --- fact_transactions --- dim_date
                      |
                 dim_account
```

| Piece | Holds | Changes |
|---|---|---|
| fact_transactions | txn_id, amounts, foreign keys | append-only, never updated |
| dim_customer | segment, risk_rating, kyc_status | tracked with SCD Type 2 |
| dim_account | account_type, open_date | rarely changes |
| dim_branch | branch_name, region | almost never changes |
| dim_date | one row per calendar date | never changes |

This shape is the same idea your team already calls staging, ODS, and
data mart. Staging lands the raw feed. The ODS is roughly your silver
layer: cleaned, deduplicated, one row per business key. The star schema
is the data mart on top of it, built for fast aggregation and easy
filtering, which in this course is gold.

## The three fact types, named

A fact table is not just "a big table with numbers in it". It follows
one of three well-known patterns, and mixing patterns inside one table
is how a fact table becomes unreadable.

| Fact type | Grain | How it changes | Example in this course |
|---|---|---|---|
| Transaction fact | one row per event | append-only | fact_transactions, one row per txn_id |
| Periodic snapshot | one row per (dimension, time bucket), even on a quiet day | a new batch of rows every period | gold/branch_daily from Lab 04, one row per branch per day |
| Accumulating snapshot | one row per case | the SAME row is updated as the case moves | loans.csv, one row per loan_id, outstanding and dpd change every month |

The test that tells them apart: transaction facts are never updated,
only appended to. Periodic snapshots always have the same row count per
period, whether anything happened or not (36 branches means 36 rows a
day, always). Accumulating snapshots are the only one of the three where
you go back and UPDATE an existing row.

A common mistake is building a "transactions" table that is secretly a
periodic snapshot, or an "accounts" table that tries to be both a
dimension and an accumulating snapshot fact at once. Decide the type
before you write a single column.

### The shape of each, in code

A transaction fact is one INSERT, forever. Nothing ever updates a row:

```python
fact_transactions.write.mode("append").partitionBy("posting_date").parquet(path)
```

A periodic snapshot OVERWRITES the whole period's rows, every run, even
if the numbers did not change, because the row for a quiet branch still
needs to exist:

```python
gold_today = silver.groupBy("branch_code", "posting_date").agg(F.count("*").alias("txn_count"))
gold_today.write.mode("overwrite").parquet(f"{WAREHOUSE}/gold/branch_daily")
```

An accumulating snapshot UPDATES the same row in place as milestones
happen, which on a lakehouse means reading the old row, changing the
columns that moved, and overwriting just that row, usually with a MERGE
(Module 11 covers MERGE on Delta and Iceberg):

```python
# loan_id LN500042 just missed a payment: dpd and status both move,
# loan_id itself and disbursed_date never do.
loans.filter("loan_id = 'LN500042'").select("loan_id", "dpd", "status").show()
```

## Slowly Changing Dimensions

A dimension changes over time. A customer's segment gets upgraded. Their
risk rating moves. The question SCD answers is: when that happens, do
you overwrite the old value, or keep both?

| Type | What happens to the old value | Use it when |
|---|---|---|
| Type 1 | overwritten, gone | the old value was a mistake, e.g. a typo in a name |
| Type 2 | kept, as a new row with its own date range | the old value was TRUE at the time, e.g. a segment change |
| Type 3 | kept, in one extra column, one prior value only | rare, only when one step of history is enough |

Banking dimensions are almost always Type 2. A transaction needs to join
to the customer as they were ON THAT DAY, and a Type 1 overwrite makes
that join permanently wrong for every transaction before the change.

## SCD Type 2 mechanics

Four columns turn a plain dimension into an SCD Type 2 dimension.

| Column | Meaning |
|---|---|
| surrogate_key | a new, unique key for every VERSION of a customer, not per customer |
| effective_from | the date this version became true |
| effective_to | the date this version stopped being true, NULL if still current |
| is_current | a shortcut so a query does not have to check effective_to IS NULL every time |

### Change detection: hash the tracked columns

Not every column is worth tracking. A typo fix to `full_name` does not
need a new dimension row. Pick the columns that matter to the business,
then fingerprint them:

```python
TRACKED = ["segment", "risk_rating", "kyc_status", "income_band"]
dim_customer = customers.withColumn(
    "row_hash", F.sha2(F.concat_ws("|", *TRACKED), 256))
```

Two rows with the same `row_hash` are, for SCD2 purposes, the same
version of the customer. Compare today's extract against the dimension's
CURRENT rows by joining on `customer_id` and comparing `row_hash`:

```python
compared = extract.alias("e").join(current.alias("c"), "customer_id", "left")
new_customers = compared.filter(F.col("c.customer_id").isNull())
changed = compared.filter(
    F.col("c.customer_id").isNotNull() & (F.col("e.row_hash") != F.col("c.row_hash")))
```

### The merge: expire, insert, keep

Three DataFrames, unioned into the new dimension:

```python
expired = (current.join(changed_ids, "customer_id")
    .withColumn("effective_to", F.lit(TODAY))
    .withColumn("is_current", F.lit(False)))

new_versions = (changed.select("e.*").unionByName(new_customers.select("e.*"))
    .withColumn("effective_from", F.lit(TODAY))
    .withColumn("effective_to", F.lit(None).cast("string"))
    .withColumn("is_current", F.lit(True)))

untouched = current.join(changed_ids, "customer_id", "left_anti")

dim_customer_v2 = untouched.unionByName(expired).unionByName(new_versions)
```

A changed customer now has two rows: the expired one, true from load 1
to today, and the new one, true from today onward with `effective_to`
still NULL. A query that filters `is_current = true` sees only the
second. A query that filters `effective_from <= '2026-03-01' AND
(effective_to IS NULL OR effective_to > '2026-03-01')` sees the row that
was true back in March, even though the customer has since changed.

## Querying an SCD Type 2 dimension

Two shapes of query cover almost everything a report needs.

The current view, for "what is true right now":

```python
current_customers = dim_customer_v2.filter("is_current = true")
```

The as-of view, for "what was true on a given date", which is the one
that answers every audit question in the table above:

```python
as_of_date = "2026-03-01"
point_in_time = dim_customer_v2.filter(
    f"effective_from <= '{as_of_date}' "
    f"AND (effective_to IS NULL OR effective_to > '{as_of_date}')")
```

Joining a fact table to a Type 2 dimension the RIGHT way means joining on
`customer_id` and the date range, not just `customer_id`. Joining on
`customer_id` alone, once a customer has more than one version, silently
duplicates every one of that customer's transactions, once per version.
That single mistake is the most common way an SCD2 dimension breaks a
downstream report.

## What SCD Type 2 does not solve

SCD Type 2 tracks the DIMENSION's history. It says nothing about the
FACT table's own timing. A transaction fact is already append-only and
never updated, so it does not need SCD logic at all: its grain, one row
per txn_id, already gives it a permanent, unambiguous history.

The two ideas get confused when a customer changes segment twice inside
one batch window, for example upgraded then downgraded on the same day
before the pipeline ran. This lab's merge only compares today's extract
against the dimension's CURRENT row, so it can only capture one change
per run. Catching every intermediate change would need the source
system to hand over a full change log, not just a daily snapshot, which
is a production concern well beyond a 45 minute lab.

## Why dim_branch and dim_date almost never need SCD2

Not every dimension earns the SCD2 treatment. `dim_branch` changes maybe
once a year, when a branch is renamed or its region is reorganised.
`dim_date` never changes at all, it is generated once. Building full
SCD2 machinery for either would be effort with no payoff.

| Dimension | Change frequency | Treatment |
|---|---|---|
| dim_customer | daily, segment and risk moves | SCD Type 2 |
| dim_account | rarely, mostly status flips | SCD Type 1 is usually enough |
| dim_branch | almost never | overwrite in place, or SCD2 only if the bank needs branch history for audits |
| dim_date | never, generated once | no SCD needed at all |

The lesson is not "always do SCD2". It is "know which dimensions the
business actually needs history for, and only pay the SCD2 cost there".
`TRACKED` in this lab's code is exactly that decision, made explicit as
a list of four column names.

## Sizing the dimension over time

This lab's simulated extract changed segment or risk_rating for about
7.6% of customers in one run (607 of 8,000). That number matters for
capacity planning, not just correctness.

| After this many daily runs | dim_customer rows, if ~7.6% change each time |
|---|---|
| 1 (initial load) | 8,000 |
| 30 | roughly 8,000 + 30 x 600, about 26,000 |
| 365 | grows every day, with no natural ceiling |

A Type 2 dimension grows forever unless something prunes it. In
practice, that something is usually "keep full history, but archive
versions older than the regulator's retention window to cold storage",
not deleting rows outright.

## Surrogate keys in a distributed system

The natural key, `customer_id`, is not enough on its own once a customer
can have several dimension rows. The surrogate key is what the fact
table actually joins to, and it must be unique per VERSION.

`F.monotonically_increasing_id()` is fine for a lab: it gives an
increasing, unique long per row, computed independently per partition,
so it needs no shuffle and no coordination between workers. It is not
guaranteed to be contiguous or stable across reruns, which is exactly why
production systems usually generate surrogate keys from a dedicated
sequence or an identity column in the target warehouse instead.

The natural key still matters. It is what today's extract arrives with,
and it is what step 5's join uses to find a customer's current version
in the first place. The surrogate key only takes over once the fact
table is ready to be built, as the column it actually joins on.

## The lab

`labs/05_lab_data_models.py`, 45 minutes.

| Step | What it shows |
|---|---|
| 1 | The grain, and the star schema around it |
| 2 | The three fact types, named, on real banking tables |
| 3 | dim_customer: the initial SCD Type 2 load |
| 4 | A changed extract lands: segment and risk_rating move for some customers |
| 5 | Detect NEW, CHANGED and UNCHANGED by comparing hashes |
| 6 | Apply the merge: expire, insert, keep |
| 7 | Prove it: the same customer_id now has two versions with real dates |

Run it:

```bash
./run.sh labs/05_lab_data_models.py
```

## Common mistakes

| Mistake | Real cause | Fix |
|---|---|---|
| A join fans out and row counts explode | joined to a dimension with more than one row per key, usually a stale SCD2 row | filter `is_current = true`, or join on the date range, not just the key |
| Every column triggers a "change" | hashing untracked columns like `full_name` or `onboarded_date` | only hash the columns the business actually wants history for |
| Two rows both show `is_current = true` | the merge inserted a new version without expiring the old one | always expire in the SAME write as the insert, from one merge, not two |
| `effective_to` is NULL on an old, closed-out version | the expire step used the wrong join key, or ran on the wrong DataFrame | join `current` to `changed_ids`, not `changed` to `current`, and check the row count matches |
| Surrogate keys collide after a rerun | `monotonically_increasing_id()` restarted from a low range on the new run | offset the new load's keys, or generate keys from a real sequence in production |
| A report double-counts a customer's transactions | fact joined to the dimension on `customer_id` alone, matching every version | join on `customer_id` AND the effective date range, or filter `is_current = true` first |
| The rule table finds a "change" every single run for the same customer | comparing against `dim_customer` instead of only its CURRENT rows | filter `current = dim_customer.filter("is_current = true")` before comparing hashes |

## Exercises

1. Add `full_name` to `TRACKED` and rerun the lab. Count how many
   customers now show as CHANGED. Explain in one sentence why that
   number is much higher and why that is a bad idea for this column.

2. Write a query against `dim_customer_v2` that returns a customer's
   segment as it was on `2026-02-01`, not their current segment. Confirm
   it returns a different value than filtering `is_current = true` for
   at least one customer.

3. Extend `TRACKED` with `occupation`. Run the lab again and confirm the
   dimension's total row count only went up by the number of customers
   whose occupation OR one of the original four columns actually
   changed, not by 8,000.

4. For the periodic snapshot in step 2, write one sentence explaining
   why `gold/branch_daily` always has 36 rows for a day even if one
   branch processed zero transactions that day. If you are not sure,
   look at how Lab 04 builds it.

## Key points

- The grain is the first design decision, and every downstream bug traces back to getting it wrong.
- A fact table is a transaction fact, a periodic snapshot, or an accumulating snapshot. Pick one.
- SCD Type 1 overwrites history. SCD Type 2 keeps it, as a new row with its own effective dates.
- Hash only the columns the business wants tracked, or every extract looks like a mass update.
- The surrogate key, not the natural key, is what a fact table should join to once a dimension has history.
