# Module 04: Lakehouse, bronze to silver to gold

After this module you can design and build a three-layer Parquet warehouse, quarantine bad rows instead of losing them, reprocess a single day safely, and prove with numbers that the layers agree with each other.

## Why this matters in a bank

Every bank already has this pattern, under different names. A staging table holds the raw feed. An ODS, an operational data store, holds it cleaned and conformed. A data mart holds it summarised for reporting. Bronze, silver and gold are the same three ideas, built on Parquet instead of a relational database, and this module is where you build all three, on the real transactions feed, with real reconciliation numbers that either tie out or tell you exactly where they do not.

This is the payoff of Day 1. Module 01 gave you the Python. Module 02 gave you how Spark actually runs. Module 03 gave you reading, cleaning and joining one feed. This module puts all three together into something a bank would actually run every night: a pipeline that lands data, cleans it without losing anything, and produces numbers people can report on, with the ability to fix one bad day without touching the other 29.

By the time this module ends, you will have built, from nothing, the exact shape of pipeline most data engineering roles at a bank spend most of their time maintaining. That is deliberate. This is not a toy exercise standing in for real work, it is a smaller, honest version of it.

Read the whole module before opening the lab file. The lab moves fast, six steps in under a minute of runtime, and it will make far more sense with the reasoning behind each step already in mind.

Everything below is organised in the same order the lab runs: why layers, what belongs where, bronze, silver, quarantine, gold, partitioning, reprocessing, reconciliation.

Start with the next section.

`labs/04_lab_lakehouse.py` also WRITES the warehouse that Day 2 and Day 3 labs read. Run it before anything else on Day 2.

The client asked for extra time on this module for a good reason: a course can teach DataFrames and joins forever without ever forcing you to answer the questions a real pipeline forces on you. What happens to a bad row. What happens when yesterday's file was wrong. How do you PROVE, not just claim, that a summary table agrees with the detail it was built from. Eighty minutes here is not padding, it is the module doing the most direct translation from "I can write Spark code" to "I can be trusted to run a production pipeline".

## Why three layers, not one or five

| Layers | Problem |
|---|---|
| One layer, clean straight from source | every consumer redoes the same cleaning, and a mistake in cleaning corrupts the only copy you have |
| Five or more layers | each hop adds a batch job, a schedule, a chance to fail, for questionable extra benefit over three |
| Three layers: bronze, silver, gold | a proven shape, one layer per purpose, easy to explain to anyone who has worked with staging, ODS and mart before |

A one-layer design also makes reprocessing dangerous. Fix a bug in the cleaning logic, and there is no clean, unmodified copy left to reprocess FROM, only the already-cleaned data the bug already touched. Three layers means there is always an earlier, trustworthy layer to rebuild from, bronze for silver, silver for gold.

Three layers is not a magic number, it is the smallest number that separates three genuinely different concerns: keeping a faithful copy of what arrived (bronze), producing one trustworthy row per business entity (silver), and answering a specific business question fast (gold). Fewer layers merges concerns that do not belong together. More layers adds operational cost without adding a new concern to separate.

Each layer, in short: bronze is a photograph, silver is a fact, gold is an answer. Keep that phrase in mind whenever you are deciding which layer a new piece of logic belongs in.

Each layer also answers a different question when something goes wrong.

| Question | Which layer answers it |
|---|---|
| "What did the source system actually send us?" | bronze, unmodified, always |
| "Is this transaction real, and which branch does it belong to?" | silver |
| "How much did BR011 process yesterday?" | gold |

If your only copy of the data is already cleaned and joined, "what did the source actually send" becomes unanswerable the moment a cleaning bug is suspected. Bronze exists specifically so that question always has an answer.

## What belongs in each layer

| Layer | What goes in it | What does NOT go in it | Grain |
|---|---|---|---|
| Bronze | the raw feed, exactly as it arrived, plus an ingest timestamp | any cleaning, any joins, any dedup | one row per row in the source file |
| Silver | deduplicated, typed, trimmed, bad rows quarantined, joined to accounts and branches | anything specific to one report | one row per `txn_id` |
| Gold | business aggregates a bank actually reports | row-level transaction detail | one row per branch per day |
| Quarantine | rejected rows, with a reason | anything that passed every quality check | one row per rejected transaction |

A useful test for "does this belong in silver or gold": would two different teams building two different reports both need this exact number? If yes, it probably belongs in gold as its own aggregate, or the underlying rows belong in silver so each team can aggregate it their own way. If a number is specific to one dashboard, build it from gold, do not bake it into gold itself.

Silver's grain, one row per `txn_id`, is the same grain the source system uses for a transaction. This is deliberate. Silver is where you want to answer "show me this one transaction and everything known about it", a lookup that only makes sense at the finest grain you have. Once you group by branch and day in gold, that ability is gone, on purpose, because gold's whole job is to be small and fast, not complete.

This is also why silver, not gold, is what Day 2 and Day 3 labs read from for row-level work, windows, SQL, data quality profiling. Gold is the end of the line for reporting, not a general-purpose source for further transformation.

## Mapping to the language you already know

| This module's term | The term you already use |
|---|---|
| Bronze | staging |
| Silver | ODS, operational data store |
| Gold | data mart |
| `WAREHOUSE` folder in this course | your bank's data lake or lakehouse storage account |
| `data/warehouse/bronze`, `/silver`, `/gold` in this course | the same three layers, named the way this module names them |
| Quarantine table | a reject or exception table, the same idea, still queryable, never a silent delete |
| Reprocessing one partition | a partial reload, the kind of fix a staging or ODS refresh already does for one bad day |
| Dynamic partition overwrite | a targeted `DELETE` plus `INSERT` for one partition, without a full table reload |

If your bank already runs a staging-ODS-mart pipeline on a relational database, this module is not a new set of ideas, it is the same three ideas built on Parquet files instead of database tables, with Spark instead of stored procedures doing the transformation.

## Why files, not a database table, for this

A relational staging-ODS-mart pipeline usually runs as a sequence of stored procedures against tables the database manages for you: transactions, locking, indexes. A Parquet-based lakehouse trades that managed environment for two things a bank cares about at this kind of scale: cheap, elastic storage that does not need a database license per terabyte, and files that any engine, Spark, a query tool, another team's Python script, can read directly, without going through a database connection.

| | Relational staging/ODS/mart | Parquet bronze/silver/gold |
|---|---|---|
| Storage cost at scale | licensed database storage | commodity object storage |
| Who can read it | anything with a database connection | anything that reads Parquet, no server required |
| Transactions, locking | built in | not built in, this is exactly the gap Module 11's table formats, Delta and Iceberg, exist to close |
| Schema enforcement | built in | you enforce it yourself, as this module does with explicit schemas throughout |

This module intentionally builds the medallion pattern on PLAIN Parquet, with no table format underneath, so you see exactly what a table format like Delta or Iceberg is adding when Module 11 introduces one: transactional writes, and safe concurrent readers and writers. Everything you build here still works, and still matters, whether or not a table format sits on top of it later.

One gap plain Parquet leaves open, worth naming now rather than discovering it the hard way: a writer that crashes mid-write can leave a partition in a half-written state, some files landed, some did not, with nothing to mark the write as incomplete. `mode("overwrite")` with `dynamic` partition mode reduces the blast radius to one partition, but does not remove this risk entirely. Module 11's table formats add a proper commit log specifically to close this gap, an atomic switch from "old version" to "new version" with nothing readable in between.

## Bronze: land the feed as it arrived

```python
bronze = (raw
    .withColumn("ingest_date", F.regexp_extract(F.input_file_name(), r"dt=(\d{4}-\d{2}-\d{2})", 1))
    .withColumn("ingest_ts", F.current_timestamp()))

bronze.write.mode("overwrite").partitionBy("ingest_date").parquet(f"{WAREHOUSE}/bronze/transactions")
```

Bronze answers one question only: what did we receive, and when. No cleaning, no dedup, no joins. If a bug in silver's logic corrupts a report, you reprocess from bronze, you do not have to re-pull the source system, because bronze already has an exact, untouched copy.

Bronze partitions by **ingest date**, the day the file arrived, taken here from the file name itself. A new day's file becomes a new partition. The old partitions are never touched by a normal day's load, only ever added to.

Notice bronze does not even filter out obviously bad rows, like the negative amounts covered in Module 08. That check belongs downstream, in silver, where a REASON is attached to why a row did not make it further. Bronze's only promise is "this is what we received", and a promise like that is only useful if it is kept absolutely, with no exceptions for rows that look wrong.

```python
raw = spark.read.option("header", True).schema(TXN_SCHEMA).csv(f"{RAW}/transactions/*.csv")
```

The schema here is the same explicit schema from Module 03, reused rather than rebuilt. A schema declared once and imported everywhere it is needed is far safer than the same `StructType` retyped by hand in four different files, where a small mismatch in one copy can silently produce different results from the others.

## Silver: one trustworthy row per transaction

Getting from bronze to silver is three separate jobs, done in order.

**1. Deduplicate.** Exact duplicate `txn_id` rows are a feed replay, not a data quality question, so they are removed before anything else runs.

```python
dedup_rank = Window.partitionBy("txn_id").orderBy(F.monotonically_increasing_id())
deduped = bronze.withColumn("rnk", F.row_number().over(dedup_rank)).filter("rnk = 1").drop("rnk")
```

**2. Clean.** The two dirty columns from Module 03, `channel` and `merchant_category`, get the same fix here.

**3. Join and quarantine.** A left join to `accounts.csv` finds orphan `account_id` values. Combined with the negative-amount check, this decides which rows are good enough for silver.

Silver partitions by **posting date**, the business date parsed from `txn_ts`, not the ingest date. This is deliberate and different from bronze. Analysts and gold aggregates filter by the date a transaction actually happened, not the date the file that contained it happened to arrive. In this course's data the two usually match, but a late-arriving correction, covered under reprocessing below, is exactly the case where they do not.

On a real run of this lab, the three steps produce numbers like these:

```text
bronze rows: 180720
exact duplicate rows removed: 720
quarantined rows: 1281  |  reasons: NEGATIVE_AMOUNT 380, ORPHAN_ACCOUNT 901
silver rows: 178719
```

180,720 rows arrived. 720 were exact replays, removed before any quality check ran. Of the 180,000 that remained, 1,281 failed a quality rule and went to quarantine, with a reason each. 178,719 made it to silver. Every one of those four numbers is printed by the lab, not asserted in a slide, and check 1 in the reconciliation step below proves they actually add up.

## The quarantine pattern

A bad row is never dropped silently. It gets a reason, and it goes to a separate table, still fully queryable.

```python
tagged = checked.withColumn("bad_reason",
    F.when(F.col("amount") < 0, "NEGATIVE_AMOUNT")
     .when(F.col("branch_code").isNull(), "ORPHAN_ACCOUNT")
     .otherwise(F.lit(None).cast("string")))

quarantine = tagged.filter(F.col("bad_reason").isNotNull())
silver = tagged.filter(F.col("bad_reason").isNull())   # only THESE rows continue to silver
```

| Why not... | Because |
|---|---|
| ...just drop bad rows | nobody can ever answer "how many rows did we lose, and why" |
| ...just keep bad rows in silver | a downstream sum now includes a negative amount that should not exist, or a transaction attributed to no branch |
| ...fail the whole job on one bad row | one bad row out of 180,000 would stop the entire day's processing for no good reason |

Quarantine is the middle path: the good data keeps moving, and the bad data is never lost, it is sitting in its own table with a reason, ready for someone to investigate, fix at the source, or explicitly decide to ignore.

A quarantine table needs a REASON column, not just the rejected rows. `bad_reason` here is one of `NEGATIVE_AMOUNT` or `ORPHAN_ACCOUNT`. A quarantine table with rejected rows but no reason is only marginally better than dropping them, since nobody investigating it can tell which check failed without re-deriving it themselves.

```python
quarantine.groupBy("bad_reason").count().show()
```

One line, and now anyone can see the SHAPE of the day's data quality, not just its total: 380 negative amounts, 901 orphan accounts, this run. A shift in either number, week over week, is worth investigating on its own, independent of whether the total quarantine count changed.

Quarantine is small, a fraction of a percent of the feed here, and read as a whole by whoever investigates it. It is written WITHOUT partitioning. Partitioning a table this small only creates many tiny files with nothing meaningful to prune.

This is also where Module 03's orphan-account lesson gets its production answer. Module 03 showed that an `inner` join silently drops orphan rows, and argued for a `left` join instead, so you can SEE what did not match. This module finishes that thought: what you do with what you see is quarantine it, with a reason, not just print a count and move on. `ORPHAN_ACCOUNT` in this lab's quarantine table is that exact orphan check from Module 03, now wired into a real pipeline decision instead of a one-off print statement.

## Gold: business aggregates

```python
gold = (silver.groupBy("branch_code", "posting_date")
    .agg(F.count("*").alias("txn_count"),
         F.sum("amount").alias("total_amount"),
         F.sum(F.when(F.col("txn_type") == "DEBIT", F.col("amount")).otherwise(0)).alias("debit_amount"),
         F.sum(F.when(F.col("txn_type") == "CREDIT", F.col("amount")).otherwise(0)).alias("credit_amount")))
```

One row per branch per day, 36 branches times 3 days, about 100 rows for this course's dataset. Gold is written WITHOUT partitioning too, for the same reason as quarantine: partitioning a table this small adds small files and gives you nothing to prune, since any real query against it scans the whole thing in a fraction of a second regardless.

Gold's aggregates here, `txn_count`, `total_amount`, `debit_amount`, `credit_amount`, are chosen because they are the kind of number a branch manager or a finance team actually reports on. A good gold table is not "every aggregate we could think of", it is the specific, named set of numbers a real report needs. Adding a column nobody asked for is not free, it is one more thing to keep correct and reconciled forever.

`F.round(..., 2)` on the monetary sums is a small but deliberate choice: rupee amounts printed in scientific notation, `4.49E7` instead of `44934702.80`, are unreadable to anyone reviewing the output, and a bank report should never make someone do currency arithmetic in their head just to read a number.

## Partitioning, one decision per layer

| Layer | Partition by | Why |
|---|---|---|
| Bronze | ingest date | matches how data actually arrives, one partition per day's file, easy to reprocess one day's raw landing |
| Silver | posting date | matches how analysts and gold actually query, by business date, not arrival date |
| Quarantine | none | small, read as a whole, nothing to prune |
| Gold | none | small, aggregated, any query scans it in a fraction of a second regardless |

Partitioning is not a default you apply everywhere. It is a decision, made once per table, based on how that table is actually going to be read. A table nobody filters by date gains nothing from a date partition, and pays the cost of more small files for it.

A partition column should also have a manageable number of distinct values. Posting date across a year is 365 partitions, entirely reasonable. Partitioning by `account_id`, with 12,000 distinct values, would create 12,000 tiny folders, mostly holding a handful of rows each, which is worse for read performance than no partitioning at all. The rule of thumb: partition by a column with a moderate number of distinct values that queries actually filter on, most often a date.

`explain()` on a query against a partitioned table shows the payoff directly. Filter silver by `posting_date = '2026-09-01'` and the `PartitionFilters` line in the plan shows Spark skipping the other two days' files entirely, never reading a single byte of them.

## Reprocessing one day, dynamic partition overwrite

Corrections arrive for one day. Silver's partition for that day needs fixing, without touching the other days.

```python
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

redo_clean.write.mode("overwrite").partitionBy("posting_date").parquet(f"{WAREHOUSE}/silver/transactions")
```

| Mode | What an `overwrite` write touches |
|---|---|
| `static` (Spark's own default) | the ENTIRE table, every partition, even ones this write has no new data for |
| `dynamic` | only the partitions this write actually has data for, every other partition is left untouched |

Without `dynamic` mode, writing a fix for one day would silently delete every other day's silver data, because `mode("overwrite")` on a static-mode write replaces the whole table, not just the partition you meant to fix. This is one of the most common, and most damaging, mistakes a team makes the first time they build a partitioned write. Setting `partitionOverwriteMode` to `dynamic` once, at the session level, avoids it permanently.

The lab walks through the whole reprocessing scenario end to end, not just the config setting:

1. **Snapshot before.** Count the OTHER two days' rows, before touching anything, so there is something to compare against after.
2. **Combine.** Take the original day's bronze rows and the matching day's rows from `txn_updates.csv`, the late corrections file, together.
3. **Resolve conflicts.** Where a `txn_id` appears in both, the correction wins, using a `src_rank` column and the same `row_number()` window pattern used for deduplication.
4. **Redo the full silver pipeline, for that day only.** Clean, quarantine, join, exactly the same steps silver already went through, just scoped to one day's rows.
5. **Write with `dynamic` mode.** Only that one partition changes on disk.
6. **Snapshot after, and compare.** The other two days' counts must be identical to the snapshot from step 1. If they are not, the dynamic mode was not actually in effect, or something in the write touched more than intended.

This shape, snapshot, redo, write dynamically, compare, is the same shape a real incident response follows: prove what should NOT have changed, actually did not change, do not just assume it.

After a partition is reprocessed, anything built FROM it downstream is now stale. This lab's gold layer is recomputed immediately after the reprocessing step for exactly this reason, a full recompute, since gold is small enough that recomputing the whole thing is cheap, cheaper than tracking which specific gold rows need updating.

A real run of the reprocessing step prints exactly this proof:

```text
other two days, row count before: 119157  after: 119157  (must match)
reprocessed day 2026-09-01, new row count: 59895
gold refreshed, rows: 108
```

119,157 rows across the two untouched days, before the write. 119,157 rows across those same two days, after. The equality is not assumed, it is the actual output of the lab, run on your machine. Only the reprocessed day's row count is expected to change, and it does, from whatever it was before to 59,895 after the corrections are merged in.

### Idempotency: why `overwrite`, not `append`

Every write in this module uses `mode("overwrite")`, never `mode("append")`. Rerun the whole lab twice and you get the same warehouse both times, not double the rows. This property, rerunning a job produces the same result, is called **idempotency**, and it is what makes a pipeline safe to retry after a failure. An `append`-based pipeline that fails halfway through and gets rerun from the start will duplicate every row that made it through before the failure. An `overwrite`-based one, scoped correctly with dynamic partition mode, simply redoes the work and lands in the same place either way.

## Reconciliation

Every layer boundary gets a number that must tie out, checked in code, not assumed.

```python
check_1 = (bronze_count - duplicates_removed) == (silver_count + quarantine_count)
check_2 = round(silver_sum, 2) == round(gold_sum, 2)
check_3 = silver_count == gold.agg(F.sum("txn_count")).first()[0]
```

| Check | What it proves |
|---|---|
| bronze minus duplicates equals silver plus quarantine | every row that survived dedup is accounted for, either good or quarantined, none silently lost |
| sum(silver.amount) equals sum(gold.total_amount) | the aggregation in gold did not drop or double-count any silver row |
| count(silver) equals sum(gold.txn_count) | same idea, on row count instead of a monetary sum |

This is not a nice-to-have. A reconciliation report a bank cannot prove ties out, layer to layer, is not a report anyone should trust, no matter how confident the pipeline's author is that the logic is correct. Printing these checks every run means a bug shows up the day it is introduced, as a `False` in the output, not three weeks later as a complaint from someone reading the report.

A real run prints all three, after the reprocessing step, so the numbers reflect the corrected data:

```text
bronze - duplicates == silver + quarantine ? 180720 - 720 == 178719 + 1281  -> True
sum(silver.amount) == sum(gold.total_amount) ? 596136934.12 == 596136934.12  -> True
count(silver) == sum(gold.txn_count) ? -> True
```

Every one of these is a boolean, computed from real numbers, not a comment claiming the pipeline is correct. If check 2 ever printed `False`, that would mean the `groupBy().agg(F.sum(...))` step lost or double-counted rows, silently, somewhere between silver and gold, exactly the kind of bug that is invisible from reading the code and only visible from a number that should match and does not.

Build reconciliation checks like these into every pipeline you write after this course, not only this lab. The pattern is always the same: pick a number that MUST be equal on both sides of a boundary, compute both sides independently, compare them, and print the result.

Picture check 1 failing on a real production night: bronze minus duplicates does not equal silver plus quarantine. That single `False` tells the on-call engineer, immediately, that rows went missing somewhere in the dedup-clean-join chain, before a single downstream report is even generated. Without that check, the same bug surfaces days later as a branch manager asking why yesterday's total looks low, with no clue where in the pipeline to start looking.

Three checks is the minimum for this lab's three layer boundaries, not a ceiling. A real pipeline often has more, one per meaningful boundary it crosses.

## What a production version adds

Everything in this module is real, working pipeline logic, not a simplified toy version of one. A production deployment adds a small number of things this lab intentionally leaves out, so the core pattern stays visible:

| What this lab does | What production adds on top |
|---|---|
| Prints reconciliation results to the console | sends a failed check to an alert, a Slack message, a paging system, not just a printed `False` |
| Runs on demand, from the command line | scheduled by Airflow, covered in Module 17, with retries and dependency ordering |
| Reads local CSV files | reads from wherever the source system actually lands files, a message queue, an SFTP drop, a change data capture stream |
| One person's laptop, `local[*]` | a cluster, with the same partitions, stages and shuffles from Module 02, just spread across real machines |

None of these additions change the core pattern. A scheduled, alerted, clustered version of this lab is still bronze, then silver with quarantine, then gold, with reconciliation checks between each step. Scale and tooling change. The shape does not.

Module 17's Airflow pipeline, later in this course, is exactly this module's logic wrapped in a schedule with retries. Nothing about bronze, silver, gold, quarantine or reconciliation changes there, only who and what triggers it.

Keep that in mind when the schedule and the retries feel like the interesting part in Module 17. They are the wrapper.

This module is the pipeline the wrapper exists to run correctly.

## The lab

`labs/04_lab_lakehouse.py` builds the whole warehouse and writes it to `data/warehouse/`. Later labs read from here.

| Step | Shows |
|---|---|
| 1 | Bronze: land the raw feed, partitioned by ingest date |
| 2 | Quarantine: dedup, then split bad rows out with a reason |
| 3 | Silver: join to branches, one row per `txn_id`, partitioned by posting date |
| 4 | Gold: one row per branch per day |
| 5 | Reprocess one day only, dynamic partition overwrite, then refresh gold |
| 6 | Reconciliation: the three checks above, printed with their actual numbers |

Every write in the lab uses `mode("overwrite")`. Running the lab twice in a row produces the same warehouse both times, not a doubled one, the idempotency property covered above. This also means it is always safe to rerun `labs/04_lab_lakehouse.py` if you are not sure the warehouse is current, rather than trying to patch it by hand.

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| A reprocessing run deletes every other day's data | `partitionOverwriteMode` left at Spark's default, `static` | set it to `dynamic` before any partitioned overwrite write |
| Bad rows just disappear, with no way to explain a missing count | dropped instead of quarantined | route them to a quarantine table with a reason column, never a plain `.filter()` that discards them |
| Silver partitioned by ingest date, same as bronze | copied bronze's partitioning without asking what silver is actually queried by | partition silver by the business date it is actually filtered on |
| Gold left un-refreshed after a silver reprocess | assumed a downstream table stays correct on its own | recompute anything built from a partition that changed |
| A reconciliation check written once, in a notebook, never rerun | trusted a one-time manual check | print reconciliation numbers every run, so a break shows up immediately |
| Too many layers, "just in case" | uncertainty about what belongs where | use the two-team test: does this number matter to more than one consumer as raw rows, or is it one dashboard's aggregate |
| Partitioning a table by a high-cardinality column | assumed partitioning always helps | check the column's distinct value count first, thousands of tiny partitions is worse than none |
| A pipeline that produces different totals when rerun | used `mode("append")` where `mode("overwrite")` was needed | make writes idempotent, rerunning the same job should never double-count |
| Trusting a report because the pipeline "usually works" | no reconciliation check exists to prove this run specifically was correct | print the checks every run, on every run's actual data, not just once during development |

## Exercises

1. Add a fourth quarantine reason, for example transactions with a `status` value that is not one of `SUCCESS`, `FAILED`, `PENDING`. Confirm reconciliation check 1 still holds.
2. Reprocess a DIFFERENT day than `2026-09-01` and confirm the other two days' row counts are unchanged, the same way the lab already checks for `2026-09-01`.
3. Add a fourth reconciliation check: the count of DISTINCT `branch_code` values in gold should equal the count of DISTINCT `branch_code` values in `branches.csv` that have at least one transaction.
4. Change gold's grain to one row per branch per day per `channel`, instead of just per branch per day. Update the reconciliation checks to match the new grain.
5. Run the lab twice in a row without changing anything, and confirm the reconciliation numbers are identical both times. This is the idempotency property in practice, not just in theory.
6. Add a fifth reconciliation check comparing sum(silver.amount) for DEBIT rows only against a recomputed sum from bronze, filtering the same way. Decide, and justify, whether it should include or exclude quarantined rows.

## Key points

- Bronze is a faithful, uncleaned copy. Silver is one trustworthy row per business entity. Gold is a specific business answer. Each layer has one job, not several.
- A bad row gets a reason and a home in a quarantine table. It is never silently dropped, and never silently kept where it can corrupt a downstream number.
- Partition each layer by how it is actually queried, not by copying the layer before it. Bronze by ingest date, silver by posting date, quarantine and gold by nothing at all.
- `spark.sql.sources.partitionOverwriteMode = "dynamic"` is what makes reprocessing one partition safe. Without it, an overwrite write replaces the whole table.
- Reconciliation is not optional. Print the numbers that must tie out, every run, so a break is visible the day it happens.
- Every write here is idempotent: `mode("overwrite")`, scoped correctly with `dynamic` partition mode when writing one partition. Rerunning a job should never double-count.
- Plain Parquet has no built-in transactions or concurrent-write safety. Module 11 covers Delta and Iceberg, table formats that add exactly that on top of everything this module builds.
- Silver, not gold, is the row-level source the rest of this course reads from. Gold is a finished report, not raw material for further transformation.
