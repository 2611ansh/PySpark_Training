# Module 12: Polyglot Persistence

What you can do after this module: pick the right file format for a given
banking workload, explain what makes Parquet fast for analytics, prove
predicate pushdown and column pruning directly from `explain()`, and know
why a Spark job should never point straight at the core banking database.

```bash
./run.sh labs/12_lab_file_formats.py
```

## Why this matters in a bank

No bank runs on one storage system. The core ledger lives in a relational
database, KYC documents sit in a document store, and years of transaction
history sit in a data lake for reporting. "Polyglot persistence" is just
the name for that reality: many stores, each chosen for what it is
actually good at. Spark's job is not to replace any of them. Its job is to
read and write each one correctly, without becoming the job that quietly
overloads a production database at 2am.

## 1. File format decision table

| Format | Schema | Compression | Splittable | Row or column | Where it belongs |
|---|---|---|---|---|---|
| CSV | none, columns are positional | none built in | yes, uncompressed only | row | source exports, human-readable drops, never a curated table |
| JSON | flexible, nothing enforces it | none built in | yes, one object per line | row | API payloads, event logs, semi-structured feeds |
| Avro | strong, travels with the data | good | yes | row | Kafka payloads, anything replayed years after the schema changed |
| ORC | good | good | yes | column | Hive-heritage warehouses, a safe lift-and-shift target |
| Parquet | good | very good | yes | column | the default curated format, and every silver/gold table in this course |

Row formats win when you write one record at a time and rarely read a
handful of columns out of many, an event stream or an audit trail. Column
formats win when a query reads a few columns out of a wide table across
millions of rows, which describes most of a bank's reporting and
reconciliation workloads. That is the whole reason Lab 04's silver and gold
tables are Parquet by default.

## 2. Avro, briefly and honestly

Avro belongs in the decision table above but is not run in the lab: it
needs the `spark-avro` package fetched from Maven, and this sandbox has no
Maven access, the same honest limitation Module 11 has for Delta and
Iceberg. Avro's real home in a bank is Kafka: the schema travels with every
message (or lives in a shared schema registry), so a consumer written
today can still read a message produced two years ago, even after the
schema changed, as long as the change was backward compatible. That
property, not file size, is why event streams reach for Avro over JSON:
JSON is flexible right up until a consumer silently misreads a renamed
field, Avro's schema makes that mismatch a loud error instead.

## 3. Parquet internals, briefly

A Parquet file is organised footer-last:

```
row group 0:  column chunk (txn_id) | column chunk (amount) | ...
row group 1:  column chunk (txn_id) | column chunk (amount) | ...
footer:       schema + per-row-group, per-column min/max/null stats
```

A **row group** is a horizontal slice of rows. Each row group holds one
**column chunk** per column, this is what makes Parquet columnar: a query
touching 3 of 12 columns reads only 3 chunks per row group, the rest are
never opened. The **footer** carries the schema and min/max statistics per
column per row group, and `Lab 12`, Step 2, reads that footer directly with
`pyarrow.parquet`, no Spark needed for that one check.

Those min/max stats are what let a filtered query skip a whole row group
unread, without decompressing it: if a row group's `amount` maxes out at
50,000 and the query filters `amount > 1,000,000`, Spark never touches that
row group's data pages. That is **predicate pushdown**, proven directly in
Step 3 of the lab, not a claim to take on faith.

## 4. Predicate pushdown and column pruning, proven

```python
filtered = parquet_txns.filter(F.col("status") == "SUCCESS")
plan = filtered._jdf.queryExecution().executedPlan().toString()
"PushedFilters" in plan   # True
```

`PushedFilters` appearing in the physical plan means the filter travelled
into the Parquet reader itself, not a later Spark stage. **Column pruning**
is the companion optimisation, proven the same way: selecting only two
columns out of twelve produces a plan that never mentions the other ten at
all, so their column chunks are never opened.

**Partition pruning** goes one level further: filtering on a partition
column (Lab 04's `posting_date` on silver, for example) skips whole folders
before a single file inside them is even listed. Module 14 extends this
idea to a join, where the filtering value is only known from the small
side of the join at runtime, not written in the query text.

## 5. Compression codecs, briefly

| Codec | Speed | Compression | Use when |
|---|---|---|---|
| snappy | fastest | modest | default for hot, frequently-read tables, Spark's own default |
| zstd | fast, tunable | best of the common codecs | the modern default once every reader in the estate supports it |
| gzip | slow to write, fast to read | good | cold archives rewritten rarely, never a nightly-rewritten table |
| none | fastest write, largest files | none | debugging only |

Delta and Iceberg are not repeated here. Module 11 already covers both in
depth, on the same banking data, with MERGE, time travel and maintenance.

## 6. JDBC to relational databases

Not runnable in this sandbox: there is no JDBC driver jar and no database
server here. This is exactly what runs on a real cluster:

```python
df = (spark.read.format("jdbc")
      .option("url", "jdbc:postgresql://core-banking-replica:5432/ledger")
      .option("dbtable", "(SELECT txn_id, account_id, amount FROM transactions "
                          "WHERE txn_ts >= '2026-09-01') t")
      .option("partitionColumn", "txn_id_numeric")
      .option("lowerBound", "1")
      .option("upperBound", "10000000")
      .option("numPartitions", "8")
      .option("fetchsize", "10000")
      .load())
```

| Option | What it does |
|---|---|
| `dbtable` | a table name, or a `(SELECT ...) alias` subquery for pushdown |
| `partitionColumn`, `lowerBound`, `upperBound`, `numPartitions` | splits one read into N parallel connections over a key range |
| `fetchsize` | rows pulled per network round trip on read |
| `batchsize` | rows per `INSERT` batch on write |

**The warning that matters more than any option above**: a core banking
database sized for a few hundred online transactions a second was never
sized for Spark opening 8, 16 or 32 parallel connections and reading every
row of a table. Always point a Spark JDBC job at a **read replica**, never
the live core, and agree `numPartitions` and `fetchsize` with the DBA who
owns that database before the first run.

## The lab

`labs/12_lab_file_formats.py`:

| Step | Shows |
|---|---|
| 1 | Same rows written as CSV, JSON and Parquet, size and time compared |
| 2 | The Parquet footer read directly: row groups, columns, min/max stats |
| 3 | Predicate pushdown, proven in `explain()` |
| 4 | Column pruning, proven in `explain()` |
| 5 | The JDBC warning, with the code that would run on a real cluster |

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| Writing a curated table as CSV "because it was easy" | not thinking about the downstream read pattern | curated tables are Parquet by default, see Lab 04 |
| Assuming `.count()` proves pushdown worked | a row count does not show what was pushed down | check `.explain()` for `PushedFilters`, the way Step 3 does |
| Choosing gzip for a table rewritten every night | picked the codec for smallest size, ignored write cost | gzip is slow to write, use it for cold archives only |
| Pointing a Spark JDBC job straight at the live core banking database | nobody asked the DBA before setting a high `numPartitions` | always read from a replica, agree limits with the DBA first |
| Setting `numPartitions` without a `partitionColumn` | assuming more partitions alone means more parallelism | JDBC parallelism needs both, a numeric column to split the range on and the partition count |

## Exercises

1. Run the lab and note which format was smallest for this data. Does that
   match Section 1's reasoning about row versus column storage?

2. Change Step 3's filter from `status == "SUCCESS"` to `amount > 500000`,
   re-run, and confirm `PushedFilters` still appears for the new filter.

3. In Step 4, add `"channel"` to the narrow `select()` and confirm the
   plan now mentions `channel` but still not `device_id` or `city`.

4. Without a database here, read Section 6's JDBC code and identify which
   option you would raise, and which you would leave alone, if AtliQ
   Bank's DBA agreed to only 4 parallel connections instead of 8.

## Key points

- Parquet wins for curated banking tables because it is columnar,
  compressed, and its footer stats let a query skip data it does not need.
- Predicate pushdown and column pruning are provable in `explain()`, check
  the plan, do not assume a filter or a `select()` is free.
- Delta and Iceberg solve the upsert problem plain Parquet cannot. That is
  all in Module 11, not repeated here.
- A Spark JDBC job against a live core banking database is an outage
  waiting to happen. Read from a replica, every time.
