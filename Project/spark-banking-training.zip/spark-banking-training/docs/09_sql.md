# Module 09: SQL, Python and Spark

After this module you can prove SQL and the DataFrame API do the same
work, choose between managed and external tables correctly, and write
the handful of Spark SQL patterns that replace what QUALIFY, and a few
other habits, did in Teradata or Oracle.

## Why this matters in a bank

Most bank data teams have SQL analysts alongside PySpark engineers, and
they need to trust the same numbers. This module proves there is no
"the DataFrame version is more correct" or "the SQL version is faster":
they compile to the exact same plan. It also covers the handful of
syntax differences that trip up someone arriving from Teradata or
Oracle, where a few very common patterns simply do not exist in open
source Spark SQL.

## Proof: the DataFrame API and SQL compile to the same plan

```python
df_way = txns.groupBy("channel").agg(F.count("*").alias("n"))
sql_way = spark.sql("SELECT channel, COUNT(*) AS n FROM v_txns GROUP BY channel")
```

Both go through the SAME Catalyst optimiser. The DataFrame API is not
compiled directly to bytecode from Python; it builds the same internal
logical plan that parsing the SQL string builds, and from that point on
neither one is faster, they are the same plan.

```python
strip_ids = lambda plan: re.sub(r"#\d+", "", plan)
df_plan = strip_ids(df_way._jdf.queryExecution().optimizedPlan().toString())
sql_plan = strip_ids(sql_way._jdf.queryExecution().optimizedPlan().toString())
df_plan == sql_plan   # True
```

The `#\d+` strip removes each column's internal id, for example `n#42`,
which differs between the two queries only because they were compiled
as two separate calls, not because the plan itself differs.

This is why "should we write this in SQL or the DataFrame API" is a
team style question, not a performance question. Pick whichever your
team reads faster, and mix the two freely inside one pipeline: a temp
view built from a DataFrame, queried with SQL, is a completely normal
pattern, not a compromise.

## Temp views, and the catalog that tracks them

`createOrReplaceTempView` makes a DataFrame queryable with `spark.sql`,
for the life of the SparkSession only. Nothing is written to disk.

```python
txns.createOrReplaceTempView("v_txns")
spark.sql("SELECT channel, COUNT(*) AS n FROM v_txns GROUP BY channel").show(5)
```

The catalog tracks what is currently queryable, temp views included:

```python
for t in spark.catalog.listTables():
    print(t.name, t.isTemporary)
```

A GLOBAL temp view, `createOrReplaceGlobalTempView`, is visible across
multiple SparkSessions in the same Spark application, under the
`global_temp` database, but that situation is rare in a single script
like this course's labs, where one script means one SparkSession.

## Managed vs external tables

A managed table: Spark owns both the metadata AND the data files. You
gave it no path, so it picked one, under `spark.sql.warehouse.dir`.

```python
daily.write.mode("overwrite").saveAsTable("branch_daily_managed")
```

An external table: YOU own the data files, at a path you chose. Spark
only manages the metadata pointing to that path.

```python
daily.write.mode("overwrite").option("path", "/some/path").saveAsTable("branch_daily_external")
```

### The warning: what DROP TABLE really deletes

This is the one distinction worth remembering above all the others in
this section. `DROP TABLE` on a MANAGED table deletes the metadata AND
every data file underneath it. `DROP TABLE` on an EXTERNAL table deletes
only the metadata; the files, and anyone else's job still pointing at
that path, are untouched.

| | Managed table | External table |
|---|---|---|
| Who picks the location | Spark | you |
| `DROP TABLE` deletes | metadata AND data files | metadata only |
| Right choice when | Spark owns the table's whole lifecycle | another job, or another team, also reads the same files |

Running `DROP TABLE` on a managed table that another pipeline was
quietly also depending on is one of the more expensive mistakes a new
Spark SQL user can make: by the time anyone notices, the data files are
already gone.

## No QUALIFY in open source Spark

Teradata and Oracle let you filter on a window function result straight
after `WHERE`, with `QUALIFY`. Open source Spark SQL has no `QUALIFY`
keyword at all. The workaround: compute the window function in a
subquery, then filter the OUTER query.

```sql
SELECT account_id, amount, channel, rn
FROM (
    SELECT account_id, amount, channel,
           ROW_NUMBER() OVER (PARTITION BY account_id ORDER BY amount DESC) AS rn
    FROM v_txns
)
WHERE rn = 1
```

This pattern, a window function inside a subquery, filtered from
outside, replaces every use of `QUALIFY` you would have written in
Teradata. It is more typing, and it is the only way to do it here, so it
is worth having memorised rather than looked up every time.

## GROUPING SETS

One scan of the data, multiple breakdowns in one result set. This
replaces running several separate `GROUP BY` queries and unioning them
by hand.

```sql
SELECT COALESCE(channel, '(all channels)') AS channel,
       COALESCE(txn_type, '(all types)') AS txn_type,
       COUNT(*) AS n, SUM(amount) AS total
FROM v_txns
GROUP BY GROUPING SETS ((channel), (txn_type), ())
```

`(channel)` groups by channel alone. `(txn_type)` groups by txn_type
alone. `()` is the grand total, everything in one row. `COALESCE` turns
the NULL that GROUPING SETS puts in the columns NOT being grouped by
into a readable label, instead of a NULL that is easy to confuse with a
real missing value elsewhere in the same result.

`ROLLUP` and `CUBE` are shorthand for common patterns of grouping sets:
`ROLLUP(a, b)` is `GROUPING SETS ((a, b), (a), ())`, a hierarchical
subtotal. `CUBE(a, b)` is every combination: `((a, b), (a), (b), ())`.
Reach for `GROUPING SETS` directly whenever the breakdowns you need are
not simply "every combination" or "every prefix".

| Pattern | Produces |
|---|---|
| `GROUPING SETS ((a), (b), ())` | totals by a, totals by b, grand total. Three specific breakdowns |
| `ROLLUP(a, b)` | totals by (a, b), totals by a, grand total. A hierarchy, like region then branch |
| `CUBE(a, b)` | every combination: (a, b), (a), (b), and the grand total |

## TRY_CAST and NULL semantics

`CAST` on a value that cannot convert fails the query under ANSI mode.
`TRY_CAST` never fails: a bad value just becomes NULL.

```sql
SELECT TRY_CAST('12.5' AS DOUBLE) AS good,   -- 12.5
       TRY_CAST('abc' AS DOUBLE) AS bad      -- NULL, no error
```

NULL means "unknown", not zero, not empty. `col = NULL` is never TRUE,
not even for a row where `col` genuinely IS NULL, because comparing
unknown to anything is itself unknown. A plain `WHERE merchant_category
= NULL` matches nothing, ever, on any row:

```sql
SELECT SUM(CASE WHEN merchant_category = NULL THEN 1 ELSE 0 END) AS matched_with_equals,   -- 0, always
       SUM(CASE WHEN merchant_category IS NULL THEN 1 ELSE 0 END) AS matched_with_is_null  -- the real count
FROM v_txns
```

Use `IS NULL` and `IS NOT NULL` to test for NULL. Use `COALESCE(col,
default)` to substitute a value when a column might be NULL, for
example turning an empty `merchant_category` into `'UNKNOWN'` before it
reaches a report that was not built to handle blanks.

## ANSI mode

The same expression behaves differently depending on one session
setting. With ANSI mode off, a bad expression quietly returns NULL. With
it on, the SAME expression raises an error.

```python
spark.conf.set("spark.sql.ansi.enabled", "false")
spark.sql("SELECT 1/0 AS x").first()          # Row(x=None), silent

spark.conf.set("spark.sql.ansi.enabled", "true")
spark.sql("SELECT 1/0 AS x").collect()        # raises ArithmeticException
```

| Setting | Divide by zero | Bad CAST |
|---|---|---|
| ANSI off (Spark's default) | NULL | NULL |
| ANSI on | raises an error | raises an error |

ANSI off matches how a lot of legacy SQL was written, quietly tolerant
of bad data. ANSI on catches problems the moment they happen, which is
closer to how Oracle and Teradata behave by default, and closer to what
a bank's data quality expectations usually assume. `TRY_CAST` and
`TRY_DIVIDE` exist specifically so you can opt into the "return NULL
instead of failing" behaviour on a single expression, even with ANSI
mode on for the rest of the session. A pipeline that has run with ANSI
mode off for years, quietly tolerating bad casts, can start failing on
the day someone turns it on, which is worth testing deliberately on a
copy of production data rather than discovering it live.

## Mixing SQL and Python safely

Building a SQL string with plain Python f-strings works, and it is also
how SQL injection happens, even inside a trusted pipeline, if any part
of the string ever comes from outside data. Spark SQL supports named
parameters directly, the same protection a parameterised query gives you
against a real database:

```python
spark.sql(
    "SELECT * FROM v_txns WHERE channel = :ch AND amount > :min_amount",
    ch="UPI", min_amount=50000
).show(5)
```

Reserve f-strings for values YOU control in the pipeline's own code,
like a partition date computed from `datetime.now()`. Use named
parameters for anything that ultimately traces back to user input or an
external system, the same rule that applies to any other SQL engine,
whether that engine is Spark, Oracle, or Teradata.

## Reading EXPLAIN output

`.explain()` on a DataFrame, or `EXPLAIN` before a SQL query, prints the
plan Catalyst chose. The default view is often enough to answer one
question: did my filter get pushed down to the file read, or is Spark
reading everything and filtering afterward.

```python
txns.filter("amount > 50000").explain()
```

Look for `PushedFilters` near the scan step. If the filter you wrote
shows up there, the file format itself, Parquet especially, skipped
reading data that could not match. If it does not show up there,
Spark read everything and filtered in memory, which is correct but
slower. Module 12 covers exactly this pushdown behaviour in more detail,
with a real before-and-after on this course's data. `.explain("formatted")` gives a longer, more structured version
with a numbered plan tree, useful once a query has several joins and the
default view gets hard to read at a glance. `EXPLAIN` in SQL gives the
same information, so the choice between the two follows the same rule as
everywhere else in this module: whichever reads more naturally in the
context you are already working in.

## Quick reference for Teradata and Oracle users

| In Teradata or Oracle | In Spark SQL |
|---|---|
| `QUALIFY row_number() OVER (...) = 1` | wrap in a subquery, `WHERE rn = 1` on the outside |
| `SEL TOP 10 * FROM t` (Teradata) | `SELECT * FROM t LIMIT 10` |
| `NVL(col, default)` (Oracle) | `COALESCE(col, default)` |
| `DECODE(col, 'A', 1, 'B', 2, 0)` (Oracle) | `CASE WHEN col = 'A' THEN 1 WHEN col = 'B' THEN 2 ELSE 0 END` |
| `SYSDATE` (Oracle) | `current_date()` or `current_timestamp()` |
| implicit type coercion in a comparison | Spark does less of this under ANSI mode, `TRY_CAST` explicitly where needed |

None of these are exotic, they are the handful of habits that show up
in almost every script someone brings over from a Teradata or Oracle
background in the first week. Keep this table nearby during the lab;
the row_number() subquery pattern in particular is worth typing from
memory a few times until it stops feeling like extra work.

## Managing databases and the metastore, briefly

`CREATE DATABASE bank_dw` and `USE bank_dw` group related tables the way
a schema does in Oracle or Teradata. Every managed and external table
this module discussed is really registered in a metastore, a small
catalog database Spark itself manages, tracking table names, their
schemas, and where their files live. For every lab in this course that
metastore lives locally, under `data/warehouse`; a real deployment
usually points it at a shared Hive metastore or a cloud catalog instead,
so every team's Spark jobs, not just this course's labs, see the same
tables and the same schemas, with no copy-pasted table definitions
drifting out of sync between teams.

## The lab

`labs/09_lab_sql.py`, 60 minutes.

| Step | What it shows |
|---|---|
| 1 | Proof: the DataFrame API and SQL compile to the same plan |
| 2 | Temp views, and the catalog that tracks them |
| 3 | Managed vs external tables, and what DROP TABLE really deletes |
| 4 | No QUALIFY in open source Spark, and the row_number() workaround |
| 5 | GROUPING SETS: three breakdowns in one query |
| 6 | TRY_CAST and NULL semantics |
| 7 | ANSI mode: the same bad query, two different outcomes |

Run it:

```bash
./run.sh labs/09_lab_sql.py
```

The two demo tables in step 3 are dropped by the lab itself before it
finishes, so nothing is left behind in `data/warehouse`.

## Common mistakes

| Mistake | Real cause | Fix |
|---|---|---|
| `QUALIFY` used in a Spark SQL query | copied straight from a Teradata or Oracle script | wrap the window function in a subquery, filter the outer query instead |
| Data files vanish after cleaning up a "temporary" table | `DROP TABLE` was run on a MANAGED table other jobs also depended on | check `DESCRIBE FORMATTED table_name` for the Location and table type before dropping anything shared |
| `WHERE col = NULL` returns nothing, and nobody notices | NULL comparison habit carried over from another SQL dialect where this sometimes behaves differently | use `IS NULL`, always, for NULL checks |
| A query "loses" rows compared to the same one in Teradata | ANSI mode is on here but the equivalent Teradata query tolerated a bad cast or a divide by zero | use `TRY_CAST` / `TRY_DIVIDE` for the specific expressions that should tolerate bad data |
| A temp view "disappears" | the SparkSession restarted, temp views do not survive that | temp views are session-scoped by design, persist real data through a managed or external table instead |
| A SQL string built from user input behaves unexpectedly, or worse | values interpolated directly into an f-string instead of passed as parameters | use Spark SQL's named parameters for anything not fully controlled by the pipeline's own code |

## Exercises

1. Rewrite the `GROUPING SETS` query in this module as three separate
   `GROUP BY` queries, unioned together with `UNION ALL`. Confirm the
   row counts match. Which version reads the data fewer times?

2. Write a `QUALIFY`-style query, using the row_number() subquery
   pattern, that returns each account's SECOND highest transaction
   instead of its highest.

3. Create one managed table and one external table from the same
   DataFrame. Delete the external table's underlying files directly
   from the filesystem, then query the external table again. Explain
   what you see and why.

4. With ANSI mode on, find a query in this lab file that would now raise
   an error if `txn_ts` contained a string that could not parse as a
   date. Explain how `TRY_CAST` would change that behaviour. Then
   rewrite the parameterised query example in this module so `channel`
   comes from a Python list of several values instead of one string,
   confirming it still avoids building the SQL text with an f-string.

## Key points

- The DataFrame API and SQL compile to the same plan. Choosing between them is a style decision, not a performance one.
- `DROP TABLE` on a managed table deletes the data. On an external table it deletes only the metadata.
- Open source Spark SQL has no `QUALIFY`. Wrap the window function in a subquery and filter the outer query.
- `NULL = NULL` is never TRUE. Use `IS NULL`, and `COALESCE` to substitute a default value.
- ANSI mode changes whether a bad expression raises an error or quietly returns NULL, for the whole session.
