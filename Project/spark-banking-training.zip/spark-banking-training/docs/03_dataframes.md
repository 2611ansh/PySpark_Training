# Module 03: DataFrames

After this module you can read a real, dirty CSV feed with a proper schema, clean it, join it safely, and write the result as Parquet.

This is the module where Module 02's architecture ideas, schemas built without a job, wide joins and their shuffles, broadcast joins, finally get used on a real problem instead of a demonstration.

By the end, `labs/03_lab_dataframes.py` has taken the raw transactions feed all the way to a cleaned, joined, aggregated, Parquet-written result, the same shape Module 04 scales up to a full production-style layout.

Keep that shape in mind as you work through the sections below: read, understand the defects, clean, join carefully, summarise, write.

## Why this matters in a bank

Every pipeline in this course, and almost every batch pipeline at a real bank, has the same shape: read a feed, deal with its known defects, join it to reference data, summarise it, write the result somewhere durable. This module is that shape, done once, carefully, on the transactions feed you will keep using for the rest of the course.

The feed this module reads is deliberately dirty, in specific, documented ways: about 6 percent of `channel` values are padded and lower case, about 7 percent of `merchant_category` values are empty, and about 0.5 percent of `account_id` values do not exist in `accounts.csv`. None of this is a mistake in the training data. It is there because every one of these defects shows up in real core banking feeds, and this module is where you learn to handle each one deliberately instead of by accident.

A reconciliation team that trusts an `inner` join by habit, on a feed with even a small orphan rate, will eventually present a total that does not match the source system, with no error anywhere in the pipeline to point at. The join ran, it returned rows, nothing crashed. The rows are simply gone. This module's orphan-account lesson exists specifically to make that failure mode visible and deliberate, instead of silent.

## 1. Read with an explicit schema

```python
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()),
    StructField("txn_ts", StringType()), StructField("amount", DoubleType()),
    StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()), StructField("status", StringType()),
    StructField("device_id", StringType()), StructField("city", StringType())])

txns = spark.read.option("header", True).schema(schema).csv("data/raw/transactions/*.csv")
```

Declaring the schema is not extra ceremony, it is the safer default. Without it, Spark has to guess, and a guess can be wrong or can change when next month's file has slightly different values in the first rows it samples.

A `StructField` takes a name, a type, and an optional `nullable` flag (`True` by default). The common types you will use for a CSV or database feed:

| Type | Python values it holds |
|---|---|
| `StringType()` | text, and this course's default choice for any column you are not certain about |
| `DoubleType()` | decimal numbers, `amount`, `balance`, `interest_rate` |
| `IntegerType()`, `LongType()` | whole numbers, `dob_year`, a count column |
| `DateType()`, `TimestampType()` | dates and date-times, once you are ready to parse them, see the next section |

Notice `txn_ts` is read as `StringType()`, not `TimestampType()`, in this lab. Reading it as a string first and converting deliberately with `F.to_timestamp()` when needed is often safer than letting the CSV reader parse it, because a CSV reader's default timestamp format may not match your feed's actual format, and a mismatch there fails silently into nulls.

One distinction worth having clear before the next two sections: a schema tells Spark what SHAPE and TYPE each column should be. A read mode, section 3 below, tells Spark what to do when a ROW does not fit that shape at all, for example one with the wrong number of fields. They solve different problems, and this module covers both.

## 2. inferSchema: why we do not use it

`inferSchema=True` asks Spark to read the whole file once just to guess column types, then read it again for the real work. You can see the extra cost even before you call an action.

```python
explicit = spark.read.option("header", True).schema(schema).csv(path)          # 0 jobs to build
guessed = spark.read.option("header", True).option("inferSchema", True).csv(path)   # 2 jobs, just to build
```

On this course's transactions feed, that guess costs a few seconds before a single row of real work has run. On a production feed a hundred times the size, that cost scales the same way, every single time the job runs, for no benefit over just writing the schema down once.

There is also a correctness risk, not only a speed one. `inferSchema` samples the data to guess a type. If the first rows it samples for a column happen to look like whole numbers, it may infer an integer type, then fail or silently corrupt values the day a row with a decimal appears. An explicit schema does not guess, so it cannot guess wrong.

The one place `inferSchema` is genuinely reasonable is ad hoc, exploratory work, a data scientist poking at a brand new feed for the first time in a notebook, with no schema documentation yet to work from. Even then, the right next step is to write down what was discovered as an explicit schema before that code runs again, not to leave `inferSchema=True` in place.

```python
guessed.printSchema()   # inspect what Spark guessed
guessed.schema          # copy this as a starting point for a real StructType
```

## 3. Read modes: PERMISSIVE, DROPMALFORMED, FAILFAST

The `mode` option controls what Spark does when a row does not match the schema it was given, for example a row with more or fewer fields than expected.

| Mode | Behaviour | When to use it |
|---|---|---|
| `PERMISSIVE` (the default) | keeps the row, fills what it can, nulls the rest | you want to see everything, and handle bad rows yourself downstream |
| `DROPMALFORMED` | silently drops the row | you are certain a malformed row is safe to lose, rare in a banking feed |
| `FAILFAST` | stops the whole read with an exception | you want the job to fail loudly the moment the feed breaks its contract |

```python
spark.read.option("header", True).schema(schema).option("mode", "FAILFAST").csv(path)
```

One detail worth knowing before you rely on this in a live demo: `.count()` alone can look like it found no bad rows, because counting does not always need to parse every column. Force a full read, for example with `.collect()`, to get a reading mode's real answer.

For this course, we quarantine bad rows ourselves in Module 04, which gives us a reason FOR the row failed, not just PERMISSIVE's silent nulls or DROPMALFORMED's silent loss. Read modes are a first line of defence at the file-parsing level. Module 04's quarantine pattern is the second line, for defects a schema mismatch cannot catch, like a negative amount.

PERMISSIVE mode has one more feature worth knowing: `columnNameOfCorruptRecord`. Add an extra, nullable `StringType()` column to your schema with this name, and set the matching option, and PERMISSIVE mode fills it with the raw, original text of any row it could not fully parse.

```python
schema_with_corrupt = schema.add("_corrupt_record", StringType())
spark.read.option("header", True).schema(schema_with_corrupt) \
    .option("columnNameOfCorruptRecord", "_corrupt_record").csv(path)
```

This gives you the best of both worlds for a one-off investigation: every row is kept, AND the rows that did not parse cleanly are easy to filter out and inspect, `_corrupt_record` will be non-null only for them.

## 4. Clean the dirty columns in this feed

Two columns in this feed have known, specific defects.

```python
cleaned = (txns
    .withColumn("channel", F.upper(F.trim(F.col("channel"))))
    .withColumn("merchant_category", F.when(F.col("merchant_category") == "", "UNKNOWN")
                                       .otherwise(F.col("merchant_category"))))
```

| Column | Defect | Rate | Fix |
|---|---|---|---|
| `channel` | padded, mixed case, e.g. `" upi "` | about 6% | `F.trim()` then `F.upper()` |
| `merchant_category` | empty string, not null | about 7% | `F.when(... == "", "UNKNOWN").otherwise(...)` |

Notice `merchant_category` arrives as an EMPTY STRING, not a SQL null. `F.col("merchant_category").isNull()` would miss every one of these rows. Checking `== ""` is what actually catches them. This is a common, easy-to-miss distinction: a source system's idea of "no value" is not always Spark's.

A cleaner, more general version handles both cases in one line, useful once you are not certain which one a given feed uses:

```python
.withColumn("merchant_category",
    F.when(F.trim(F.coalesce(F.col("merchant_category"), F.lit(""))) == "", "UNKNOWN")
     .otherwise(F.col("merchant_category")))
```

`F.coalesce(a, b)` returns the first non-null argument, here turning a real null into an empty string so the same `== ""` check catches both a true null and an empty string in one expression.

Chaining several `.withColumn()` calls, as `cleaned` does, is a common and readable pattern. Each call adds one clearly named step, and the whole chain still costs nothing until an action runs, per Module 02.

Avoid calling `.withColumn()` in a Python loop with dozens of iterations on very wide tables. Each call adds a step to Catalyst's plan, and an extremely long chain can slow down PLANNING itself, separate from the cost of running the plan. For a handful of columns, as in this lab, it is never a concern.

## Handling nulls, a quick reference

Nulls come up constantly once you start joining and cleaning real data. A quick reference for the functions you will reach for most:

| Function | Does |
|---|---|
| `F.col("x").isNull()`, `.isNotNull()` | test for a SQL null, use in a `.filter()` or `.when()` |
| `F.coalesce(a, b, c)` | returns the first non-null of several columns |
| `df.na.fill(value)` | replaces every null in every column with `value`, or pass a dict for per-column values |
| `df.na.drop()` | drops any row with a null in ANY column, or pass `subset=[...]` to check only specific columns |
| `df.fillna(...)`, `df.dropna(...)` | shorter aliases for the two above |

`df.na.fill({"merchant_category": "UNKNOWN", "amount": 0})` fills different columns with different defaults in one call, useful once a cleaning step touches several columns at once instead of one `.withColumn()` at a time.

Be careful with `df.na.drop()` with no arguments on a wide table. It drops a row if ANY column is null, which on a table with dozens of columns can silently remove far more rows than you intended. Prefer `subset=[...]` naming exactly the columns that must not be null.

## 5. Joins: the orphan-account lesson

About 0.5 percent of transactions carry an `account_id` that does not exist in `accounts.csv`, a downstream system effect, a closed account, a data entry error upstream, the exact cause does not matter here. What matters is what your join does with it.

```python
inner = cleaned.join(accounts, "account_id", "inner")   # silently drops orphan rows
left = cleaned.join(accounts, "account_id", "left")     # keeps them, branch_code comes back null

orphans = left.filter(F.col("branch_code").isNull())
print(orphans.count())   # every row an inner join would have quietly deleted
```

An `inner` join treats "no match" as "this row does not exist". For a lookup that genuinely should never miss, that might be fine. For a transactions feed, it is not: those rows are real money movements, and silently dropping them from a reconciliation report is the kind of bug that surfaces three weeks later as a number that does not add up, with no error message pointing at the cause.

| Join type | Orphan rows | Use it when |
|---|---|---|
| `inner` | dropped, no warning | you are CERTAIN every row must match, and want a clean result |
| `left` | kept, unmatched columns are null | you need to know WHAT did not match, which is almost always the safer default for a fact table |

The rule of thumb for a banking feed: default to `left`, and explicitly count and inspect what came back null. Reach for `inner` only when a missing match genuinely means "not interested in this row", not when it means "something is wrong and I have not noticed".

There are two more join types worth knowing, even though this lab does not use them:

| Join type | Keeps |
|---|---|
| `right` | every row from the right side, nulls on the left for no match, the mirror image of `left` |
| `full` (or `outer`) | every row from BOTH sides, nulls wherever a side has no match |
| `anti` | only rows from the left with NO match on the right, useful to isolate orphans directly |

`left_anti` is worth calling out on its own, since it is exactly what the orphan check above is doing in two steps.

```python
orphans_direct = cleaned.join(accounts, "account_id", "left_anti")
```

This gives you the orphan rows in one join instead of a join plus a filter, and reads slightly more directly as "transactions with no matching account".

## 6. Broadcast join to the 36-row branch table

`branches.csv` has 36 rows, small enough to fit in memory on every executor many times over. Copying it everywhere, instead of shuffling the much bigger transactions table to match it, is a **broadcast join**.

```python
with_branch = inner.join(F.broadcast(branches), "branch_code")
with_branch.explain()
# look for BroadcastHashJoin, not SortMergeJoin
```

| Join strategy | What moves | Cost |
|---|---|---|
| `SortMergeJoin` (the default for two large tables) | both sides, shuffled and sorted by the join key | expensive, a full shuffle |
| `BroadcastHashJoin` (forced with `F.broadcast()`) | only the small side, copied to every executor | cheap, no shuffle of the large side |

Spark has a default size threshold (`spark.sql.autoBroadcastJoinThreshold`, 10 MB by default) under which it may choose to broadcast automatically, without being asked. Calling `F.broadcast()` explicitly does two things: it guarantees the choice regardless of that threshold, and it tells the next person reading the code exactly what you intended, instead of leaving it to Spark's judgement on that day's data size.

Do not broadcast a table you are not sure is small. Forcing a broadcast of a large DataFrame can crash executors that run out of memory holding a copy each, or make the job far slower than the shuffle it was meant to avoid. `branches.csv`, 36 rows, is an easy, safe call. `accounts.csv`, 12,000 rows, is still comfortably small enough here, but on a real core banking accounts table with tens of millions of rows, it would not be.

This lab actually broadcasts `branches` while joining to the already-inner-joined `accounts` result, which is a plain, unbroadcast join. That is deliberate: `accounts.csv` at 12,000 rows is well under Spark's own auto-broadcast threshold, so Spark's default behaviour already broadcasts it without being asked, which you can confirm yourself in `explain()`.

A useful check before broadcasting anything you are unsure about:

```python
accounts.count()                              # how many rows
len(accounts.head(1)[0]) if accounts.head(1) else 0   # how many columns, roughly
```

There is no single row-count rule that always applies, since row width matters as much as row count. When in doubt, let `spark.sql.autoBroadcastJoinThreshold` make the call automatically instead of forcing it.

Read the threshold currently in effect with `spark.conf.get("spark.sql.autoBroadcastJoinThreshold")`. It is set in bytes, and `-1` disables automatic broadcasting entirely, a setting sometimes used in Module 14 to force a specific join strategy for a controlled comparison.

## 7. Aggregations

The usual SQL aggregate functions are available as `pyspark.sql.functions`: `F.count()`, `F.sum()`, `F.avg()`, `F.min()`, `F.max()`, alongside `groupBy()`.

```python
by_channel = (with_branch.groupBy("channel")
    .agg(F.count("*").alias("txn_count"),
         F.round(F.sum("amount"), 2).alias("total_amount"),
         F.round(F.avg("amount"), 2).alias("avg_amount"))
    .orderBy(F.desc("txn_count")))
```

`.alias(...)` names the result column. Without it, Spark generates a name like `sum(amount)`, which works but reads poorly in the output and in anything downstream that reads this DataFrame's columns by name.

`groupBy().agg(...)` is a wide transformation, covered in Module 02. Every `groupBy` you write from here on is a shuffle, and its cost scales with how many distinct groups and how much data feeds into it, not with how short the line of code looks.

A few more aggregate functions worth knowing, beyond the four used above:

| Function | Returns |
|---|---|
| `F.countDistinct("account_id")` | number of DISTINCT values, not just row count |
| `F.stddev("amount")`, `F.variance("amount")` | spread of the values in a group |
| `F.first("status")`, `F.last("status")` | one value from the group, order-dependent, use with care |
| `F.collect_list("channel")`, `F.collect_set("channel")` | every value, or every distinct value, gathered into an array per group |
| `F.min("amount")`, `F.max("amount")` | smallest and largest value in a group |

`.groupBy("channel").agg(...)` with a single grouping column, as this lab does, is the simplest case. `groupBy("channel", "txn_type")` groups by the combination of both, giving one row per distinct pair, exactly like `GROUP BY` with two columns in SQL.

## 8. Writing Parquet

```python
with_branch.select("txn_id", "account_id", "branch_code", "region", "channel",
                    "merchant_category", "amount", "txn_type", "status") \
    .write.mode("overwrite").parquet(out_path)
```

| Write mode | Behaviour |
|---|---|
| `"overwrite"` | replaces everything at the path, the safe default for a lab you might rerun |
| `"append"` | adds new files alongside whatever is already there |
| `"error"` (the default if you do not set one) | fails if the path already has data |
| `"ignore"` | does nothing if the path already has data |

`mode("overwrite")` replaces the whole path's worth of data, not just the rows this write touches. Module 04 shows a more targeted alternative, dynamic partition overwrite, for replacing only part of a table without touching the rest.

Parquet, not CSV, is the format to write intermediate and final results in. It stores the schema WITH the data, so nothing downstream has to guess it, it compresses well, and it lets a later read skip whole columns and row groups it does not need. Module 04 goes deeper into Parquet and the medallion pattern of layered tables.

| | CSV | Parquet |
|---|---|---|
| Schema | not stored, must be declared on every read | stored with the file, read automatically |
| Column storage | row by row | column by column, so reading 3 of 12 columns only reads those 3 |
| Compression | none by default, large on disk | built in, typically much smaller on disk |
| Human readable | yes, open it in a text editor | no, needs a tool that understands the format |

A read of a Parquet file for just `txn_id` and `amount` genuinely reads less data off disk than a read of the same two columns from a CSV, because Parquet stores each column separately. This is called **column pruning**, and `explain()` shows it in the `ReadSchema` line of a Parquet scan. CSV cannot do this at all, every row must be read in full regardless of which columns you asked for.

This lab's write is a PRACTICE output only, kept separate from the real, reconciled warehouse. Module 04 builds the bronze, silver and gold layers that the rest of the course actually reads from, with the quarantine pattern for bad rows this module's read modes only partially cover.

## Two ways to build a column expression

You will see both styles in real PySpark code, and both appear in this course.

```python
df.select("txn_id", F.col("amount") * 2)          # column-expression style
df.selectExpr("txn_id", "amount * 2 as doubled")   # SQL-string style
```

`F.col(...)` builds a column expression in Python, checked by your editor and by Spark at plan-build time. `selectExpr(...)` takes a SQL string and parses it at runtime. Both produce the same plan. This course uses the `F.col()` style throughout, because it composes more easily, an `F.when(...)` chain, a filter condition, a join key, are all built the same way, whereas SQL strings need to be built up as text.

Module 09 covers writing full SQL queries against a DataFrame with `spark.sql(...)`, a third style, useful when a query is naturally easier to read as SQL than as chained method calls.

All three styles compile to the SAME underlying plan. Picking one is a readability choice for your team, not a performance choice. Mixing all three inside one short block of code, though, makes a file harder to follow, so pick one style for a given piece of logic and stay with it.

## select vs withColumn

`select()` replaces the full column list. `withColumn()` keeps every existing column and adds or replaces just one.

```python
txns.select("txn_id", "amount")                       # ONLY these two columns survive
txns.withColumn("amount_doubled", F.col("amount") * 2)  # every original column, plus this new one
```

A common early mistake is reaching for `select()` with a long list of every column just to add one new one. `withColumn()` says what actually changed, and is easier for the next reader to see at a glance.

## The lab

`labs/03_lab_dataframes.py` runs every idea above against the real transactions feed.

| Step | Shows |
|---|---|
| 1 | Read the transactions with an explicit schema |
| 2 | inferSchema: jobs and time spent before any action runs |
| 3 | Read modes: PERMISSIVE, DROPMALFORMED, FAILFAST on a malformed row |
| 4 | Clean `channel` and `merchant_category` |
| 5 | Inner vs left join to accounts, counting orphan transactions |
| 6 | Broadcast join to the 36-row branch table, `explain()` proof |
| 7 | Aggregations by channel |
| 8 | Writing the cleaned, joined result as Parquet |

Run it with the Spark UI open, the same habit Module 02 asked you to build. Step 6's broadcast join is worth clicking into on the SQL tab: you will see the small side's `BroadcastExchange` box, and can compare its size to the much larger `FileScan` box on the other side.

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| `merchant_category.isNull()` misses dirty rows | the defect is an empty string, not a SQL null | check `== ""` as well as `isNull()` |
| Row counts drop after a join, with no error | used `inner` on a feed with orphan foreign keys | use `left`, then explicitly count and inspect the nulls |
| A join that should be fast is slow, with a `SortMergeJoin` in `explain()` | forgot `F.broadcast()` on the small side | wrap the small DataFrame in `F.broadcast()` explicitly |
| `DROPMALFORMED` looks like it kept a bad row | called `.count()`, which can skip full-row parsing | use `.collect()` or select every column before trusting the count |
| A groupBy result column named `sum(amount)` breaks downstream code | forgot `.alias(...)` | always alias an aggregate you plan to reference by name later |
| `inferSchema=True` left in a scheduled job | copied from a quick, one-off notebook exploration | replace with an explicit schema before anything runs unattended |
| `.select()` with every column just to add one | did not know `withColumn()` keeps the rest automatically | use `withColumn()` when adding or replacing a single column |
| A null slips through a `.na.fill()` on the wrong column | filled a default on the whole DataFrame instead of the specific column that needed it | pass a dict to `.na.fill({...})`, one default per column |
| `F.broadcast()` on a table nobody checked the size of | assumed small without measuring | count rows, and roughly estimate column width, before forcing a broadcast |

## Exercises

1. Add a data quality check: count how many rows have `amount < 0`. These are covered properly in Module 08, but confirm you can find them here with a plain `.filter()`.
2. Change the join in step 5 to also print the DISTINCT orphan `account_id` values, not just the count.
3. Remove `F.broadcast()` from step 6 and compare the `explain()` output and run time to the broadcast version.
4. Add a second aggregation, by `merchant_category` instead of `channel`, and write it as a separate Parquet output.
5. Rewrite the orphan check in step 5 using `left_anti` instead of `left` plus a filter. Confirm the row count matches.
6. Add a `columnNameOfCorruptRecord` column to the schema used in step 3, and print the raw text of the malformed row it captures.
7. Read `spark.sql.autoBroadcastJoinThreshold` with `spark.conf.get(...)`, then set it to `-1` and rerun exercise 3's unbroadcast join. Confirm `explain()` now shows a `SortMergeJoin` where it previously auto-broadcast.

## Key points

- Always declare a schema. `inferSchema` costs jobs and time before any real work starts, and can guess wrong.
- A dirty column's defect is specific. `channel` needs trim and upper case. `merchant_category`'s "missing" value is an empty string, not null. Know the defect before you write the fix.
- Default to a `left` join on a fact table. An `inner` join silently deletes rows that do not match, with no warning.
- `F.broadcast()` on a small table turns an expensive shuffle join into a cheap one. `explain()` proves which strategy actually ran.
- Parquet, not CSV, for anything written between pipeline stages. Module 04 builds on this with the full bronze, silver, gold layering.
- `withColumn()` keeps every existing column and changes one. `select()` replaces the whole column list. Reach for the one that matches what you actually mean.
- `F.coalesce()`, `.na.fill()` and `.na.drop()` cover most null handling. Know which columns in a feed use null vs an empty string for "no value".
- `F.col()`, `selectExpr()` and `spark.sql()` all compile to the same plan. Pick one style per piece of logic and stay consistent.
- Run this lab with the Spark UI open. Module 02's habit of checking `explain()` and the Stages tab applies to every join and aggregation you write from here on.
