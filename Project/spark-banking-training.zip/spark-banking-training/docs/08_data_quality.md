# Module 08: Data quality and profiling

After this module you can profile a new feed, turn its defects into real
numbers, run a small rule framework in one pass, and reconcile two
layers of a pipeline against each other.

## Why this matters in a bank

A bank's data quality problem is rarely "the data is wrong". It is
"nobody can say HOW wrong, by how much, or since when". A regulator, an
auditor, or a downstream team asking "can I trust this feed" needs a
number, not a feeling. This module turns "the feed looks dirty" into
"0.40% of rows are exact duplicates, 7.07% have no merchant category",
which is the difference between a guess and something you can act on.

The four pieces in this module, profiling, quantifying, a rule
framework, and reconciliation, are not four separate tools. They are
four questions asked of the same pipeline, in order: what does this
data look like, how bad are its known problems, does it pass the rules
the business actually cares about, and did anything go missing on the
way from one layer to the next.

## Profiling a new feed

Before writing a single rule, know the shape of what you have. Four
questions, answered with a handful of Spark actions.

```python
total = txns.count()
blanks = txns.filter(F.col("merchant_category").isNull() | (F.col("merchant_category") == "")).count()
distinct_channels = txns.select("channel").distinct().count()
date_min, date_max = txns.select(F.min("txn_ts"), F.max("txn_ts")).first()
```

| Question | What it catches |
|---|---|
| How many rows, really? | a silent partial load, or a duplicated file |
| How many blank or NULL in each key column? | a source system field that stopped being populated |
| How many distinct values in a category column? | 16 "channels" when the business only has 8 real ones, a sign the column is dirty |
| What is the date range? | a feed that arrived with last month's file by mistake |

None of this needs a rule engine yet. It is a first look, the same four
questions any analyst should ask before trusting a new feed at all.

### Exact vs approximate distinct counts

This is a performance choice, not a correctness one: pick the right tool for the size of the column, not a fixed habit.

`countDistinct` is exact, and on a huge column, for example a bank's
full customer base across years of history, it is also expensive: Spark
has to shuffle every value to find the true distinct set.
`approx_count_distinct` trades a small, known error rate for a much
cheaper computation:

```python
txns.select(F.approx_count_distinct("account_id")).show()   # within about 5% by default, much cheaper
```

On this course's 180,720 row feed the difference is not worth noticing.
On a table with hundreds of millions of rows, an approximate count that
finishes in seconds is often more useful than an exact one that finishes
in an hour, especially for a profiling step that runs before every
batch, not a number the business is making a final decision on. Keep the
exact version for the numbers that go into a report someone signs off
on, and the approximate version for the numbers that only decide whether
to keep looking.

### NULL and blank are two different defects

A column can be missing in two different ways, and they usually point to
two different root causes. NULL means the source system sent nothing.
An empty string means it sent something, and that something was
nothing, which is a different failure further upstream.

```python
nulls = txns.filter(F.col("merchant_category").isNull()).count()
blanks = txns.filter(F.col("merchant_category") == "").count()
```

On this course's feed, `merchant_category` is empty STRING, never NULL,
because the generator writes `""` for a missing category, not a missing
field. A profiling check that only tests `IS NULL` would report zero
problems on this column and miss the entire 7.07% defect. Always test
for both, and treat a mismatch between the two counts as its own clue
about where in the pipeline the value went missing. This is also why the
rule table's `category_not_empty` condition explicitly checks both
`IS NOT NULL` and `!= ''`, not just one of them.

## Quantify this feed's five deliberate defects

This course's data was generated with five specific, teachable defects.
Profiling turns each into a number instead of a suspicion.

| Defect | How to measure it |
|---|---|
| Duplicate txn_id | `total_rows - df.select("txn_id").distinct().count()` |
| Orphan account_id | left join to `accounts.csv`, count where the match is NULL |
| Negative amount | `df.filter("amount < 0").count()` |
| Dirty channel, e.g. `" upi "` | `df.filter(col("channel") != upper(trim(col("channel"))))` |
| Empty merchant_category | `df.filter("merchant_category IS NULL OR merchant_category = ''")` |

On this course's feed, that gives:

| Defect | Rows | Percent of feed |
|---|---|---|
| duplicate txn_id | 720 | 0.40% |
| orphan account_id | 904 | 0.50% |
| negative amount | 383 | 0.21% |
| dirty channel | 10,778 | 5.96% |
| empty merchant_category | 12,783 | 7.07% |

The percentages matter more than the raw counts. 0.21% negative amounts
might be an acceptable, known issue a downstream rule already handles.
7.07% missing category might be well over a threshold the business
agreed to, and worth stopping the pipeline for.

## A small, copyable data quality rule table

A rule table is a list of (name, condition) pairs. GOOD rows satisfy the
condition. Nothing more is needed to define a rule.

```python
RULES = [
    ("no_negative_amount", "amount >= 0"),
    ("account_is_known", "account_known"),
    ("channel_is_clean", "channel = upper(trim(channel))"),
    ("category_not_empty", "merchant_category IS NOT NULL AND merchant_category != ''"),
    ("status_is_valid", "status IN ('SUCCESS', 'FAILED', 'PENDING')"),
]
```

Adding a bank rule, for example "amount must be under a branch's daily
limit", means adding one tuple to this list. Nothing else in the
pipeline changes. That is the whole point of the pattern: it should look
copyable, not clever, so the next person who needs a new rule can add
one without understanding the rest of the file.

```python
RULES.append(("under_daily_limit", "amount <= 200000"))
```

One line, and the new rule is included in step 4's single-pass
aggregate automatically, with no other code to touch. The dq_results
table, the write path, and the pass or fail logic all stay exactly as
they were.

## Run every rule in one pass

"One pass" means Spark reads the data ONCE, not once per rule. One
aggregate expression per rule, all evaluated together:

```python
fail_exprs = [F.sum(F.when(~F.expr(cond), 1).otherwise(0)).alias(name) for name, cond in RULES]
totals = tagged.agg(F.count("*").alias("total_rows"), *fail_exprs).first()
```

Five separate `.filter(...).count()` calls would scan the table five
times. This scans it once, and returns one row with five fail counts, a
building block cheap enough to run on every batch, not just when
someone remembers to check.

From the counts, build a small results table and write it out:

```python
rows = [(name, cond, totals[name], totals["total_rows"],
         round(totals[name] / totals["total_rows"] * 100, 3),
         "FAIL" if totals[name] / totals["total_rows"] * 100 > 1.0 else "PASS")
        for name, cond in RULES]
dq_results = spark.createDataFrame(rows, ["rule_name", "condition", "fail_count", "total_rows", "fail_pct", "verdict"])
dq_results.write.mode("overwrite").parquet(f"{WAREHOUSE}/dq_results")
```

`dq_results` is a small table, one row per rule, written every run. That
is what makes "is this feed getting worse over time" answerable later:
compare today's `fail_pct` for `channel_is_clean` against last month's,
from the same table, instead of re-running the profiling from scratch.

### Thresholds and the fail-the-job pattern

A 1% threshold in this lab is a placeholder. In production the threshold
comes from the business, per rule, not one number for everything: a
missing merchant category might be fine up to 10%, while even one
orphan account_id might be worth stopping the job over, since money is
moving against an account that officially does not exist.

```python
critical = dq_results.filter("rule_name = 'account_is_known' AND fail_count > 0")
if critical.count() > 0:
    raise ValueError("orphan accounts found, stopping before silver is written")
```

Whether a failed rule stops the pipeline, or just gets logged for
someone to look at tomorrow, is a business decision. The rule framework
only needs to produce the number; deciding what happens next is a
policy, not a Spark question.

A reasonable STARTING point for setting thresholds, to be replaced with
real numbers from the business once they exist:

| Kind of rule | Starting threshold | Why |
|---|---|---|
| Referential integrity, e.g. orphan account_id | fail on any occurrence | money should never move against an account that does not exist |
| A value outside a hard business rule, e.g. negative amount on a CREDIT | fail on any occurrence | usually a sign of an upstream bug, not natural variation |
| Formatting, e.g. dirty channel casing | a generous percentage, tune down over time | annoying, not dangerous, and easy to clean in silver |
| Missing optional context, e.g. empty merchant_category | a generous percentage | often genuinely optional at the source, not a pipeline defect |
| Duplicate rows, e.g. duplicate txn_id | fail above a small percentage, well under 1% | a growing duplicate rate usually means a feed replay bug got worse, not better |

These starting points come from one general pattern: rules about whether
money and identity are correct get a strict threshold, rules about
whether a field is nicely formatted or fully populated get a loose one.
Revisit every threshold once real production numbers exist. A rule that
never fails in a month is probably too loose to catch anything. A rule
that fails every single run has stopped being useful as a signal, and is
worth investigating as a real, ongoing problem instead of muting.

## Reconciliation

Profiling one table tells you about that table. Reconciliation tells you
whether two RELATED tables still agree, which is where a silently
dropped row actually gets caught. Two layers can each look individually
fine, correct row counts, no obvious nulls, and still disagree with each
other, which is exactly the failure profiling alone cannot see.

```python
bronze_n = bronze.count()
duplicates_removed = bronze_n - bronze.dropDuplicates(["txn_id"]).count()
silver_n = silver.count()
quarantine_n = quarantine.count()

tie = (bronze_n - duplicates_removed) == (silver_n + quarantine_n)
```

The identity is simple on purpose: every row that entered bronze, minus
the exact duplicates, must land in EXACTLY ONE of silver or quarantine.
Not zero, which means a row vanished. Not two, which means a row was
double-counted. If Lab 04 has already run, this lab reads its real
bronze layer; if not, it rebuilds bronze from the raw feed and derives
silver and quarantine with the same rule this lab already checked, so
the identity holds by construction either way.

### What a broken reconciliation looks like

Concretely, on this course's numbers: bronze has 180,720 rows, 720 of
them exact duplicates, so 180,000 rows should be accounted for. If
silver has 178,719 rows and quarantine has 1,281, that is 180,000 total,
and the identity holds. If someone later changes quarantine's filter to
also exclude the negative-amount rows found in step 2's profiling
WITHOUT updating silver's filter to match, the two numbers stop summing
to 180,000, and the reconciliation check is what catches it, often
before anyone notices the actual report numbers look slightly off,
which is usually weeks later and much harder to trace back.

### Why "ties" is not the same as "is correct"

A reconciliation that ties proves nothing was silently dropped or
duplicated. It does NOT prove the business logic inside silver is
right. A silver table built with an inverted condition, keeping bad
rows and quarantining good ones, would still tie perfectly: every row
still lands in exactly one place. Reconciliation catches missing and
duplicated rows. The rule table catches wrong rows. Both are needed.

## Off-the-shelf alternatives for a larger rule set

This lab's rule framework is deliberately small enough to type from
memory. For a production system with dozens of tables and hundreds of
rules, purpose-built tools exist and are usually a better investment
than growing this pattern by hand indefinitely.

| Tool | What it adds over this lab's pattern |
|---|---|
| Great Expectations | a large library of pre-built rule types, and a standard report format |
| Deequ (on Spark) | rules that estimate their own statistical confidence, built by Amazon for exactly this scale |
| dbt tests | rules defined next to the SQL models they check, if the warehouse layer is dbt-managed |
| Soda Core | a YAML-based rule language, aimed at teams who want rules defined outside of Python code |

Knowing this lab's pattern by hand still matters even if a team adopts
one of these: every one of them is built on the same idea, a condition
per rule and a pass or fail count, just with more infrastructure around
it. A team that understands this lab's version can read what a
generated Great Expectations report is actually checking, instead of
treating it as a black box that occasionally turns red.

## The lab

`labs/08_lab_data_quality.py`, 70 minutes.

| Step | What it shows |
|---|---|
| 1 | Profile the feed: counts, blanks, distincts, date range |
| 2 | Quantify this feed's five deliberate defects as real numbers |
| 3 | A small, copyable data quality rule table |
| 4 | Run every rule in one pass, write dq_results |
| 5 | Reconcile bronze against silver: counts and sums that must tie |

Run it:

```bash
./run.sh labs/08_lab_data_quality.py
```

Step 5 checks for Lab 04's bronze layer first. If it has not run yet,
the lab prints a one line note and rebuilds a small bronze stand-in from
the raw feed, so this lab still runs and still teaches the
reconciliation technique on its own. Run Lab 04 first if you want to see
this lab reconcile against the real medallion layers instead.

## Common mistakes

| Mistake | Real cause | Fix |
|---|---|---|
| The rule table says PASS but the pipeline is clearly broken | a rule's condition is inverted, or too lenient, for example `amount IS NOT NULL` when the real risk is negative amounts | read every condition out loud as "good rows satisfy this", and check it against a row you know is bad |
| Reconciliation never ties, even though the pipeline looks right | comparing bronze against a silver table that was reprocessed later, for example after a correction file changed one day's data | reconcile against the SAME snapshot of the data on both sides, not bronze-then against silver-now |
| `dq_results` grows without anyone noticing a trend | it is written, but nobody ever queries the history | plot `fail_pct` for one rule over time before treating any single run's number as meaningful |
| Five separate `.count()` calls used for the rule table instead of one aggregate | copied from the profiling step, where five actions were fine because it was a one-off, not a per-batch job | use one `.agg(...)` with a `F.when(...)` expression per rule |
| A rule passes in the lab but fails in production | the lab's threshold, 1% here, was copied as-is instead of being set per rule by the business | get a real threshold per rule from whoever owns that data, do not reuse a lab placeholder |
| A column reports zero defects, but the data is clearly missing values | the check tested `IS NULL` on a column where missing values are actually empty strings, or the reverse | test both NULL and blank, and compare the two counts, do not assume which one the source system uses |
| Approximate distinct counts do not match the exact ones, and someone flags it as a bug | this is expected: `approx_count_distinct` trades a small error for speed | only use the approximate version where a small error is acceptable, keep exact counts for signed-off numbers |

## Exercises

1. Add a sixth rule: `currency_is_inr`, checking `currency = 'INR'`. Run
   the lab again and report its fail count. Is this rule ever expected
   to fail on this feed, based on what you saw in `forex_rates.csv`? If
   it never fails, is it still worth keeping in the rule table?

2. Change the threshold for `category_not_empty` to 10% instead of 1%,
   only for that one rule, while leaving the others at 1%. Rerun and
   confirm its verdict changes from FAIL to PASS. Write one sentence
   justifying why 10% is, or is not, a reasonable number for this
   particular column.

3. Deliberately break the reconciliation: filter `silver` down to only
   `posting_date = '2026-09-01'` before the tie check, without changing
   `bronze`. Confirm the identity now reports False, and explain in one
   sentence what real-world mistake this simulates.

4. Using `dq_results`, write one query that returns only the rules
   currently in FAIL state, sorted by `fail_pct` descending. This is the
   query a daily job would use to decide whether to alert someone. Then
   write a second version that also returns rules within 0.5 percentage
   points of their threshold, a simple early warning for a rule about to
   start failing.

## Key points

- Profile first: know the row count, blank rates, and date range before writing a single rule.
- Turn every deliberate defect into a real percentage. A number is actionable, a suspicion is not.
- A rule table is a list of conditions GOOD rows satisfy. Keep it copyable, not clever.
- Run all rules in one pass, with one aggregate expression per rule, not one scan per rule.
- Reconciliation catches missing and duplicated rows. It does not catch wrong rows. Use both.
