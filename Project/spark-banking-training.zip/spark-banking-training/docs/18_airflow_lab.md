# Module 18: Airflow scheduling lab

After this module you can install Airflow on your own WSL2 machine next
to the PySpark environment without the two breaking each other, trigger
the one DAG in `airflow/dags/` against this course's own pipeline, and
read a task log.

**Honesty note before you start.** Apache Airflow cannot be installed in
the sandbox that built this course, so nothing in this document, and
nothing in `airflow/dags/bank_pipeline.py`, was actually run against a
live Airflow install. The DAG file was compile-checked with
`python -m py_compile` (syntax only) and desk-checked, argument by
argument, against the Airflow 2.10 API. Follow this module on your own
WSL2 machine to see it run for real.

This module is hands-on, about 30 minutes: install, start, trigger,
read a log, break the gate on purpose.

## Why this matters in a bank

A working Airflow install that only exists in a slide is not a working
Airflow install. Every rollout of a new orchestration tool lives or dies
on exactly the friction this module walks through: which Python
environment, which port, what happens when a laptop reboots overnight.
Get this right and the takeaway is "I already have this running, on my
own machine, against real data", not "Airflow is fragile". Every piece
of friction here, which venv, which port, is friction a real rollout
hits on day one. Better to meet it here first, on a laptop, than in
front of an audit.

## 1. Why Airflow needs its own venv

This course's PySpark venv already has `pyspark==3.5.0` and everything
modules 01 to 17 needed. Apache Airflow ships a large, precisely pinned
dependency tree of its own: specific versions of Flask, SQLAlchemy,
Jinja2, and more. Installing Airflow into the SAME venv as PySpark means
`pip` has to satisfy both sets of pins at once, and it regularly cannot.
One of the two breaks, usually weeks later with a confusing error, not a
clean install-time failure.

**Never install Airflow into the PySpark venv.** Two separate venvs
sidestep the problem entirely. Airflow's venv only ever runs
`labs/17_lab_pipeline.py` as an external subprocess, through
`BashOperator`. It never imports `pyspark` itself.

| Venv | Has | Never has |
|---|---|---|
| PySpark venv (already built, modules 01 to 17) | `pyspark`, this course's own packages | Airflow or any of its dependencies |
| Airflow venv (this module) | `apache-airflow` | `pyspark` (it only shells out to the other venv's python) |

## 2. Target version

This module targets **Apache Airflow 2.10.5** on **Python 3.11 or
3.12**, with **LocalExecutor** and SQLite. If your organization is
already on Airflow 3.x, the DAG code here still runs, but expect renamed
things: `execution_date` becomes `logical_date` only, Datasets are
called Assets, and the webserver is called the API server. Match your
constraints URL to whichever version you install, do not mix a 2.10
command with a 3.x constraints file.

## 3. Install

Run this in WSL2 Ubuntu, not in Windows PowerShell.

```bash
cd ~
python3 -m venv airflow-venv
source airflow-venv/bin/activate
python -m pip install --upgrade pip

pip install "apache-airflow==2.10.5" \
  --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-2.10.5/constraints-3.11.txt"
```

The constraints file pins every one of Airflow's dependencies to
versions known to work together, for your exact Python minor version
(`3.11` in the URL, use `3.12` if that is your interpreter). Installing
without `--constraint` is how you end up with a webserver that will not
start because pip picked a newer library than 2.10.5 was tested against.
This lab needs no provider package: the DAG uses only `BashOperator`,
which ships with Airflow core.

Confirm:

```bash
airflow version
# 2.10.5
```

## 4. `AIRFLOW_HOME`, the database, and a user

`AIRFLOW_HOME` is where Airflow keeps `airflow.cfg`, its SQLite file,
and logs. Set it, and point `dags_folder` at this project's DAGs, before
the first command that touches it:

```bash
export AIRFLOW_HOME=~/airflow
export AIRFLOW__CORE__DAGS_FOLDER=/path/to/spark-banking-training/airflow/dags
export AIRFLOW__CORE__LOAD_EXAMPLES=false
```

Add these three lines to `.bashrc`, or a small script you `source` at
the start of every session, or `AIRFLOW_HOME` resets and Airflow
rebuilds a default config in a different place the next time you open a
terminal. This is the single most common reason a fresh terminal cannot
find a DAG that was working a minute ago in a different one.

Initialize the metadata database:

```bash
airflow db migrate
```

`airflow db migrate` is the 2.10 name. Older tutorials say `airflow db
init`, both exist in 2.10, use `migrate`.

Create a login:

```bash
airflow users create \
  --username admin --password admin \
  --firstname Bank --lastname Trainee \
  --role Admin --email admin@example.com
```

## 4.1 SQLite now, Postgres later

SQLite is a single file, needs no server, and is what `airflow db
migrate` uses by default. It is also single-writer: LocalExecutor's
whole point is running tasks in parallel, and with SQLite those parallel
writes serialize on file locks, which defeats part of the point. For one
learner on one laptop this is fine. The moment more than one person
needs to trigger DAGs against the same install, move to Postgres:

```bash
sudo apt install postgresql
sudo -u postgres createuser airflow -P
sudo -u postgres createdb airflow -O airflow
export AIRFLOW__DATABASE__SQL_ALCHEMY_CONN="postgresql+psycopg2://airflow:<password>@localhost/airflow"
airflow db migrate
```

LocalExecutor stays LocalExecutor either way, only the metadata database
changes.

## 5. Starting Airflow

```bash
airflow standalone
```

runs the scheduler, the webserver, the triggerer and (with
LocalExecutor) everything needed to actually run tasks, all as one
process, in one terminal. If you skip section 4's `users create`,
`standalone` creates an admin user for you automatically, and **prints
the generated password to the terminal**. Look for a line near the top
of the startup log that says
`Login with username: admin  password: <a long random string>`.

## 6. Reaching the UI from your Windows browser

WSL2 forwards `localhost` to Windows automatically for most setups.
Start `airflow standalone` inside WSL2, then open
[http://localhost:8080](http://localhost:8080) in your normal Windows
browser, Edge or Chrome, no extra configuration.

If that does not load, find WSL2's IP address from inside the WSL2
shell:

```bash
ip addr show eth0 | grep "inet "
```

and browse to `http://<that-ip>:8080` from Windows instead.

## 7. Editing the three constants

Open `airflow/dags/bank_pipeline.py` and edit the three constants at the
top, before you go anywhere near the UI:

| Constant | Set it to |
|---|---|
| `PROJECT` | the absolute path to `spark-banking-training` on your machine |
| `PYTHON` | the absolute path to the PySpark venv's python, `.venv/bin/python`, not the Airflow venv's |
| `RUN_DATE` | which of the three available dates to process when you just click play, no config |

That is the only project-specific setup this DAG needs. Nothing else in
the file is meant to be edited.

## 8. Triggering the DAG and reading a task log

In the UI: unpause `bank_pipeline`, then click the play button (Trigger
DAG) on its row.

To run a specific date without editing `RUN_DATE`, use the small dropdown
next to the play button, **Trigger DAG w/ config**, and paste:

```json
{"run_date": "2026-09-02"}
```

Only `2026-09-01`, `2026-09-02` and `2026-09-03` have data in this
course. Anything else fails at the `ingest` step.

Watch the Grid view until `ingest`, `curate` and `publish` all turn
green, in that order. Click any task's square, then **Logs**, to read
exactly what `labs/17_lab_pipeline.py` printed for that step, including
the row counts and the DQ gate's pass or fail line from module 17.

`airflow tasks test bank_pipeline ingest 2026-09-01` runs one task in
isolation, with no scheduler and no state written to the database, the
fastest inner loop while a DAG is still being developed.

A task log for `curate` looks like this, the same lines module 17's lab
prints, now captured by Airflow instead of your terminal:

```
[2026-09-02, 02:00:14] INFO - step=curate run_date=2026-09-01 dq_threshold=1.0
[2026-09-02, 02:00:19] INFO - rows=60000 negative_amount_rows=140 reject_pct=0.233%
[2026-09-02, 02:00:19] INFO - DQ GATE PASSED
[2026-09-02, 02:00:22] INFO - silver: wrote 60000 rows for dt=2026-09-01
```

Nothing Airflow-specific is in that output, it is the exact same script
module 17 already proved runs standalone. Airflow only captured it.

## 9. Forcing the DQ gate to fail, on purpose

`labs/17_lab_pipeline.py` defaults `--dq-threshold` to `1.0`, and the DAG
does not override it, so this lab's clean sample data always passes the
gate as shipped. To see the gate actually trip, edit `cmd()` in
`bank_pipeline.py` for one test run and append `--dq-threshold 0`, then
trigger the DAG again.

Expected: `curate` fails, `publish` shows SKIPPED, not FAILED, and the
DAG run overall shows FAILED. `publish` is skipped because its trigger
rule is the Airflow default, `all_success`: with `curate` failed, that
condition is never met, so `publish` never runs at all. This is the
exact behaviour module 17 section 8 describes, seen live in the Grid
view instead of only read about. Undo the edit afterward.

## 10. `bank_pipeline` has no schedule, on purpose

`schedule=None` means this DAG never runs on its own. There is no cron
string, no `catchup`, no `end_date`, because none of those apply to a
DAG that only ever runs when a person clicks the play button. If you
want to reprocess all three available dates, trigger the DAG three
times, once per date, using **Trigger DAG w/ config** each time. There
is no backfill command to run here: backfill only makes sense against a
schedule, and this DAG deliberately has none.

## 11. WSL2 troubleshooting

| Symptom | Real cause | Fix |
|---|---|---|
| `Address already in use` on port 8080 | a previous `airflow standalone` did not shut down cleanly | `lsof -i :8080`, kill that PID, or `airflow webserver --port 8081` |
| UI unreachable from Windows browser | WSL2 NAT is not forwarding, or the wrong IP was used | try `localhost:8080` first, then WSL2's `eth0` IP, section 6 |
| A new DAG file does not appear in the UI | `dags_folder` points elsewhere, or there is an import error | `airflow config get-value core dags_folder`, then `airflow dags list-import-errors` |
| `PermissionError` writing to `$AIRFLOW_HOME/logs` | `AIRFLOW_HOME` was created once as root by accident | `sudo chown -R $USER: $AIRFLOW_HOME`, or pick a path fully inside your home directory |
| Everyone in a shared training room sees Variables or runs changing under them | one `AIRFLOW_HOME` shared by accident | confirm each learner has their own `AIRFLOW_HOME`, ideally their own WSL2 instance |
| `airflow: command not found` in a new terminal | the Airflow venv was not activated in this shell | `source ~/airflow-venv/bin/activate` first, every new terminal |
| `bash: .../python: No such file or directory`, exit code 127 | the `PYTHON` constant points at a venv that does not exist at that path | check the path carefully. The venv may sit BESIDE the project folder rather than inside it |
| `ERROR: no raw file for 2026-09-12` | you asked for a date with no data, either as `RUN_DATE` or in the trigger config | only `2026-09-01`, `2026-09-02` and `2026-09-03` exist |
| A run shows success in 0 seconds, with no tasks | a DAG run and a task instance are different objects. A run can exist with zero tasks in it | click into the run and check the task squares themselves, not just the run's overall colour |
| `ModuleNotFoundError: No module named 'pyspark'` in a task log | the command ran with Airflow's own python, not the PySpark one | `PYTHON` in `bank_pipeline.py` must point at the PySpark venv, never the Airflow venv |

## 12. Everyday commands

| Task | Command |
|---|---|
| List DAGs | `airflow dags list` |
| Check a DAG parses cleanly | `airflow dags list-import-errors` |
| Test one task without scheduling it | `airflow tasks test bank_pipeline ingest 2026-09-01` |
| Stop everything | `Ctrl+C` in the `airflow standalone` terminal |

## The lab

| File | What |
|---|---|
| `airflow/dags/bank_pipeline.py` | The one DAG. Three `BashOperator` tasks, `ingest >> curate >> publish`, no schedule |
| `airflow/README.md` | The copy-paste quickstart version of this document |

The DAG orchestrates the exact same script module 17 already ran by
hand, `labs/17_lab_pipeline.py`, once per step. It contains no PySpark
code of its own, only three shell commands.

## Common mistakes

| Mistake | Real cause | Fix |
|---|---|---|
| Installed Airflow into the PySpark venv | "it's just one more pip install" | a separate venv, always, section 1 |
| `pip install apache-airflow` with no `--constraint` | pip resolving an incompatible dependency set on its own | always use the matching constraints URL, section 3 |
| `AIRFLOW_HOME` different in every new terminal | forgot to export it, or `.bashrc` was never updated | export it once in `.bashrc`, section 4 |
| DAG runs but reads or writes the wrong place | `PROJECT` in `bank_pipeline.py` still has the placeholder path | edit `PROJECT`, `PYTHON` and `RUN_DATE` at the top of the file, section 7 |
| `bash: .../python: No such file or directory`, exit code 127 | the `PYTHON` constant points at a venv that does not exist | check the path, the venv may be beside the project rather than inside it |
| `ERROR: no raw file for 2026-09-12` | asked for a date with no data | only 2026-09-01, 02 and 03 exist |
| A run shows success in 0 seconds with no tasks | a DAG run and a task instance are different objects, a run can contain zero tasks | check the task squares, not just the run |
| `ModuleNotFoundError: No module named 'pyspark'` in a task log | the command is using Airflow's python | `PYTHON` must point at the PySpark venv, not the Airflow one |

## Exercises

1. Complete sections 3 and 4: install Airflow 2.10.5 in its own venv, run
   `airflow db migrate`, create a user, and confirm `airflow version`
   prints `2.10.5`.

2. Edit `bank_pipeline.py`'s `PROJECT` and `PYTHON` for your machine,
   start `airflow standalone`, and open the UI from your Windows
   browser. Expected: the login screen loads at `http://localhost:8080`.

3. Unpause and trigger `bank_pipeline` with `RUN_DATE` left at its
   default. Watch the Grid view until all three tasks show success, then
   open `curate`'s log and find the `DQ GATE PASSED` line module 17
   prints.

4. Use **Trigger DAG w/ config** to run the DAG again for
   `{"run_date": "2026-09-03"}`. Confirm the log for `ingest` mentions
   `2026-09-03`, not whatever `RUN_DATE` is set to.

5. Follow section 9, force the gate to fail, and confirm `publish` shows
   SKIPPED, not FAILED, in the Grid view. Undo the edit afterward.

6. Try `{"run_date": "2026-09-12"}` on purpose. Read `ingest`'s log and
   confirm it fails with the exact "no raw file" message from the
   troubleshooting table above.

## Key points

- Airflow and PySpark live in two separate venvs, always. This is the
  single most common install mistake.
- `airflow standalone` is the right choice for one learner on one
  laptop. It prints a generated password if you skip creating a user by
  hand.
- Editing `PROJECT`, `PYTHON` and `RUN_DATE` at the top of
  `bank_pipeline.py` is the only project-specific setup the DAG needs.
- The DQ gate you read about in module 17 is visible live here: a failed
  `curate` skips `publish` through the default `all_success` trigger
  rule, it does not fail it.
- `schedule=None` means this DAG only ever runs when you trigger it, by
  the play button or the CLI, optionally with a `run_date` in the
  trigger config.
- Nothing in `airflow/dags/` was run against a live Airflow install in
  this sandbox, only compile-checked and desk-checked. Run it yourself
  to see it for real.
- SQLite is fine for one learner alone, move to Postgres the moment a
  second person shares the same install.
