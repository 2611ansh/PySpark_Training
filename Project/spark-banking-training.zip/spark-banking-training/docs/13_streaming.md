# Module 13: Structured Streaming

What you can do after this module: explain the unbounded table model,
choose a trigger, write a watermark that gives late data a real cutoff,
build a tumbling window aggregation, write a checkpointed `foreachBatch`
sink, and explain what "exactly-once" actually means in Structured
Streaming.

```bash
./run.sh labs/13_lab_streaming.py
```

The lab starts its own feeder (`labs/13b_feeder.py`) as a background
process, runs for about 50 seconds total, and stops everything cleanly on
its own. You do not need a second terminal or a real Kafka topic to run it.

## Why this matters in a bank

Fraud monitoring, real-time balance updates, and card authorisation alerts
cannot wait for tonight's batch job. A bank needs to react to a
transaction within seconds of it happening, not hours later. Structured
Streaming is Spark's answer: the same DataFrame API from every earlier
module, running continuously against data that keeps arriving, instead of
a fixed file read once. Nothing about `filter`, `join` or `groupBy`
changes, only a handful of streaming-specific ideas get added on top:
triggers, watermarks, and checkpoints.

## 1. A stream is an unbounded table

Structured Streaming's core idea: treat a streaming source as a table that
keeps growing new rows, and run ordinary DataFrame code against it. Spark
repeatedly reruns your query against the rows that arrived since the last
micro-batch and reconciles the result, instead of you writing separate
"batch" and "streaming" code.

```python
raw_stream = (spark.readStream
              .schema(txn_schema)                 # never inferSchema on a stream, see Lab 03
              .option("header", True)
              .option("maxFilesPerTrigger", 5)     # caps how much one micro-batch reads
              .csv(STREAM_IN))
```

`readStream` instead of `read`, `csv(STREAM_IN)` pointed at a folder
instead of one file: everything after that line is a normal DataFrame,
right up until you call `writeStream` instead of `write`.

## 2. Micro-batch triggers

| Trigger | What it does | When to use it |
|---|---|---|
| default, no trigger set | run a new micro-batch as soon as the last one finishes | simplest, Spark runs as fast as the source allows |
| `processingTime="N seconds"` | run a micro-batch every N seconds, even if the last one finished early | predictable cadence, this module's choice throughout |
| `availableNow=True` | process everything currently available, then stop | scheduled batch-like runs, e.g. every 15 minutes via a scheduler |
| `continuous="N seconds"` | experimental low-latency mode | narrow operator support, rarely used in a banking batch/micro-batch estate |

`Lab 13` uses `processingTime="5 seconds"` on every query: predictable, and
easy to read in the console output while the room watches it run.

## 3. Watermarks: a real cutoff for late data

Event time (`txn_ts`, when the transaction actually happened) and
processing time (when Spark saw the row) are not the same thing, a row can
arrive late. Without a rule, Spark would have to remember every key it has
ever seen, forever, in case a very late row still needs it. A watermark
gives it permission to forget:

```python
watermarked = raw_stream.withWatermark("txn_ts", "2 minutes")
```

Once the latest `txn_ts` seen so far reaches some time T, Spark assumes no
row with an event time older than `T - 2 minutes` will ever arrive. Any row
that does arrive later than that is silently **dropped**, not queued and
not an error. That is the real, sometimes uncomfortable, meaning of "the
watermark drops late data": pick the window wide enough for your real
data's lateness, not just wide enough to make the demo pass.

## 4. Tumbling windows

`Lab 13`, Step 3, counts transactions per channel in fixed, 20-second,
non-overlapping buckets:

```python
windowed = (watermarked
            .groupBy(F.window("txn_ts", "20 seconds"), "channel")
            .agg(F.count("*").alias("txn_count")))
```

| Window type | Shape | Example use |
|---|---|---|
| Tumbling | fixed, non-overlapping | this lab's channel activity count |
| Sliding | `F.window(col, "10 minutes", "2 minutes")`, overlapping | a rolling velocity check across several open lookbacks |
| Session | `F.session_window(col, "5 minutes")`, closes after a gap of inactivity | a customer's banking session, a burst of card attempts seconds apart |

A sliding window means one event can count toward several open windows at
once, useful for "has this account moved unusually fast money in any of
the last several lookbacks", at the cost of more state than a tumbling
window. A session window fits a banking session far better than a fixed
width: a 20-minute gap with no activity starts a new session, a burst of
attempts seconds apart stays in one.

```python
# sliding: a 10-minute window, sliding forward every 2 minutes, overlapping
F.window("txn_ts", "10 minutes", "2 minutes")

# session: closes after a 5-minute gap with no new event for that account
F.session_window("txn_ts", "5 minutes")
```

Both function calls slot into the same `groupBy(...).agg(...)` shape as
the tumbling window `Lab 13` runs, only the windowing function itself
changes, the rest of the query is untouched.

## 5. Backpressure: not letting one micro-batch swallow everything

`Lab 13`'s `readStream` sets `maxFilesPerTrigger=5`, a simple cap on how
many new files one micro-batch is allowed to pick up, even if 50 have
piled up since the last run.

| Source | Rate-limiting option | Caps |
|---|---|---|
| File source | `maxFilesPerTrigger` | files per micro-batch |
| Kafka source | `maxOffsetsPerTrigger` | total records per micro-batch, across all partitions |

Without a cap, a job that has fallen behind (a restart after downtime, a
burst of activity) tries to process everything that piled up in one huge
micro-batch, which can spike memory and make that one batch run far longer
than the trigger interval expects. A cap trades a slower catch-up for a
steady, predictable batch size throughout.

## 6. Stream-static join

A stream can join a normal, finite DataFrame exactly like a batch join.
`accounts.csv` is small, so broadcast it, the same rule Module 02 teaches
for any small dimension table:

```python
enriched = raw_stream.join(F.broadcast(accounts), "account_id", "left")
```

Every micro-batch of new transactions joins against the CURRENT accounts
snapshot at the moment that micro-batch runs. If `accounts.csv` changed
between runs, a later micro-batch sees the new version, Spark does not
version the static side for you.

## 7. `foreachBatch`: the general-purpose sink

`Lab 13`, Step 4, writes large-amount alerts to Parquet:

```python
def write_alerts(batch_df, batch_id):
    large = batch_df.filter(F.col("amount") > LARGE_AMOUNT)
    if large.count() > 0:
        large.write.mode("append").parquet(ALERTS_PATH)

alert_query = (watermarked.writeStream
               .foreachBatch(write_alerts)
               .option("checkpointLocation", f"{STREAM_CKPT}/alerts")
               .trigger(processingTime="5 seconds")
               .start())
```

`foreachBatch` hands each micro-batch to your function as a plain, static
DataFrame, so any batch-side write is legal inside it, a Parquet append
here, a JDBC upsert or two different sinks at once in a real job. This is
the general-purpose way most production streaming sinks actually get
built, not just the narrower built-in console/memory/kafka sinks alone.

## 8. Output modes

| Output mode | Meaning | Allowed on |
|---|---|---|
| `append` | only new rows since the last batch, ever | non-aggregated queries, or an aggregation with a watermark, once a window closes |
| `update` | rows that changed since the last batch, re-emitted with new values | aggregations, this module's window query |
| `complete` | the whole result table, re-emitted every batch | small aggregations only, must fit the sink every time |

## 9. Checkpoints and exactly-once

The checkpoint directory (`data/stream_ckpt/` here) is the single most
important thing to get right in a streaming job. It holds the exact input
offsets already processed, so a restart never reprocesses or skips a file,
and the state store, window aggregates and any dedup keys in flight.

Change the query logic in a way that changes the SHAPE of that state (a
new `groupBy` key, a different aggregation, a different watermark column)
and the checkpoint becomes unreadable. The safe move is a new checkpoint
directory, accepting that state starts over, never editing the old one in
place. Safe to change without a new checkpoint: the trigger interval,
`maxFilesPerTrigger`, filter conditions that do not change the state
shape, and the sink itself.

Exactly-once comes from two things working together:

| Piece | What it guarantees |
|---|---|
| The checkpoint | a restart reprocesses exactly the same batch it was on, never a different one |
| An idempotent sink | re-writing the same batch twice produces the same end state, not duplicates |

`Lab 13`'s Parquet append sink is naturally idempotent for this pattern
because a real pipeline would already have deduplicated by `txn_id`
upstream, Lab 04's silver-layer habit. A sink that is NOT naturally
idempotent, a JDBC counter increment for example, needs its own
idempotency key (write the `batch_id` alongside the data, upsert instead
of blindly inserting) to get the same guarantee. "Checkpoint plus an
idempotent sink" is the whole practical answer, there is no further magic.

## 10. Kafka, briefly

`Lab 13` uses the file source because it needs no server. A production
fraud pipeline reads from Kafka instead, the source most banking event
streams actually use:

```python
kafka_stream = (spark.readStream
                 .format("kafka")
                 .option("kafka.bootstrap.servers", "broker1:9092,broker2:9092")
                 .option("subscribe", "txn-events")
                 .option("startingOffsets", "latest")
                 .load())
```

Not runnable here, no broker exists in this sandbox. The shape of the rest
of the job barely changes: `kafka_stream` is still a DataFrame with a
`value` column (raw bytes, usually JSON or Avro, needing a `from_json` or
schema-registry decode step), and every watermark, window, join and
`foreachBatch` idea in this module applies to it unchanged. What changes
with Kafka is the checkpoint content: it now tracks topic-partition
offsets instead of file names, same purpose, a different unit.

## 11. Debugging a stream that looks stuck

| Symptom | Likely cause | Where to look |
|---|---|---|
| No new batches appear | the source has nothing new, or a `maxFilesPerTrigger` cap is genuinely just slow | `query.lastProgress`, check `numInputRows` |
| `query.status` keeps showing "Getting offsets from FileStreamSource" | the source folder itself is empty, or the feeder stopped | check the feeder's own output, confirm files are landing |
| The job never stops when told to | code path stopped only one query, not all of them | keep a list of every query started, stop every one, `Lab 13`'s Step 5 does this on purpose |
| State keeps growing, eventually spills or slows | no watermark, or a watermark too wide for the real lateness of the data | add or tighten `withWatermark`, Section 3 |

`query.lastProgress` and `query.status`, both used in `Lab 13`'s Step 5,
are the two calls to reach for first, before opening the Spark UI's own
Structured Streaming tab for the same information in graph form.

## 12. Failure and restart

Kill a Structured Streaming job (a pod eviction, a laptop that sleeps
mid-demo) and restart it pointed at the SAME checkpoint directory: it
resumes from the last committed offset, not from the beginning and not
from wherever the process happened to die. Any file the checkpoint had not
yet recorded as processed gets picked up again, so at-least-once input
handling is automatic. Combined with an idempotent sink (Section 9), the
end-to-end result is exactly-once in practice.

To deliberately reprocess history (a rule changed, alerts need
regenerating), the checkpoint is exactly what stands in the way: point the
job at a new, empty checkpoint directory. There is no "rewind" command
inside one checkpoint, a fresh checkpoint IS the rewind.

## The lab

`labs/13b_feeder.py` is a small, pure-Python helper, no Spark. It drips
rows from `data/raw/stream_pool.csv` into `data/stream_in/` as small CSV
files, one at a time, writing each to a hidden temp name first and
renaming it into place so the stream never reads a half-written file.
`labs/13_lab_streaming.py` starts it automatically.

`labs/13_lab_streaming.py`:

| Step | Shows |
|---|---|
| 1 | Start the feeder, open the stream with an explicit schema |
| 2 | A watermark on `txn_ts` |
| 3 | A tumbling window: transaction count per channel, per 20 seconds |
| 4 | `foreachBatch`, writing large-amount alerts to checkpointed Parquet |
| 5 | Run bounded for about 50 seconds, print real progress, stop everything |
| 6 | Output modes and exactly-once, summarised in one table |

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| `inferSchema` on a `readStream` | copying a batch-read habit onto a stream | always pass an explicit schema, the first micro-batch may not show every column's real range |
| No watermark on a windowed aggregation | not realising state grows forever without one | add `withWatermark` before any `groupBy` on event time |
| Forgetting to stop a query | assuming the script exiting stops it | always call `query.stop()` for every query you started, `Lab 13`'s Step 5 does this for both |
| Editing query logic without a new checkpoint | not knowing state shape is tied to the checkpoint | change the checkpoint path whenever a `groupBy` key, aggregation or watermark column changes |
| Assuming a JDBC sink is automatically idempotent | copying the Parquet-append pattern without checking | give a non-idempotent sink its own upsert key, see Section 9 |

## Exercises

1. In `Lab 13`, change the tumbling window from 20 seconds to 10 seconds
   and re-run. Does `channel_activity`'s row count change, and why?

2. Change `LARGE_AMOUNT` to a lower value and re-run. Confirm more alerts
   land in `data/warehouse/streaming/large_amount_alerts/`.

3. Without running it, read Step 4's `write_alerts` function and identify
   what would need to change to make a non-idempotent sink (say, a running
   total kept in a dictionary) safe to re-run after a crash.

4. Read Section 4's window type table and decide which window type fits
   "alert if a customer's card is used in two different cities within 10
   minutes": tumbling, sliding, or session. Justify your choice.

## Key points

- A stream is an unbounded table, the same DataFrame code from every
  earlier module runs against it, only `readStream`/`writeStream` and a
  few streaming-only options are new.
- A watermark is what lets Spark forget old state safely, and it is also
  the reason genuinely late data gets silently dropped, choose the window
  deliberately.
- `foreachBatch` is the general-purpose sink, any batch-side write is
  legal inside it.
- Exactly-once is "checkpoint plus an idempotent sink", nothing more
  exotic than that.
- Always stop every query you started, and always run a streaming demo
  with a wall-clock deadline, never wait forever.
