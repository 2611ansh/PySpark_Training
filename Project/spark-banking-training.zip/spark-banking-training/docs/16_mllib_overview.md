# Module 16: MLlib overview

After this module you can name what `spark.ml` covers, read a Pipeline,
and know when Spark ML is the wrong tool for the job.

This is a short survey, about 25 minutes. It is not a machine learning
course. Data science teams own model quality. IT and platform teams, this
room, own getting data to them at scale and getting predictions back into
production without breaking anything.

## Why this matters in a bank

Every bank IT team eventually gets asked to "run the fraud model" or
"score the churn list" inside a pipeline that already reads transactions
and accounts. You do not need to be a data scientist to do that job well.
You need to know what a Pipeline is, what fitting a model actually does to
a cluster, and honestly, when the answer to "can we just do this in
Spark" is no. Getting that "no" right early saves a team from spending
weeks forcing a dataset that fits in memory through a framework built for
one a thousand times its size.

## 1. `pyspark.ml` vs `pyspark.mllib`

Two ML APIs ship inside PySpark. Only one is current.

| | `pyspark.ml` | `pyspark.mllib` |
|---|---|---|
| Data structure | DataFrame | RDD |
| Status | current, actively developed | maintenance mode since Spark 2.0 |
| Use in a new project | always | never |

If a blog post or an old answer imports `pyspark.mllib`, check the date
before copying it.

`pyspark.ml` is a DataFrame API on purpose: it composes directly with the
joins, filters and window functions from modules 03 to 10. Building a
feature table is ordinary Spark SQL work, and the model stages plug
straight onto the end of it, no conversion to an RDD and back needed
anywhere in the pipeline.

## 2. What is available, by family

| Family | For | Key classes |
|---|---|---|
| Classification | predict a category (fraud, default, churn) | `LogisticRegression`, `RandomForestClassifier`, `GBTClassifier` |
| Regression | predict a number (expected loss, a forecast balance) | `LinearRegression`, `GBTRegressor` |
| Clustering | group similar rows with no label | `KMeans`, `BisectingKMeans` |
| Recommendation | rank items for a user | `ALS` |
| Feature transformers | turn raw columns into model-ready features | `StringIndexer`, `VectorAssembler`, `StandardScaler` |
| Evaluation | score a fitted model | `BinaryClassificationEvaluator`, `MulticlassClassificationEvaluator` |
| Tuning | search hyperparameters | `ParamGridBuilder`, `CrossValidator` |
| Frequent pattern mining | find items that co-occur often | `FPGrowth` |

This is a survey, not a manual. Recognise the family name when someone
mentions it, that is the goal.

## 3. The Pipeline concept, in one page

| Concept | What it is | Method |
|---|---|---|
| Transformer | DataFrame in, DataFrame out, no learning | `.transform(df)` |
| Estimator | DataFrame in, learns something, produces a Transformer | `.fit(df)` |
| Pipeline | an ordered list of stages | `.fit(df)` produces a `PipelineModel` |
| PipelineModel | the fitted Pipeline, itself a Transformer | `.transform(df)` |

The naming trap that catches almost everyone: `StringIndexer` is an
**Estimator**, it has to see the data once to learn the string-to-number
mapping. `LogisticRegression` is also an Estimator. Calling `.fit()` on a
whole `Pipeline` runs every Estimator stage in order and wraps the result
as one `PipelineModel`.

```python
indexer = StringIndexer(inputCol="channel", outputCol="channel_idx")
assembler = VectorAssembler(inputCols=["channel_idx", "amount"], outputCol="features")
lr = LogisticRegression(featuresCol="features", labelCol="label")

pipeline = Pipeline(stages=[indexer, assembler, lr])
model = pipeline.fit(train_df)     # runs every stage's fit/transform in order
scored = model.transform(test_df)  # runs every stage's transform only
```

Custom stages exist too: implement `_transform(dataset)` for your own
Transformer, or `_fit(dataset)` for your own Estimator, and it slots into
a Pipeline like a built-in one. Reach for this only when the exact same
logic needs to be reused, unchanged, across many pipelines, a plain
`.withColumn()` call does the same job for a one-off case with none of the
extra machinery.

## 4. Banking use cases mapped to the right family

| Use case | Family | Notes |
|---|---|---|
| Fraud detection | Classification | severe class imbalance, section 6 |
| Credit scoring | Classification | regulators want reason codes, not just a score |
| Customer churn | Classification | usually less imbalanced than fraud |
| Customer segmentation | Clustering | unsupervised, needs a human to name the clusters |
| Next best offer | Recommendation (`ALS`) or classification | needs an interaction matrix |
| Collections prioritisation | Regression or classification | often blended with existing DPD rules |
| AML anomaly detection | Clustering, or classification against confirmed reports | rule engines still catch most volume, ML augments them |

## 5. When NOT to use Spark ML

| Situation | Better choice |
|---|---|
| Data fits on one machine, a few GB or less | scikit-learn, XGBoost, on one strong machine |
| Deep learning (images, text, LLM fine-tuning) | PyTorch or TensorFlow, GPU machines |
| Heavy hyperparameter search across many algorithms | scikit-learn plus a dedicated tuning library |
| The team needs SHAP or LIME explainability tooling | the scikit-learn/XGBoost ecosystem, built for that |

The rule worth remembering: Spark ML earns its keep when the feature
engineering, not the model fit, is the big job. A five-year transaction
history join for 8 million customers is a Spark job. Fitting a logistic
regression on the resulting rows is often not big enough to need Spark at
all.

## 6. What people actually do with Spark ML in 2026

| Step | Tool | Why |
|---|---|---|
| Feature engineering at scale | Spark | the genuinely hard, genuinely distributed part |
| Feature storage | Parquet or Delta, or a feature store product | one definition of a feature, reused by training and scoring |
| Model training | scikit-learn, XGBoost, or Spark ML for a simple case | model fitting is rarely the bottleneck once features exist as columns |
| Experiment tracking | [MLflow](https://mlflow.org/) or similar | records which data and code version produced which model |
| Batch scoring at scale | Spark again, the model wrapped as a pandas UDF | scoring millions of rows with an already-trained model is an engineering problem again |

A **feature store** (Feast, a Databricks Feature Store, and similar) solves
one specific, expensive bug: a feature computed one way in training and a
slightly different way in real-time scoring, called training/serving skew.
Worth knowing the term even if this course does not set one up.

## 7. Evaluation metrics, which one for which problem

| Metric | Use it for | Do not use it for |
|---|---|---|
| Accuracy | roughly balanced classes | a rare-event label like fraud, section 8 |
| Area under ROC | a general sense of ranking quality | the headline number on a severely imbalanced label, it still looks better than it is |
| Area under PR (precision-recall) | any rare-event classification: fraud, AML, NPA | balanced classes, where it adds little over ROC |
| RMSE / MAE | regression, predicting a number | classification of any kind |

`BinaryClassificationEvaluator(metricName="areaUnderPR")` is the one line
that matters most from this whole table for a banking fraud or AML model.

## 8. The one runnable example: a fraud classifier

`labs/16_lab_mllib.py` builds a `StringIndexer -> VectorAssembler ->
LogisticRegression` Pipeline on `transactions` joined to `fraud_labels`,
features: `channel`, `merchant_category`, `txn_type`, `amount`,
`hour_of_day`.

Verified run against this course's data:

```
total transactions: 180,720
labelled fraud    : 516 (0.286%)
```

That confirms the brief: fraud is roughly 0.3% of rows, a 1-in-350
problem. Metrics on the held-out test set:

```
accuracy (looks great, means almost nothing here) : 0.9970
area under ROC (also flattered by the imbalance)  : 0.4906
area under PR  (the honest number for this data)  : 0.0030
test set base rate (PR-AUC of a useless model)    : 0.0030
```

Two honest lessons, straight out of this real run:

1. **Accuracy is close to a lie on a 0.3% label.** A model that predicts
   "not fraud" for every row scores 99.7% accuracy without learning
   anything. Report PR-AUC, never accuracy, on a rare-event banking
   problem: fraud, AML alerts, NPA prediction.

2. **PR-AUC sits right on the base rate.** This model is barely better
   than randomly shuffling the queue. That is not a bug, it is what a
   small, untuned model with weak features and only 516 confirmed cases
   actually looks like. The fix is never "trust the metric less", it is
   richer features and more labels.

This lab does no tuning and no cross-validation on purpose, a 25 minute
survey module is not the place for it. `CrossValidator` and
`ParamGridBuilder` exist and are worth knowing by name, section 2's table
is where they live.

## 9. Saving and reusing a fitted model

A `PipelineModel` is not something you retrain every time you need a
prediction. Save it once, load it wherever scoring happens next.

```python
model.write().overwrite().save("data/warehouse/models/fraud_v1")

from pyspark.ml import PipelineModel
loaded = PipelineModel.load("data/warehouse/models/fraud_v1")
scored = loaded.transform(new_transactions)
```

| Where scoring happens | Pattern |
|---|---|
| A batch job, millions of rows, already in Spark | load the `PipelineModel`, call `.transform()` directly, exactly like the lab does |
| A real-time API, one request at a time | the model is usually exported to a lighter single-machine format (ONNX, or the underlying library's own format) and served outside Spark entirely, starting a JVM per request is far too slow |
| A scheduled batch scoring job feeding a dashboard | Spark reads the day's transactions, loads the saved model, writes a scored gold table, the same shape as every other gold table in this course |

The version saved to disk, the code version that trained it, and the data
it was trained on are the three things worth recording together (section
6's MLflow row). Without that, "which model is actually running in
production right now" has no reliable answer, the same problem module 15
solves for a packaged job in general.

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| Copying `pyspark.mllib` code from an old tutorial | did not check the source's age | use `pyspark.ml`, the RDD-based API gets no new features |
| Reporting accuracy on a fraud or AML model | accuracy looks great on any rare label | use `areaUnderPR`, and know the base rate to compare against |
| Calling `.fit()` on a `StringIndexer` and expecting data back | confusing Estimator and Transformer | `.fit()` returns a Transformer, call `.transform()` on that |
| Training on the full customer base on a laptop "because Spark can handle it" | assuming distributed always wins | if it fits in memory, a single-machine library is usually faster |
| Treating a low PR-AUC as a code bug | not checking the base rate first | compare PR-AUC to the base rate, if they are close, it is features, not code |
| Building a huge `ParamGridBuilder` grid without checking the fit count | not realising `CrossValidator` multiplies model fits by folds times grid size | print `numFolds x grid size` before calling `.fit()` |
| Letting a fitted `PipelineModel` go untracked | "it worked on my laptop" is not an audit trail | log the data version, code version and metrics together, section 6's MLflow row |

## Exercises

1. Run `labs/16_lab_mllib.py` and confirm the fraud rate it prints
   (roughly 0.29%) matches this module's 0.3% figure.

2. Add `city` as an extra `VectorAssembler` input (index it first, the
   same way `channel_clean` is indexed), re-run, and note whether PR-AUC
   moves. It should not move much: with only 516 confirmed cases spread
   across a handful of features, one more weak feature rarely changes
   much, explain why in one sentence of your own.

3. Change `LogisticRegression(maxIter=20)` to `maxIter=5`. Confirm the lab
   still finishes without an error.

4. Without running it, write out what would need to change to add a
   `RandomForestClassifier` instead of `LogisticRegression` in the same
   Pipeline. Answer: only the last stage, `channel_idx`, `category_idx`,
   `type_idx` and `assembler` stay exactly as they are.

## Key points

- `pyspark.ml`, never `pyspark.mllib`, for anything new.
- A Pipeline is four ideas: Transformer, Estimator, Pipeline, PipelineModel.
- Spark ML earns its keep on feature engineering at scale, not always on
  the model fit itself.
- On a rare-event label, report PR-AUC and the base rate, never accuracy
  alone.
- A `PipelineModel` saves and loads like any other Spark artifact, so
  batch scoring is the same read, transform, write shape as every other
  job in this course.
