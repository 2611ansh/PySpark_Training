# Module 02: Spark architecture

After this module you can explain, with real numbers from your own machine, why a Spark job is split into jobs, stages and tasks, and when that split costs you time.

This is the longest module on Day 1, and deliberately so: everything downstream leans on it.

## Why this matters in a bank

A batch job that reconciles a day's transactions, or a nightly job that rebuilds a risk report, either finishes in minutes or it does not finish before the business needs the numbers. Every performance conversation you will have on this course, and every performance problem you will debug at work, comes back to the ideas in this module: partitions, stages, shuffles and caching. Get this module solid and Module 14, Performance tuning, will feel like common sense instead of guesswork.

This module also asks you to keep the Spark UI open while the lab runs. Reading the UI is not optional background reading, it is the skill. A trainer who can only read `explain()` output is only half equipped. A trainer who can also read the UI can walk into a slow production job and say exactly which stage is the problem.

Nothing in this module is specific to `local[*]`. The same partitions, the same stages, the same shuffle cost apply whether the job runs on your laptop or on a 40-node cluster processing the full core banking feed overnight. The only thing a bigger cluster changes is how much parallel work is available, not the shape of the ideas.

A common real scenario: a nightly reconciliation job that joined the day's transactions to accounts and branches used to run in a few minutes. After a schema change upstream, it started taking over an hour, with no error, no crash, just slow. The cause, almost always in a case like this, is a join that used to be small enough to broadcast and now is not, so Spark silently falls back to a full shuffle join on both sides. Nobody wrote bad code. The data changed shape, and the plan changed with it. Module 02's skills, reading `explain()`, reading the Stages tab, are exactly what finds that cause in minutes instead of hours of guessing.

## 1. The driver and the executors

Every Spark application has one **driver**, the process that runs your Python script, builds the plan, and hands out work. The actual work, reading files, filtering rows, running aggregations, happens on **executors**.

| Environment | Driver | Executors |
|---|---|---|
| This course, `local[*]` | this Python process | threads inside the SAME process, one per core |
| A real cluster | a dedicated process, often on its own node | separate processes, often on separate machines |
| A **cluster manager** (YARN, Kubernetes, Spark's own standalone mode) | asks for executors, hands them to the driver | not involved in this course, `local[*]` needs none of it |

`local[*]` is a real Spark deployment, not a toy simulation. Every concept in this module, partitions, stages, shuffles, works exactly the same way on a cluster. What changes on a cluster is only the distance between the driver and the executors, and the network cost that distance adds.

| What stays exactly the same | What actually changes on a real cluster |
|---|---|
| Partitions, jobs, stages, tasks | how many executors you have, and how many cores each one gets |
| Laziness, `explain()`, the DAG | a shuffle now moves data over the network, not just between threads |
| `.cache()`, AQE, broadcast joins | a lost executor can be replaced by the cluster manager mid-job |
| Reading the Spark UI | the UI runs on the cluster's driver node, usually reached through a gateway URL, not `localhost` |

A **cluster manager** is the layer that decides which physical machines your executors actually run on. YARN and Kubernetes are the two you are most likely to meet at a bank running Spark on-premises or in a private cloud. Spark itself does not need to know which one is underneath, it asks for executors through a common interface, and the cluster manager finds the capacity. This course never touches a cluster manager directly, `local[*]` needs none of it, but the driver and executor roles you see here are unchanged underneath one.

```python
sc = spark.sparkContext
sc.applicationId      # a unique id for this run, also shown in the UI
sc.defaultParallelism  # cores available to executors, here: cores on your laptop
sc.uiWebUrl            # where the Spark UI is actually listening
```

The driver does more than schedule work. It holds the Catalyst plan, decides how to split each job into stages, collects the final result of an action, and is the process that would crash your whole application if it ran out of memory. This is why `.collect()` on a huge DataFrame is dangerous: it pulls every row back to the driver's memory, not to a worker's.

Work is scheduled in small units. Each partition of each stage becomes one **task**, and tasks are handed out to whichever core is free next. On a laptop with `sc.defaultParallelism` equal to 2, at most 2 tasks run at the same time, no matter how many partitions the stage has. The rest queue and wait their turn.

### Session configuration lives in one place

Every lab in this course starts with the same line: `spark = get_spark("lab-NN")`. All the settings that shape the driver and executors, the ones this module is about, live in `src/bank_session.py`, not repeated in every lab file.

```python
def get_spark(app_name="bank-lab", shuffle_partitions=8, aqe=True, delta=False, iceberg=False, extra=None):
    ...
```

| Setting | Default in this course | What it controls |
|---|---|---|
| `master("local[*]")` | all cores on the machine | how many executor threads exist |
| `spark.sql.shuffle.partitions` | 8 | post-shuffle partition count before AQE adjusts it |
| `spark.sql.adaptive.enabled` | `true` | whether AQE is on, see section 6 |
| `spark.sql.session.timeZone` | `Asia/Kolkata` | how timestamp columns are interpreted and displayed |
| `spark.sql.warehouse.dir` | `data/warehouse` | where managed tables and this course's Parquet output land |
| `extra` (a dict) | empty by default | a one-off setting a single demo needs, without touching every other lab's defaults |

In a real team, this is exactly the pattern to follow: one place that builds the session, so a config change is one line, not a search-and-replace across eighteen scripts. `get_spark()` also accepts an `extra` dict for a one-off setting a single demo needs, without touching the shared defaults every other lab relies on.

## 2. Partitions: the unit of parallel work

A DataFrame is not one big table sitting in memory. It is split into **partitions**, and Spark schedules one task per partition. More partitions means more parallel work, up to the number of cores you have.

For a plain file read, the partition count follows the input files, not any setting.

```python
df = spark.read.option("header", True).schema(schema).csv("data/raw/transactions/*.csv")
df.rdd.getNumPartitions()   # 3, one per daily CSV file
```

A single small file reads as one partition.

```python
accounts = spark.read.option("header", True).schema(acc_schema).csv("data/raw/accounts.csv")
accounts.rdd.getNumPartitions()   # 1
```

Too few partitions and you leave cores idle. Too many and the scheduling overhead per task starts to dominate the actual work. Module 14 covers tuning this deliberately. For now, the point is simpler: partition count is a real, inspectable number, not a black box.

You can also set partition count directly, two ways, and they are not the same operation.

| Method | What it does | Cost |
|---|---|---|
| `repartition(n)` | shuffles the data into exactly `n` new, evenly sized partitions | a full shuffle, can increase or decrease partition count |
| `coalesce(n)` | merges existing partitions together, without a full shuffle | cheaper, but can only decrease partition count, and can leave partitions uneven |

Use `coalesce()` when you only need FEWER partitions, for example right before writing output files, so you do not end up with hundreds of tiny files. Use `repartition()` when you need an even spread, for example before a wide operation on skewed data.

## 3. Jobs, stages and tasks

Spark plans your code as a **DAG**, a directed acyclic graph, a fancy name for "a flowchart with no loops back to an earlier step". When you call an action, Spark turns the relevant part of that DAG into work:

| Term | What it is | Roughly maps to |
|---|---|---|
| **Job** | everything needed to satisfy one action | one `.count()`, `.collect()`, `.write()` call |
| **Stage** | a chunk of the job that can run without a shuffle | the work between two shuffle boundaries |
| **Task** | one stage, run on one partition | one thread, one partition, one unit of scheduled work |

A job with no shuffle in it has exactly one stage. A job with one shuffle, for example a `groupBy`, has two stages: the work before the shuffle, and the work after it. Chain three shuffles together and you get four stages. Stage count is a direct, honest measure of how much shuffling a query does.

**Tracing one query.** Take `df.filter("status = 'SUCCESS'").groupBy("channel").count()` and follow it end to end.

1. You call `.count()`. Spark sees one action, so it plans one job.
2. Catalyst looks at the plan and finds one shuffle boundary, the `groupBy`. That means two stages.
3. Stage 1 reads the CSV files, applies the filter, and does a partial count per channel, per partition. This is narrow work, no data crosses partition boundaries.
4. The shuffle happens between stages: each partition's partial counts are written out, grouped by channel, and re-read into new partitions.
5. Stage 2 reads the shuffled data and adds the partial counts together into the final result per channel.
6. The driver collects that small final result and returns it to your Python code as the return value of `.count()`... except `.count()` returns a single number, so in this specific case the final aggregation also happens driver-side, on the small per-channel counts.

Every wide operation you write adds this same two-part shape, work, then a shuffle boundary, then more work. A query with a `filter`, a `join`, and a `groupBy` where the join is NOT broadcast has two shuffle boundaries and three stages.

Task count follows partition count, stage by stage. Reading 3 daily transaction files gives stage 1 exactly 3 tasks, one per partition, one per file. After the shuffle, stage 2 gets as many tasks as the shuffle partition count, 8 by default in this course, or fewer once AQE coalesces them. On a 2-core laptop, 3 tasks in stage 1 means one core runs 2 tasks in sequence while the other runs 1, since only 2 can run at once.

### Why the DAG also matters for fault tolerance

The DAG is not only a scheduling tool. Because Spark remembers HOW each partition was derived, not just its data, it can recompute a lost partition if a task fails, instead of failing the whole job. On a real cluster, a single executor can crash mid-job, and Spark simply reruns the tasks that were running on it, using the same DAG. You do not see this in `local[*]`, since there is no separate executor to lose, but it is the same mechanism that makes Spark practical on hundreds of machines where some hardware failure is a certainty, not an edge case.

## 4. Transformations are lazy, actions trigger execution

Calling `.filter(...)` or `.select(...)` does not touch any data. It only adds a step to the plan. Nothing runs until you call an **action**: `.count()`, `.collect()`, `.show()`, `.write(...)`.

```python
plan = df.filter("status = 'SUCCESS'").select("txn_id", "amount", "channel")   # instant, no data read
row_count = plan.count()                                                       # THIS reads the files
```

You can chain as many transformations as you like before the first action. None of them cost anything until the action runs. This is why building a plan in the lab takes a fraction of a second, while the `.count()` right after it takes several seconds, even though the plan looks like "more code".

Laziness is not a performance trick you opt into. It is how every DataFrame operation works, always. Knowing this stops a common confusion: a `print()` placed between two transformations tells you nothing about how long each one takes, because neither one actually ran yet.

```python
t0 = time.time()
step_a = df.filter("amount > 0")
step_b = step_a.withColumn("amount_sq", F.col("amount") * F.col("amount"))
print(time.time() - t0)   # near zero, no matter how many steps you chain here
```

An action only evaluates the plan UP TO that action, not beyond it. If you build `step_a`, then `step_b` on top of it, then call `.count()` on `step_a` alone, Spark never looks at `step_b` at all. This is easy to forget when reading a long chain of transformations top to bottom, since the code layout suggests an order that only matters once an action actually runs.

## 5. Narrow vs wide transformations, and the shuffle

| Kind | Needs data from | Example | Cost |
|---|---|---|---|
| Narrow | only its own partition | `filter()`, `select()`, `withColumn()` | cheap, no data movement |
| Wide | every partition, grouped by a key | `groupBy()`, `join()` (unless broadcast), `distinct()` | a shuffle: write, then re-read, repartitioned by key |

A **shuffle** is Spark writing every partition's data out, split by the group key, then having each new partition read back only the slice with its key. It is the single most expensive thing an everyday Spark query does, because it moves data across the network (or, in `local[*]`, across disk and process boundaries) instead of just scanning it once.

`explain()` shows you the shuffle directly. Look for the word `Exchange`.

```python
df.filter("status = 'SUCCESS'").explain()
# no Exchange: this plan is entirely narrow

df.groupBy("channel").count().explain()
# +- Exchange hashpartitioning(channel, 8), ...
# an Exchange: this plan shuffles
```

The number after the column name in `hashpartitioning(channel, 8)` is the shuffle partition count, controlled by `spark.sql.shuffle.partitions`. This course sets it to 8, a sensible number for a laptop. Spark's own default is 200, tuned for a cluster, and far too many for a single machine.

A few more operations worth knowing where they fall:

| Operation | Narrow or wide | Note |
|---|---|---|
| `filter()`, `select()`, `withColumn()` | narrow | never shuffles |
| `union()` | narrow | stacks partitions, does not shuffle |
| `groupBy().agg(...)` | wide | shuffles by the group key |
| `join()`, regular | wide | shuffles both sides by the join key |
| `join()`, with `F.broadcast()` | narrow, on the big side | the small side is copied everywhere instead, covered in Module 03 |
| `distinct()`, `dropDuplicates()` | wide | needs every partition compared against every other |
| `repartition(n)` | wide | a shuffle, by design |
| `coalesce(n)` | narrow | merges partitions without moving data between them |
| `orderBy()`, `sort()` | wide | a global sort needs every row compared against the sort key range of every other partition |
| `window()` functions | usually wide | most window specs need rows grouped by their partition key first, covered in Module 10 |

`explain()` on a join shows which strategy Spark picked: `BroadcastHashJoin` (narrow, cheap, only possible for a small side) or `SortMergeJoin` (wide, a full shuffle of both sides). Module 03's broadcast join step shows exactly this choice on real data.

A typical run of the lab shows the gap in real seconds, not just theory:

```text
narrow filter+count took: 0.45 s
wide groupBy+collect took: 0.77 s   (the shuffle adds real cost)
```

That is on 180,720 rows, on a laptop, with the shuffle already tuned to 8 partitions. The gap widens fast as data size grows, and widens again if `shuffle.partitions` is left at Spark's default of 200 on a small machine.

## 6. Adaptive Query Execution (AQE)

AQE watches the ACTUAL size of data at each shuffle boundary, while the query is running, and adjusts the plan. The most visible thing it does for this course: it **coalesces** small shuffle partitions into fewer, bigger ones, so you do not pay scheduling overhead for a partition holding almost no rows.

```python
wide = df.groupBy("channel").count()
wide.collect()
wide.rdd.getNumPartitions()   # 1, even though shuffle.partitions=8

spark.conf.set("spark.sql.adaptive.enabled", "false")
wide_no_aqe = df.groupBy("channel").count()
wide_no_aqe.collect()
wide_no_aqe.rdd.getNumPartitions()   # 8, the configured number, unadjusted
```

There are only 8 distinct channels in this dataset, so 8 shuffle partitions for the final aggregate is wasteful. AQE notices the result is tiny and merges it down to 1. AQE is on by default in this course (`get_spark(..., aqe=True)`), and Module 14 is the one place it gets turned off deliberately, to see tuning decisions without AQE quietly fixing them for you.

AQE does more than coalescing, though coalescing is the part this lab measures directly.

| AQE feature | What it does |
|---|---|
| Coalescing shuffle partitions | merges small post-shuffle partitions into fewer, bigger ones |
| Switching join strategy at runtime | can convert a `SortMergeJoin` into a `BroadcastHashJoin` if the actual data turns out small enough, even if the static plan did not expect that |
| Skew join handling | splits an unusually large partition into smaller pieces, so one slow task does not hold up the whole stage |

The plan text itself hints at this: `AdaptiveSparkPlan isFinalPlan=false` in an `explain()` means the plan you are reading is a starting point, and AQE may still rewrite it once real data sizes are known.

## 7. Caching avoids recomputing the same data

Because DataFrames are lazy, calling `.count()` on the SAME DataFrame twice does the SAME work twice. Spark does not remember the result from last time.

```python
expensive = df.withColumn("amt_sq", F.col("amount") * F.col("amount")).filter("amt_sq > 0")
expensive.count()   # reads the files, computes amt_sq
expensive.count()   # reads the files AGAIN, computes amt_sq AGAIN
```

`.cache()` changes that. The first action after `.cache()` still does the full work, but it also stores the result in memory. Every action after that reuses the stored result.

```python
expensive.cache()
expensive.count()   # still does the full work, but now also stores it
expensive.count()   # reused from memory, no recompute
```

Cache a DataFrame when you are about to run several actions against the same expensive result. Do not cache a DataFrame you only use once, the caching itself costs time and memory for no benefit.

`.cache()` is shorthand for `.persist(StorageLevel.MEMORY_AND_DISK)`, the safest default: keep it in memory, but spill to disk rather than lose it if memory runs out. `.persist()` accepts other storage levels for special cases.

| Storage level | Where it lives | When to use it |
|---|---|---|
| `MEMORY_AND_DISK` (the `.cache()` default) | memory, spills to disk if needed | the sensible default, almost always the right choice |
| `MEMORY_ONLY` | memory only, recomputes if evicted | when you are sure it fits, and recomputing is cheap anyway |
| `DISK_ONLY` | disk only | very large data, or memory is scarce |
| `MEMORY_AND_DISK_2` | memory and disk, two copies | rare, used when losing the cache mid-job would be expensive to recover from |
| `OFF_HEAP` | outside the JVM heap | advanced tuning, rarely needed, mentioned here only so the name is not a surprise later |

Call `.unpersist()` when you are done with a cached DataFrame and want the memory back, particularly inside a long-running job that caches several different DataFrames in sequence.

`.cache()` and `.persist()` are transformations too, in the sense that they do not force execution by themselves. The DataFrame is only actually cached the next time an action runs against it.

## 8. Reading the Spark UI

Keep `http://localhost:4040` open in a tab while any lab runs. If a previous Spark session is still holding that port, the actual URL is printed at the top of the lab's output, use that instead.

| Tab | What to look at |
|---|---|
| **Jobs** | one row per action. Click a row to see its stages. |
| **Stages** | how many stages a job took, and how long each one ran |
| **Executors** | the Cores column, how many threads are actually doing work |
| **SQL / DataFrame** | the same plan `explain()` prints, but visual, with timing per node |
| **Storage** | DataFrames you have called `.cache()` on, and how much memory they hold |
| **Environment** | every effective config value, including ones you never set explicitly, useful when a setting is not behaving as expected |
| **Executors**, thread dump | a live stack trace per running task, useful when a job looks stuck rather than slow |
| **SQL / DataFrame**, node detail | click any box in the visual plan to see its own row count and time, not just the whole query's total |

A stage with a large "Shuffle Read" or "Shuffle Write" number is the stage a wide transformation created. That number, not a guess, is what a shuffle actually costs on your data.

The UI keeps history only for the current application. Once `spark.stop()` runs, the UI process shuts down with it. If you need to review a job after it finished, either keep the terminal window open before the script exits, or configure the Spark History Server, which is outside the scope of this course.

**A simple diagnostic routine**, worth practising now, before you need it under pressure in Module 14:

1. Jobs tab. Find the slow job by its Duration column.
2. Click into it. Look at its list of stages, and the Duration column there.
3. Click into the slowest stage. Check "Shuffle Read Size / Records" and "Shuffle Write Size / Records".
4. A large shuffle size usually means a wide operation on more data than expected, often a join that did not broadcast when you thought it would.
5. A stage with one task taking far longer than the rest is a skew symptom: one partition holds far more data than the others. Module 14 covers fixing this.

This routine works the same way whether you are looking at a lab on your laptop or a production job someone else wrote. The UI does not know or care who wrote the query, only what it actually did.

### Where these ideas come back

| Idea from this module | Comes back in |
|---|---|
| Explicit schemas, partitions from file count | Module 03, DataFrames |
| Partitioning written data on disk | Module 04, the lakehouse |
| Broadcast join, `SortMergeJoin` vs `BroadcastHashJoin` | Module 03 and Module 14 |
| AQE, shuffle partitions, skew | Module 14, Performance tuning |
| `.cache()` and `.persist()` | Module 06, RDDs and UDFs, and Module 14 |
| Reading the Spark UI under load | Module 13, Structured streaming |

None of these later modules re-explain partitions or the DAG from scratch. They assume this module.

If a later lab's output looks strange, come back here first. Check partition counts, check `explain()` for an unexpected `Exchange`, check the Stages tab for an unexpectedly large shuffle. Most problems in this course, and most problems in a real Spark job, trace back to one of those three checks.

## The lab

`labs/02_lab_architecture.py` proves every claim above with a number from your own machine.

| Step | Shows |
|---|---|
| 1 | The session, the driver, cores in use, and the Spark UI URL |
| 2 | Partition counts for a 3-file read and a 1-file read |
| 3 | Timing proof that building a plan is instant, running it is not |
| 4 | `explain()` for a narrow and a wide plan, plus a timing comparison |
| 5 | AQE coalescing shuffle partitions, on vs off |
| 6 | Caching: four timed `.count()` calls, no cache then cached |
| 7 | A guided walk through the Jobs and Stages tabs in the Spark UI |

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| "My job is slow but the code looks simple" | a hidden wide transformation, often inside a join that is not broadcast | check `explain()` for `Exchange`, and check the Stages tab for shuffle bytes |
| Calling `.count()` twice "to check", timing both | each call reruns the full plan from scratch | cache first if you need to inspect the same result more than once |
| Assuming more shuffle partitions is always faster | more partitions means more small tasks, and scheduling overhead adds up | let AQE coalesce, or set `shuffle.partitions` based on actual data size, not a guess |
| Reading `explain()` output top to bottom like a story | the plan is a tree, execution order is bottom to top | start at the FileScan line at the bottom and read upward |
| Caching every DataFrame "just in case" | caching costs memory and time for no benefit if used once | cache only a DataFrame you will run more than one action against |
| Confusing `repartition()` with `coalesce()` | assumed they were interchangeable ways to reduce partition count | `coalesce()` avoids a shuffle but cannot increase partitions or guarantee even sizes, `repartition()` shuffles but can do both |
| Forgetting to `.unpersist()` a large cached DataFrame | memory stays reserved long after the DataFrame is no longer needed | call `.unpersist()` once you are done with it, especially in a job that caches several DataFrames in turn |
| Reading `AdaptiveSparkPlan isFinalPlan=false` as an error | it looks alarming in a wall of plan text | it is normal, it means AQE may still rewrite the plan once real data sizes are known |
| Calling `.collect()` on a large DataFrame "just to look" | pulls every row back to the driver's memory, not a worker's | use `.show(5)` or `.limit(20).collect()` to inspect a small sample instead |
| Comparing two runs' timings without accounting for JVM warm-up | the first query in a fresh session is often slower than an identical later one, code just being loaded and JIT-compiled | run a query twice and compare the second run to the second run, not the first to the first |

## Exercises

1. Change `shuffle_partitions` in `get_spark("lab-02", shuffle_partitions=2)` and rerun. Does the narrow filter's partition count change? Does the wide groupBy's?
2. Add a second wide transformation, `df.groupBy("merchant_category").count()`, and compare its stage count and `explain()` output to the `channel` groupBy already in the lab.
3. Turn AQE off for the ENTIRE session instead of one query, by passing `aqe=False` to `get_spark(...)`. Rerun step 6 and see if the cache timings change.
4. Open the Spark UI Storage tab after step 6 runs. Confirm the cached DataFrame is listed, and note how much memory it reports.
5. Write a query that joins `transactions` to `accounts` WITHOUT `F.broadcast()`. Compare its `explain()` output and stage count to the broadcast version in Module 03. Which strategy does Spark pick on its own, and does that match what you would have chosen?
6. Using `sc.statusTracker()`, print the number of completed jobs after each step of the lab runs, and confirm the total matches what the Jobs tab in the UI shows.

## Key points

- The driver plans, the executors run the plan. `local[*]` uses one process for both, but the roles are the same as on a real cluster.
- A DataFrame is split into partitions. Partition count for a plain read follows the input files, not a config setting.
- Transformations are always lazy. Nothing runs until an action is called, no exceptions.
- A wide transformation shuffles: data is written out and re-read, partitioned by a key. `explain()` shows this as `Exchange`.
- AQE coalesces small shuffle partitions automatically. `.cache()` avoids recomputing the same DataFrame more than once. Both are proven with real numbers in the lab, not asserted.
- `repartition()` shuffles, `coalesce()` does not. Reach for `coalesce()` first when you only need fewer partitions.
- The Spark UI Jobs, Stages, Executors and Storage tabs are not for emergencies only. Get comfortable reading them on a lab that is working correctly, before you need them on one that is not.
- Task count follows partition count, stage by stage. If a number in the UI looks wrong, check the partition count feeding that stage first.
- `local[*]` is a real Spark deployment. Everything you learn here about partitions, stages and shuffles carries over unchanged to a real cluster.
- When something looks wrong, check partition counts, `explain()`, and the Stages tab, in that order, before reaching for a bigger cluster.
