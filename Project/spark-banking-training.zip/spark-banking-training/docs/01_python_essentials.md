# Module 01: Python essentials for Spark

After this module you can read and write the Python that the rest of this course, and most PySpark code at your bank, is built from.

## Why this matters in a bank

Spark's DataFrame API is Python objects calling Python methods. Every `.filter(...)`, every `lambda`, every class in a packaged job is ordinary Python underneath. If the Python is shaky, every later module gets harder to follow for no good reason. This module is the floor you stand on, not a detour.

Module 15, later in this course, packages a PySpark job the way a real deployment expects: a small package of modules, not one long script. None of that will make sense without this module first.

You already know SQL. This module leans on that: a Python list is a bit like a result set, a dict is a bit like a one-row lookup, and a function is a bit like a stored procedure. The lab, `labs/01_lab_python.py`, is pure Python. No Spark, no cluster. Run it, read it, and move on to Module 02 where Spark starts.

One habit to bring from day one: Python uses indentation, not `BEGIN`/`END` or curly braces, to mark what is inside a function, a loop, or an `if`. Four spaces is the usual indent. Get the indentation wrong and Python either refuses to run the file or, worse, runs a different piece of logic than the one you meant.

## 1. Variables, lists, dicts

Python does not need a declared type. A name just points at a value.

```python
branch_name = "Mumbai Main Branch"
```

A **list** is an ordered, changeable collection, written with square brackets.

```python
amounts = [1200.0, -50.0, 999.5, 30000.0, 15.75]
amounts[0]     # 1200.0, the first item
amounts[-1]    # 15.75, the last item
```

A **dict** maps a key to a value, written with curly braces. Think of it as one row from a table, addressed by column name instead of position.

```python
account = {"account_id": "ACC9000001", "balance": 79760.71, "status": "ACTIVE"}
account["balance"]   # 79760.71
```

There is also a **tuple**, an ordered collection like a list, but one you cannot change after creating it. Use it for a fixed, small group of values, for example a coordinate pair or a row you never intend to modify.

```python
branch_location = ("Mumbai", "Maharashtra")   # round brackets, not square
```

| Type | Written as | Changeable | Typical use in this course |
|---|---|---|---|
| list | `[1, 2, 3]` | yes | a column of values, a batch of transactions |
| dict | `{"k": "v"}` | yes | one row, addressed by field name |
| tuple | `(1, 2)` | no | a fixed pair or triple that should never change |

## 2. List comprehension

A comprehension builds a new list from an old one, in one line. It replaces the classic "build an empty list, then append in a loop" pattern.

The for-loop way:

```python
positive = []
for a in amounts:
    if a > 0:
        positive.append(a)
```

The same result, as a comprehension: `[expression for item in list if condition]`.

```python
positive = [a for a in amounts if a > 0]
```

A comprehension can transform each item too, not just filter it:

```python
doubled = [a * 2 for a in positive]
```

Use a comprehension when the loop body is one line. If you need several lines of logic per item, a plain for-loop is clearer and that is fine.

Why this matters here: a Spark DataFrame column transformation, `df.withColumn("doubled", F.col("amount") * 2)`, is the same idea as a list comprehension, apply one expression to every row. Getting comfortable with the comprehension version in plain Python makes the Spark version read naturally in Module 03.

## 3. Functions

A function is defined with `def`, takes arguments, and sends a value back with `return`. An argument can have a default, so most calls only need to pass the values that differ from the usual case.

```python
def apply_interest(balance, rate=0.03):
    return round(balance * (1 + rate), 2)

apply_interest(10000)              # uses the default rate, 0.03
apply_interest(10000, rate=0.05)   # overrides it
```

An argument can be passed **positionally**, by order, or **by keyword**, by name. Both calls above work. Once a function takes more than two or three arguments, calling it by keyword is safer, because it does not depend on remembering the exact order.

```python
def transfer(from_account, to_account, amount, currency="INR"):
    return f"{amount} {currency} from {from_account} to {to_account}"

transfer("ACC1001", "ACC1002", 500)                       # positional
transfer(from_account="ACC1001", to_account="ACC1002", amount=500)   # by keyword, clearer
```

## 4. `*args` and `**kwargs`

Sometimes you do not know in advance how many arguments a function will get. `*args` collects any number of positional arguments into a tuple.

```python
def total_of(*amounts):
    return sum(amounts)

total_of(100, 200, 300)   # 600
```

`**kwargs` does the same for named arguments, collecting them into a dict.

```python
def open_account(**details):
    return f"opening {details['account_type']} account for {details['customer']}"

open_account(customer="Priya Rao", account_type="SAVINGS")
```

You will meet both reading library code, including parts of PySpark, where a function accepts options it does not know the full list of in advance.

The two can appear on the same function, and Python requires this order: normal arguments, then `*args`, then `**kwargs`.

```python
def log_transaction(txn_id, *flags, **metadata):
    print(txn_id, flags, metadata)

log_transaction("TXN1", "HIGH_VALUE", "FLAGGED", channel="UPI", city="Pune")
# TXN1 ('HIGH_VALUE', 'FLAGGED') {'channel': 'UPI', 'city': 'Pune'}
```

## 5. What a class is

A class is a template for objects. `__init__` runs once, when the object is created, and sets up its starting state. `self` refers to the one object the method is currently running on, not the class in general.

```python
class Account:
    def __init__(self, account_id, balance):
        self.account_id = account_id   # an attribute: data that belongs to THIS account
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount

acc = Account("ACC1001", 5000.0)
acc.deposit(1500.0)
acc.balance   # 6500.0
```

Every method takes `self` as its first parameter so it can read and change that one object's attributes.

Two accounts built from the same class are independent. Changing one does not touch the other, because each has its own `self.balance`.

```python
acc2 = Account("ACC1002", 9000.0)
acc.deposit(100)
acc.balance    # 6600.0
acc2.balance   # 9000.0, unchanged
```

A plain variable inside a method that is not written as `self.something` disappears when the method returns. Only attributes on `self` persist on the object between calls.

## 6. Instance, class and static methods

| Kind | First parameter | Needs |
|---|---|---|
| Instance method | `self` | one specific object, to read or change its data |
| Class method (`@classmethod`) | `cls` | the class itself, often used to build an object a different way |
| Static method (`@staticmethod`) | neither | no object or class data, just belongs with the class logically |

```python
class SavingsAccount(Account):
    bank_name = "AtliQ Bank"          # a class attribute: shared by every instance

    def __init__(self, account_id, balance, rate):
        super().__init__(account_id, balance)
        self.rate = rate

    def add_interest(self):           # instance method
        self.balance = round(self.balance * (1 + self.rate), 2)

    @classmethod
    def with_default_rate(cls, account_id, balance):
        return cls(account_id, balance, rate=0.035)

    @staticmethod
    def is_valid_rate(rate):
        return 0 <= rate <= 0.10
```

`with_default_rate` is a second way to build a `SavingsAccount`, one that does not ask the caller for a rate. `is_valid_rate` does not touch any specific account, it is a rule that just happens to live on this class.

A simple rule of thumb for picking which one to write:

| Ask yourself | Then write |
|---|---|
| Does this need one specific account's data? | an instance method, with `self` |
| Does this build or configure the class itself, not one account? | a class method, with `cls` |
| Does this just need the arguments passed in, nothing from the class? | a static method |

## 7. The four OOP concepts

Each one, with a one-line banking example.

**Encapsulation.** Change data only through methods that can check it, not by poking a field directly.

```python
class GuardedAccount:
    def __init__(self, balance):
        self._balance = balance        # the underscore signals "internal"

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("deposit must be positive")
        self._balance += amount
```

In a bank, this is why a core banking system never lets a caller set `balance` directly. Every change goes through a method that can enforce a rule, log the change, or reject it.

**Inheritance.** `SavingsAccount(Account)` in section 6 already reuses `Account`'s `__init__` and `deposit`. It did not have to rewrite them. `SavingsAccount`, `CurrentAccount`, `NREAccount` can all share one `Account` base and only add what differs, the interest rule, the minimum balance, the currency handling.

**Polymorphism.** The same method name behaves differently per class.

```python
class CurrentAccount(Account):
    def add_interest(self):
        pass   # current accounts earn no interest

for a in [savings_account, current_account]:
    a.add_interest()   # correct behaviour for each, from the same call
```

A monthly interest job can loop over every account type and call `add_interest()` on each one, without an `if` statement checking what kind of account it is. Each class knows its own rule.

**Abstraction.** A caller of `apply_interest()` or `deposit()` does not need to know the formula or the validation inside. The method hides it. That is the whole point of a method.

This is also why a well-designed `Account` class is safe to hand to another team. They call `deposit()` and `add_interest()`. They never need to know, or accidentally depend on, how the balance is stored internally.

## 8. Modules and packages

A **module** is one `.py` file. A **package** is a folder of modules with an `__init__.py` file in it, which is what tells Python "treat this folder as one importable unit".

This course ships one: `labs/bankutils/`, with `formatting.py` and `rules.py` inside.

```python
from bankutils import formatting
from bankutils.rules import risk_band

formatting.as_rupees(125000)   # 'Rs 1,25,000.00'
risk_band(65)                  # 'SUBSTANDARD'
```

| Import style | When to use it |
|---|---|
| `import bankutils` | you will call `bankutils.formatting.as_rupees(...)`, fully qualified |
| `from bankutils import formatting` | you will call `formatting.as_rupees(...)` a few times |
| `from bankutils.rules import risk_band` | you only need this one function, call it as `risk_band(...)` |

Avoid `from bankutils import *`. It pulls every public name into your file at once, so a reader cannot tell which module a given function came from just by looking at the call site.

`__init__.py` can be empty, it just needs to exist. Python sees the file and treats the folder as a package. A larger project might use it to control exactly what a `from bankutils import *` exposes, but for this course an empty or near-empty `__init__.py` is normal and enough.

The difference in one line: a module is one file, a package is a folder of modules that import as a unit. Every real PySpark project you will work on at the bank is organised as one or more packages, not a folder of loose scripts.

## 9. Logging

`print()` cannot be turned off, carries no severity, and has no timestamp. `logging` gives you all three, which matters once code runs unattended, for example inside an Airflow task at 2 AM.

```python
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("my_job")

log.info("account %s opened with balance %s", "ACC1001", 5000.0)
log.warning("balance below minimum for %s", "ACC9099")
```

| Level | Use it for |
|---|---|
| `DEBUG` | detail you only want while developing |
| `INFO` | normal progress, "job started", "1200 rows written" |
| `WARNING` | something odd, but the job carries on |
| `ERROR` | the job failed to do part of its work |

Setting `level=logging.INFO` hides `DEBUG` messages automatically. Change one line to see them again, instead of hunting down and re-adding a dozen `print()` calls.

The `%s` placeholders in `log.info("account %s opened...", account_id)` are deliberate. Pass values as arguments, not with an f-string, so the string formatting only happens if the message is actually going to be shown. On a busy job that logs at `INFO` but has thousands of `DEBUG` calls, this avoids doing pointless work for messages that never print.

By default `logging` writes to the console, exactly where these labs run. A production job typically adds a file handler as well, so the log survives after the console is gone. That is one line more than `basicConfig`, and outside the scope of this module.

## A note on naming

Two conventions to read code comfortably from here on.

| Kind | Convention | Example |
|---|---|---|
| Variable, function | `snake_case`, lower case with underscores | `account_id`, `apply_interest` |
| Class | `PascalCase`, each word capitalised | `Account`, `SavingsAccount` |
| Constant | `UPPER_SNAKE_CASE` | `MAX_DAILY_LIMIT` |

These are conventions, not rules Python enforces. Following them means your code reads the way every other Python file at the bank reads, which is worth more than it sounds.

## The lab

`labs/01_lab_python.py` is pure Python. No SparkSession is created.

| Step | Shows |
|---|---|
| 1 | Variables, lists, dicts |
| 2 | List comprehension, for-loop version next to it |
| 3 | Functions, then `*args` and `**kwargs` |
| 4 | A class: `Account`, with `__init__` and `self` |
| 5 | `SavingsAccount`: instance, class and static methods |
| 6 | The four OOP concepts, each with a one-line banking example |
| 7 | Importing from the `bankutils` package |
| 8 | `logging`, with levels |

## Common mistakes

| Mistake | Cause | Fix |
|---|---|---|
| `TypeError: missing 1 required positional argument` | called a method on the class, not an instance, e.g. `Account.deposit(100)` | call it on an object: `acc.deposit(100)` |
| A `@staticmethod` that still needs `self` | the method actually depends on instance data | make it a normal instance method instead |
| `ImportError: No module named bankutils` | ran the lab from the wrong folder | run it with `./run.sh labs/01_lab_python.py` from the project root |
| Every message printed with `print()` in a long job | no way to turn off the noise later, no timestamps | use `logging` with a level, from the start |
| A list comprehension with three nested conditions | trying to do too much in one line | fall back to a plain for-loop, it will be easier to read |
| Forgetting `self` in an instance method's parameter list | copied a static method and added logic that needs the object | add `self` back as the first parameter |
| A class attribute changed on one instance, unexpectedly changes on all of them | assigned a mutable value, like a list, as a class attribute and mutated it in place | set that kind of value inside `__init__` on `self` instead, so each instance gets its own copy |
| `*args` or `**kwargs` used where named parameters would be clearer | copied a pattern from a library without needing its flexibility | prefer explicit named parameters, with defaults, when you know what the caller will pass |

## Exercises

1. Write a list comprehension that takes `amounts` and returns only the values over 1000, rounded to the nearest integer.
2. Add a `CurrentAccount` class that inherits from `Account` and overrides `deposit` to reject deposits under Rs 100.
3. Add a third module to `bankutils`, for example `ifsc.py`, with one function that checks an IFSC code is 11 characters long. Import and call it from the lab.
4. Change the lab's `logging.basicConfig` level to `DEBUG` and add one `log.debug(...)` call. Confirm it now prints.
5. Write a function `summarise(*amounts, **labels)` that prints the count and sum of `amounts`, followed by every key and value in `labels`. Call it with a mix of both.

## Key points

- Python underneath Spark is ordinary Python. Nothing here is Spark-specific, but everything here shows up inside Spark code later.
- A list comprehension is a for-loop that builds a list, written on one line, no more than that.
- `self` is the object a method is running on. `cls` is the class itself, used by `@classmethod`.
- Encapsulation, inheritance, polymorphism and abstraction are not academic terms. Each one is a reason a real `Account` class is written the way it is.
- A package is just a folder with `__init__.py` in it. `bankutils/` is the smallest possible example.
- `logging`, not `print()`, once code needs to run on its own.
- Naming conventions, `snake_case` for functions and variables, `PascalCase` for classes, make your code readable to everyone else on the team.
- Closures, decorators beyond `@classmethod`/`@staticmethod`, type hints and dataclasses are not covered here. You will not need them for this course.
