# Module 07: Using pandas from PySpark

After this module you can decide when `toPandas()` is safe, use
`applyInPandas` for a per-group pandas calculation, and know what
`pyspark.pandas` is for.

## Why this matters in a bank

Most banking teams already have pandas scripts: a reconciliation
notebook, a regulatory report, a model someone prototyped. The question
this module answers is not "pandas or Spark", it is "which of the three
ways to combine them fits this particular job", because picking the
wrong one is how a script that worked fine on a sample crashes the
driver on the full table.

None of the three tools below are wrong in general. Each is wrong for a
SPECIFIC job, usually the job of touching the full, unaggregated table.
Knowing which is which takes thirty minutes. Finding out the hard way,
on a production job at 2am, takes much longer.

| Pandas artifact a bank already has | What usually needs to change |
|---|---|
| a reconciliation notebook comparing two extracts | the comparison logic, if it is a simple aggregate, moves to native Spark; if it is a custom per-branch rule, `applyInPandas` |
| a regulatory report built with `pandas.read_csv` and `groupby` | the read and groupby move to Spark, only the final small table goes through `toPandas()` for formatting |
| a model prototype written and validated in pandas or scikit-learn | often stays as a pandas UDF or `applyInPandas`, since rewriting a validated model is its own risk |
| an ad hoc analysis a single analyst runs on their laptop | frequently does not need to move at all, until the data it reads outgrows the laptop |

The right migration is rarely "convert everything to `pyspark.pandas`".
It is "identify which calls actually touch large data, and change only
those".

## toPandas() driver memory, the actual arithmetic

`toPandas()` pulls every row of a DataFrame into ONE pandas DataFrame,
on the driver, in the driver's memory. There is no partitioning once it
lands: the whole thing has to fit.

```python
row_count = txns.count()
avg_bytes_per_row = 130           # rough: about 12 columns, mostly short strings, one double
estimated_mb = row_count * avg_bytes_per_row / (1024 * 1024)
driver_memory_mb = 2048           # a typical laptop's default Spark driver heap
```

On this course's transaction feed, 180,720 rows, that arithmetic gives
about 22 MB, comfortably under a 2 GB driver heap. The SAME table at a
real bank's daily volume, tens of millions of rows, gives an estimate in
the multiple gigabytes, easily larger than the driver's heap. The fix is
never "give the driver more memory". It is "make Spark do the reduction
first", so only a small, already-aggregated result ever reaches the
driver.

| Rows | Rough size as pandas | Safe on a 2 GB driver? |
|---|---|---|
| 180,720 (this course's feed) | ~22 MB | yes |
| 10 million | ~1.2 GB | risky, over half the heap |
| 100 million | ~12 GB | no, do not attempt |

## Where pandas is legitimately useful

Not every use of pandas inside a Spark job is a mistake. The honest list
is short, and everything on it shares one property: the DATA at that
point is already small.

| Legitimate use | Why it is safe |
|---|---|
| Plotting a chart from an aggregated result | the aggregate is already small, the chart library needs pandas or numpy anyway |
| Handing a small lookup table to a library with no Spark integration | the table is small by definition, for example a currency rate table |
| A statistical test on a per-group sample | `applyInPandas` keeps the DATA distributed, only the CALCULATION uses pandas |
| Prototyping a rule on a `.sample()` before writing it as a Spark built-in | the sample is small on purpose |
| Formatting a final table for an email or a slide, with pandas' styling options | formatting happens after all the heavy computation is done |

The property they all share, worth repeating: pandas touches data that
is already small, either because it was aggregated, sampled, or was
always small. The moment pandas would touch the FULL, unaggregated
table, the tool is wrong for the job.

## A toPandas() that is safe

Aggregate BEFORE calling `toPandas()`, so only the small, final result
crosses over to the driver:

```python
daily = (txns.withColumn("posting_date", F.to_date("txn_ts"))
    .groupBy("posting_date")
    .agg(F.count("*").alias("txn_count"), F.round(F.sum("amount"), 2).alias("total_amount")))
daily_pdf = daily.toPandas()      # 3 rows, not 180,720. Safe.
```

The pattern is always the same: let Spark's distributed engine do the
heavy reduction, and only call `toPandas()` on what is already small
enough to plot, email, or hand to a library that only accepts pandas.

## toPandas() vs collect()

Both pull every row to the driver. They differ in what shape you get
back, and that difference matters once the result is not tiny.

| | `.collect()` | `.toPandas()` |
|---|---|---|
| Returns | a Python list of `Row` objects | one pandas DataFrame |
| Needs Arrow | no | only if `spark.sql.execution.arrow.pyspark.enabled` is set, otherwise it still works, just slower |
| Typical use | a handful of rows you will loop over in plain Python | a result you will hand to pandas, matplotlib, or a report |
| Memory shape | one Python object per row, all on the driver | one contiguous pandas DataFrame, all on the driver |

Neither is "the safe one". Both have the exact same rule from this
module: know the row count and the row size before you call either,
because both land the full result in the driver's memory.

## createDataFrame from pandas, and a schema trap

Going the other way, pandas to Spark, has one trap worth knowing before
it costs you an hour. Spark's Python-side type verifier is stricter than
Python itself about numeric types.

```python
import pandas as pd
pdf = pd.DataFrame({"count": [3.0, 5.0]})     # a float column, values that look like whole numbers

# does NOT work: the verifier rejects a float value like 3.0 for a
# declared IntegerType field, it does not silently truncate it for you
bad = spark.createDataFrame(pdf, schema="count int")

# WORKS: cast after the DataFrame already exists
good = spark.createDataFrame(pdf).withColumn("count", F.col("count").cast("int"))
```

The fix is always the same: let Spark infer the schema from the pandas
DataFrame first, then cast the columns that need a different type,
rather than declaring a stricter schema upfront and hoping Spark
coerces the values for you.

## applyInPandas: a real per-group calculation

`applyInPandas` is different from `toPandas()` in an important way: the
DATA STAYS DISTRIBUTED. Spark groups the rows, then hands each GROUP to
a worker as a pandas DataFrame, runs your function there, and collects
the results back into a distributed DataFrame. Nothing large ever lands
on the driver.

```python
result_schema = "branch_code string, txn_count long, total_amount double, avg_amount double"

def reconcile_branch(pdf: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame([{
        "branch_code": pdf["branch_code"].iloc[0],
        "txn_count": len(pdf),
        "total_amount": round(pdf["amount"].sum(), 2),
        "avg_amount": round(pdf["amount"].mean(), 2),
    }])

by_branch.groupBy("branch_code").applyInPandas(reconcile_branch, schema=result_schema)
```

This is the right tool when the calculation genuinely needs pandas
methods PER GROUP, for example a statistical test, a custom
reconciliation rule already written in pandas, or a per-account model
that pandas already has and Spark does not. If the per-group logic is
just `count()`, `sum()`, or `mean()`, Spark's own `.agg()` does the same
job faster, with no Arrow round trip at all.

Like a pandas UDF, `applyInPandas` needs Apache Arrow to move data
between the JVM and the Python worker, and Arrow is sensitive to the
exact JDK build. Guard it the same way, and see the pandas UDF note in
Module 06.

## A short look at the Pandas API on Spark

`pyspark.pandas` gives you pandas SYNTAX, `.mean()`, column indexing,
no `.select()` or `.groupBy()`, while the work underneath still runs as
distributed Spark jobs, not in the driver's memory.

```python
import pyspark.pandas as ps
psdf = ps.DataFrame({"branch_code": ["BR011", "BR021"], "txn_count": [14824, 1152]})
psdf.sort_values("txn_count", ascending=False)
```

It exists for teams migrating an existing pandas codebase to Spark
without a full rewrite: the method names mostly match, so a script
written for a laptop-sized CSV can run against a table too large for any
one machine, with the same syntax. It is not a drop-in replacement for
every pandas feature, and it needs a pandas version this Spark build
supports; a version mismatch is the most common reason it fails to
import at all on a given machine.

## Pandas habits that do not translate

A few pandas reflexes cause real confusion the first time someone
brings them into `pyspark.pandas` or an `applyInPandas` function.

| Pandas habit | Why it is different here |
|---|---|
| `df.iloc[3]`, positional row access | Spark has no guaranteed row order across partitions, "row 3" is not a stable idea |
| `df[df.amount > 100] = 0`, chained assignment | Spark DataFrames are immutable, every operation returns a NEW DataFrame |
| `df.sort_values(inplace=True)` | there is no `inplace` in Spark, and only limited support in `pyspark.pandas` |
| looping over `df.iterrows()` | pulls the whole thing through Python row by row, exactly the slow path this module warns about |
| `df.merge(other_df)` for a join | `pyspark.pandas` supports `.merge()`, but a native Spark `.join()`, with an explicit `F.broadcast()` for a small table, is usually clearer and faster |

Inside an `applyInPandas` function, the pandas DataFrame you get IS a
real, local, in-memory pandas DataFrame for that one group, so ordinary
pandas idioms like `.iloc` are fine there. The caution is about treating
the OUTER Spark DataFrame as if it were pandas.

## Arrow and batch size

Both a pandas UDF and `applyInPandas` move data in batches, not all at
once, controlled by `spark.sql.execution.arrow.maxRecordsPerBatch`
(default 10,000 rows). A very wide table, many columns, can need a
smaller batch size to avoid a large spike in worker memory; a narrow
table rarely needs to touch this setting at all. It is a tuning knob for
later, not something a 30 minute module needs to change.

`spark.sql.execution.arrow.pyspark.enabled` turns Arrow ON for a plain
`toPandas()` call too, which is usually faster than the non-Arrow path.
Its companion, `spark.sql.execution.arrow.pyspark.fallback.enabled`
(on by default), is meant to quietly retry WITHOUT Arrow if the Arrow
path fails. In practice that fallback only catches certain conversion
errors, not every possible failure, so treat it as a convenience, not a
guarantee that `toPandas()` will always succeed just because Arrow is
enabled. If `toPandas()` fails in a way that looks like an Arrow or JDK
problem rather than a data problem, trying it again with Arrow OFF is a
quick way to tell the two apart.

## Migrating a small pandas script

A common real task: someone already has a pandas script that computes
average outstanding loan amount by product, and it needs to run against
a table too large for one laptop. The pandas version:

```python
import pandas as pd
loans_pdf = pd.read_csv("loans.csv")
by_product = loans_pdf.groupby("product")["outstanding"].mean()
```

The direct Spark equivalent, same shape, same answer, no row limit:

```python
loans = spark.read.option("header", True).schema(loan_schema).csv(f"{RAW}/loans.csv")
by_product = loans.groupBy("product").agg(F.avg("outstanding").alias("outstanding"))
```

Nothing here needed `pyspark.pandas`, `applyInPandas`, or `toPandas()`.
Most "migrate this pandas script" tasks are really "rewrite these few
pandas calls as their native Spark equivalents", which is usually both
simpler and faster than trying to keep the original pandas syntax alive
through `pyspark.pandas`.

Before trusting a rewritten pipeline, check the two versions actually
agree, on a sample small enough for both to run:

```python
pandas_answer = loans_pdf.groupby("product")["outstanding"].mean().round(2)
spark_answer = by_product.toPandas().set_index("product")["outstanding"].round(2)
print((pandas_answer - spark_answer).abs().max())   # should be a tiny number, not zero exactly
```

A tiny non-zero difference is normal, the same floating point ordering
issue this course's Module 06 covers for `reduceByKey` vs `groupByKey`.
A large difference means the rewrite is not equivalent yet, and is worth
finding before the pipeline ever reaches production, not after.

## Decision guide: which tool, for which job

| Need | Use | Where the data lives while it runs |
|---|---|---|
| a small final result, already aggregated, on the driver | `toPandas()`, after aggregating | driver, after the aggregate shrinks it |
| a pandas-only calculation, per group, at Spark scale | `applyInPandas` | distributed, one group at a time |
| pandas syntax over the full dataset, migrating existing pandas code | `pyspark.pandas` | distributed, the whole time |
| everything else | the native DataFrame API, it is almost always fastest | distributed, the whole time |

The native DataFrame API is the default. Reach for one of the other
three only when you have a specific reason: the result really is small,
the calculation really does need pandas per group, or the codebase
really is being migrated from pandas syntax.

Notice the pattern in the "where the data lives" column: only
`toPandas()` ever puts the full result on the driver, and only after
you, the author, chose to aggregate first. The other two keep the data
spread across the cluster the entire time, which is exactly why they
scale to tables `toPandas()` could never touch.

## The lab

`labs/07_lab_pandas.py`, 30 minutes.

| Step | What it shows |
|---|---|
| 1 | toPandas() driver memory, the actual arithmetic before you run it |
| 2 | A toPandas() that is safe, because the result is small |
| 3 | applyInPandas: a per-branch reconciliation, one pandas call per group |
| 4 | A short look at the Pandas API on Spark |
| 5 | Decision guide: which tool, for which job |

Run it:

```bash
./run.sh labs/07_lab_pandas.py
```

Steps 3 and 4 are wrapped in try/except. Both need Arrow, or in step 4's
case a matching pandas version, and different laptops in the room can
disagree on either. If either is skipped on your machine, the code shown
is still correct for a machine where the versions line up.

## Common mistakes

The table below lists the failure, its real cause, and the fix, in that
order. Most of these show up first as a confusing error message that
does not mention memory, schema, or Arrow by name.

| Mistake | Real cause | Fix |
|---|---|---|
| `toPandas()` hangs or the driver runs out of memory | called on a large, unaggregated DataFrame | aggregate first, check the row count before calling `toPandas()` |
| `applyInPandas` result has the wrong columns | the function's returned DataFrame does not match the declared `schema` string exactly | make the pandas function's output columns and types match the schema, in the same order |
| `import pyspark.pandas` fails | pandas or pyarrow version does not match what this Spark build expects | check `pandas.__version__` against the Spark version's documented support range |
| `applyInPandas` throws an Arrow-related error on one laptop but not another | JDK build differences, same root cause as Module 06's pandas UDF issue | try `--add-opens=java.base/java.nio=ALL-UNNAMED`, or fall back to the native `.agg()` if the calculation does not truly need pandas |
| A pandas function used inside `applyInPandas` is slow | it was written for a single laptop-sized DataFrame and does something expensive like a nested Python loop, now running once per group instead of once total | profile it on one group first, vectorise with pandas/numpy operations instead of looping |
| One group is much slower than the rest inside `applyInPandas` | data skew, one group, for example one branch, has far more rows than the others | check `.groupBy("branch_code").count()` first, salt or pre-aggregate the skewed group before applying pandas logic |
| `createDataFrame` from a pandas DataFrame raises a type error | the pandas column's dtype does not match the declared Spark schema exactly, for example a float column against a declared `int` | let Spark infer the schema first, then `.cast(...)` the columns that need a different type |
| A "migrated" Spark pipeline gives a different answer than the original pandas script | an implicit pandas default, like how NaN is treated in a `groupby`, was not carried over | compare the two on a small sample before trusting the rewrite on the full table |

## Exercises

1. Estimate, using the arithmetic from this module, how many rows of
   this course's transaction table would use half of a 4 GB driver heap.
   Compare it to the actual row count.

2. Change `reconcile_branch` to also return the branch's most common
   `channel`, using `pdf["channel"].mode()`. Confirm the schema string
   is updated to match.

3. Try `import pyspark.pandas as ps` in a plain Python shell, outside
   this lab's guarded try/except, and read the actual error if it fails.
   Identify which library version is the mismatch.

4. Take the loans migration example above and add one more column to
   the pandas version, the maximum `dpd` per product, using
   `.groupby("product")["dpd"].max()`. Write the native Spark
   equivalent, in the SAME `.agg(...)` call as the average outstanding,
   so the data is scanned once, not twice. Confirm both versions agree
   using the small equivalence check shown earlier in this module.

## Key points

- `toPandas()` pulls everything to the driver's memory. Aggregate first, or do the arithmetic before you run it.
- `applyInPandas` keeps the data distributed and hands pandas one group at a time. Use it when the logic truly needs pandas per group.
- `pyspark.pandas` gives pandas syntax at Spark scale, mainly useful for migrating existing pandas code.
- Both `applyInPandas` and pandas UDFs need Arrow, which is sensitive to the JDK build. Guard the call in a room with mixed laptops.
- The native DataFrame API is still the default. Use one of the other three only for a specific, real reason.
