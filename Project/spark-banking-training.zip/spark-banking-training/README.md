# Apache Spark for Banking IT

A 3-day hands-on course. Open source Spark 3.5 on Windows with WSL2. No
Databricks, no Fabric, no cloud account, no licence.

## The rhythm of the course

Most modules run in three steps:

| Order | What |
|---|---|
| 1 | The trainer explains the concept |
| 2 | You work through the **notebook** in `notebooks/`, learning the commands cell by cell |
| 3 | You run the **lab file** in `labs/`, seeing the full flow end to end |

The notebook is not the lab split into cells. It is small isolated examples of
each command, with room to experiment. The lab builds a pipeline. The notebook
teaches the vocabulary the pipeline is written in.

Lab numbers match module numbers, all the way through.

Notebooks exist for modules 01, 03, 05, 06, 07, 08, 09, 10, 11, 12 and 16.
Modules 02, 04, 13, 14, 15, 17 and 18 are script-only on purpose: they need
wall-clock timing, the Spark UI, a full pipeline run, or `spark-submit`.

**One notebook at a time.** Only one Spark session runs per kernel. Use
**Kernel > Restart Kernel** before opening the next notebook.

| Module | Lab file | Day |
|---|---|---|
| 01 Python essentials for Spark | `labs/01_lab_python.py` | 1 |
| 02 Spark architecture | `labs/02_lab_architecture.py` | 1 |
| 03 DataFrames | `labs/03_lab_dataframes.py` | 1 |
| 04 Lakehouse: bronze, silver, gold | `labs/04_lab_lakehouse.py` | 1 |
| 05 Data models | `labs/05_lab_data_models.py` | 2 |
| 06 RDDs and UDFs | `labs/06_lab_rdd_udf.py` | 2 |
| 07 Using pandas | `labs/07_lab_pandas.py` | 2 |
| 08 Data quality | `labs/08_lab_data_quality.py` | 2 |
| 09 SQL, Python and Spark | `labs/09_lab_sql.py` | 2 |
| 10 Window functions | `labs/10_lab_windows.py` | 2 |
| 11 Table formats: Delta and Iceberg | `labs/11_lab_delta.py`, `labs/11b_lab_iceberg.py` | 3 |
| 12 Polyglot persistence | `labs/12_lab_file_formats.py` | 3 |
| 13 Structured streaming | `labs/13_lab_streaming.py` | 3 |
| 14 Performance tuning | `labs/14_lab_tuning.py` | 3 |
| 15 Packaging PySpark apps | `labs/15_lab_packaging.py` | 3 |
| 16 MLlib overview | `labs/16_lab_mllib.py` | 3 |
| 17 Airflow basics | `labs/17_lab_pipeline.py` | 3 |
| 18 Airflow scheduling lab | `airflow/dags/bank_pipeline.py` | 3 |
| 19 Deep dive appendix | reading only | reference |

## Setup

Put the project in your **Linux** home, never on `/mnt/c/`.

```bash
mkdir -p ~/projects && cd ~/projects
unzip spark-banking-training.zip && cd spark-banking-training

python3 -m venv .venv
source .venv/bin/activate
pip install --no-cache-dir -r requirements.txt
```

Prove Spark starts:

```bash
./run.sh src/bank_session.py
```

You should see `Spark version : 3.5.0` and a table of five rows.

Generate the dataset. It takes about 4 seconds.

```bash
python labs/00_generate_data.py
```

## Running a notebook

```bash
jupyter lab
```

A browser tab opens. Open the notebook for the module you are on and run each
cell with `Shift + Enter`.

## Running a lab

From the VS Code terminal:

```bash
./run.sh labs/03_lab_dataframes.py
```

`run.sh` does one thing. It sets `PYTHONPATH` so `import bank_session` works
from any folder. It is 8 lines, you can read it.

In VS Code you can also open the file and press the play button, or select a
few lines and press `Shift + Enter` to run just that part.

Three rules that prevent most problems:

| Rule | Why |
|---|---|
| Keep the project in `~/projects/` | files on `/mnt/c/` go through a translation bridge and Spark reads become very slow |
| Open VS Code with `code .` from the Ubuntu terminal | otherwise VS Code runs in Windows mode and every import fails |
| The bottom-left corner must say `WSL: Ubuntu` | that is your proof VS Code is inside Linux |

## The dataset: AtliQ Bank

A synthetic retail bank. No real customer data. The seed is fixed, so every
laptop in the room produces identical numbers.

| File | Rows |
|---|---|
| `transactions/dt=*.csv` | 180,720 over 3 days |
| `accounts.csv` | 12,000 |
| `customers.csv` | 8,000 |
| `cards.csv` | 9,000 |
| `loans.csv` | 3,000 |
| `stream_pool.csv` | 12,000 |
| `txn_updates.csv` | 4,000 |
| `fraud_labels.csv` | 514 |
| `branches.csv` | 36 |
| `forex_rates.csv` | 6 |

The data is **deliberately dirty**. Each defect is the hook for a module.

| Defect | Rate | Fixed in |
|---|---|---|
| Exact duplicate `txn_id` rows | about 0.4 percent | 04 and 10 |
| `account_id` not in `accounts.csv` | about 0.5 percent | 03 and 04 |
| Negative amounts | about 0.2 percent | 08 |
| `channel` padded and lowercase, like `" upi "` | about 6 percent | 03 and 04 |
| Empty `merchant_category` | about 7 percent | 03 and 08 |
| One branch holding 22 percent of accounts | by design | 14 |

## Folders

| Folder | What is in it |
|---|---|
| `notebooks/` | 11 practice notebooks, worked through before the matching lab |
| `labs/` | the 18 lab files you run, numbered by module |
| `labs/bankutils/` | a tiny package, used by module 01 to make packages concrete |
| `labs/bankjobs/` | a real installable Spark application, used by module 15 |
| `docs/` | the teaching notes, one per module |
| `src/bank_session.py` | the only place Spark is configured |
| `airflow/dags/` | one DAG, `bank_pipeline.py`, for module 18 |
| `tests/` | pytest examples for module 15 |
| `data/raw/` | generated source CSVs |
| `data/warehouse/` | everything the labs write, as Parquet |

## Run order

**Lab 04 writes the bronze, silver and gold Parquet that Day 2 and Day 3 labs
read.** If you skip it, later labs will tell you to go back and run it.

To start a day clean:

```bash
rm -rf data/warehouse
./run.sh labs/04_lab_lakehouse.py
```

Your source CSVs in `data/raw/` are untouched, so there is no need to
regenerate them.

## Two things that need extra setup

| Thing | Note |
|---|---|
| Module 11, Delta and Iceberg | the first run downloads about 60 MB of jars from Maven Central into `~/.ivy2`. Needs internet once, then it is cached |
| Module 18, Airflow | install it in a **separate** virtual environment. Never in the PySpark one. See `docs/18_airflow_lab.md` |

## Useful links

- [Spark SQL and DataFrame guide](https://spark.apache.org/docs/3.5.0/sql-programming-guide.html)
- [Spark configuration reference](https://spark.apache.org/docs/3.5.0/configuration.html)
- [Spark tuning guide](https://spark.apache.org/docs/3.5.0/tuning.html)
- [Structured Streaming guide](https://spark.apache.org/docs/3.5.0/structured-streaming-programming-guide.html)
- [Delta Lake documentation](https://docs.delta.io/latest/index.html)
- [Apache Iceberg documentation](https://iceberg.apache.org/docs/latest/)
- [Apache Airflow documentation](https://airflow.apache.org/docs/apache-airflow/stable/index.html)
