"""Lab 15: Packaging PySpark applications.

Run it:  ./run.sh labs/15_lab_packaging.py

This lab is different from every lab before it: there is no SparkSession
here. Instead it drives the REAL `bankjobs` package (labs/bankjobs/) three
different ways, exactly how a production job actually gets run, and shows
you the real console output each time.

What you will see:
  1. Why a folder of loose scripts is not a production job
  2. The bankjobs/ package layout, file by file
  3. Running it as a module: python -m bankjobs
  4. What landed on disk
  5. Shipping it with spark-submit --py-files, the real cluster path
  6. Config precedence: an environment variable overriding a default
  7. Running the pytest suite
"""
import os
import subprocess
import sys
import zipfile

# Make `import bank_session` work no matter where you run this from.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from bank_session import step

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LABS_DIR = os.path.join(PROJECT_ROOT, "labs")
PYTHON = sys.executable                                  # this same interpreter, so --py-files matches it

# spark-submit needs SPARK_HOME to find itself. Everything else about the
# environment is exactly what run.sh already gives this process.
RUN_ENV = dict(os.environ, SPARK_HOME=os.path.dirname(__import__("pyspark").__file__))


# ====================================================================
step(1, "Why a folder of loose scripts is not a production job")
# ====================================================================

# This is the exact problem every lab file before this one has: one .py
# file, one concept, easy to read on a projector. Great for teaching, and
# exactly wrong for a job that has to run unattended, get rerun after a
# bug fix, and be provably the same code that passed testing.
problems = {
    "No tests": "a change has no automated way to prove it did not break the numbers",
    "No versioning": "\"which version is running in prod\" has no good answer",
    "No config separation": "\"run this in UAT instead\" means editing the file",
}
for problem, why in problems.items():
    print(f"  {problem}: {why}")


# ====================================================================
step(2, "The bankjobs/ package layout")
# ====================================================================

for root, dirs, files in os.walk(os.path.join(LABS_DIR, "bankjobs")):
    dirs[:] = [d for d in dirs if d != "__pycache__"]    # skip clutter
    for f in sorted(files):
        rel = os.path.relpath(os.path.join(root, f), LABS_DIR)
        print(" ", rel)


# ====================================================================
step(3, "Running it as a module: python -m bankjobs")
# ====================================================================

# Run from PROJECT_ROOT so config.py's dev default ("data/raw") resolves,
# exactly the same rule spark-submit will follow in Step 5.
result = subprocess.run(
    [PYTHON, "-m", "bankjobs", "--job", "daily_kpi", "--env", "dev"],
    cwd=PROJECT_ROOT, env=dict(RUN_ENV, PYTHONPATH=LABS_DIR),
    capture_output=True, text=True, timeout=90,
)
print("exit code:", result.returncode)
for line in result.stdout.strip().splitlines()[-3:]:      # the last few log lines only, not the whole console
    print(" ", line)
assert result.returncode == 0, result.stderr[-2000:]


# ====================================================================
step(4, "What landed on disk")
# ====================================================================

out_dir = os.path.join(PROJECT_ROOT, "data", "warehouse", "gold", "daily_kpi")
parquet_files = [f for f in os.listdir(out_dir) if f.endswith(".parquet")]
print(f"{len(parquet_files)} Parquet file(s) written to data/warehouse/gold/daily_kpi/")
print("(one row per branch per day, exactly what a branch ops team pulls every morning)")


# ====================================================================
step(5, "Shipping it with spark-submit --py-files, the real cluster path")
# ====================================================================

# Zip the package the way you would before handing it to a cluster that
# has never seen this code before.
zip_path = os.path.join(LABS_DIR, "bankjobs.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(os.path.join(LABS_DIR, "bankjobs")):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for f in files:
            full = os.path.join(root, f)
            zf.write(full, os.path.relpath(full, LABS_DIR))
print(f"zipped bankjobs/ -> bankjobs.zip ({os.path.getsize(zip_path):,} bytes)")

spark_submit = os.path.join(os.path.dirname(PYTHON), "spark-submit")
cmd = [
    spark_submit, "--master", "local[2]", "--py-files", "labs/bankjobs.zip",
    "labs/bankjobs/__main__.py", "--job", "daily_kpi", "--env", "dev",
]
print("command:", " ".join(cmd))
result = subprocess.run(cmd, cwd=PROJECT_ROOT, env=RUN_ENV, capture_output=True, text=True, timeout=90)
print("exit code:", result.returncode)
for line in result.stdout.strip().splitlines()[-2:]:
    print(" ", line)
assert result.returncode == 0, result.stderr[-2000:]


# ====================================================================
step(6, "Config precedence: an environment variable overriding a default")
# ====================================================================

# config.py's precedence is: default, then env var, then explicit argument.
# No code change, no --raw-path flag, just one environment variable.
result = subprocess.run(
    [PYTHON, "-m", "bankjobs", "--job", "daily_kpi", "--env", "dev"],
    cwd=PROJECT_ROOT,
    env=dict(RUN_ENV, PYTHONPATH=LABS_DIR, BANKJOBS_SHUFFLE_PARTITIONS="2"),
    capture_output=True, text=True, timeout=90,
)
print("BANKJOBS_SHUFFLE_PARTITIONS=2, exit code:", result.returncode)
print("(config.py never hardcodes this, section 7 of the doc has the precedence rules)")
assert result.returncode == 0


# ====================================================================
step(7, "Running the pytest suite")
# ====================================================================

result = subprocess.run(
    [PYTHON, "-m", "pytest", "tests/", "-q"],
    cwd=PROJECT_ROOT, env=RUN_ENV, capture_output=True, text=True, timeout=90,
)
print(result.stdout.strip().splitlines()[-1])              # the "N passed in Ns" summary line
assert result.returncode == 0, result.stdout[-2000:]

os.remove(zip_path)   # tidy up, this lab can be re-run any number of times

print("\nLab 15 done. bankjobs ran as a module, via spark-submit, and its tests passed.")
