"""Lab 04: Lakehouse, bronze to silver to gold.

Run it:  ./run.sh labs/04_lab_lakehouse.py

This lab WRITES the Parquet warehouse that later labs read. Run it before
any Day 2 or Day 3 lab.

What you will see:
  1. Bronze: land the raw feed as-is, partitioned by ingest date
  2. Quarantine: split bad rows out, never drop them silently
  3. Silver: dedup, clean, join to accounts and branches, one row per txn_id
  4. Gold: business aggregates, one row per branch per day
  5. Reprocess one day only, with dynamic partition overwrite
  6. Reconciliation: counts and sums that must tie between layers
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from bank_session import get_spark, step, RAW, WAREHOUSE

spark = get_spark("lab-04")

# Schemas, reused across steps. Always explicit: inferSchema reads the file twice
# and can guess a different type next month.
TXN_SCHEMA = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()),
    StructField("txn_ts", StringType()), StructField("amount", DoubleType()),
    StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()), StructField("status", StringType()),
    StructField("device_id", StringType()), StructField("city", StringType())])
ACCOUNTS_SCHEMA = StructType([
    StructField("account_id", StringType()), StructField("customer_id", StringType()),
    StructField("account_type", StringType()), StructField("branch_code", StringType()),
    StructField("open_date", StringType()), StructField("acct_status", StringType()),
    StructField("balance", DoubleType()), StructField("acct_currency", StringType())])
BRANCHES_SCHEMA = StructType([
    StructField("branch_code", StringType()), StructField("branch_name", StringType()),
    StructField("city", StringType()), StructField("state", StringType()),
    StructField("region", StringType()), StructField("ifsc", StringType())])


# ====================================================================
step(1, "Bronze: land the raw feed, partitioned by ingest date")
# ====================================================================

# Bronze keeps the feed AS IT ARRIVED: no cleaning, no dedup, no joins. If silver
# logic turns out wrong, we reprocess from bronze, not from the source system.
raw = spark.read.option("header", True).schema(TXN_SCHEMA).csv(f"{RAW}/transactions/*.csv")

# The file name carries the day the batch ARRIVED, e.g. "dt=2026-09-01.csv", so
# that is ingest_date. Bronze partitions by it: a new day is one new partition.
bronze = (raw
    .withColumn("ingest_date", F.regexp_extract(F.input_file_name(), r"dt=(\d{4}-\d{2}-\d{2})", 1))
    .withColumn("ingest_ts", F.current_timestamp()))  # when THIS load ran

bronze.write.mode("overwrite").partitionBy("ingest_date").parquet(f"{WAREHOUSE}/bronze/transactions")
bronze_count = bronze.count()
print("bronze rows:", bronze_count)


# ====================================================================
step(2, "Quarantine: dedup, then split bad rows out")
# ====================================================================

# Exact duplicate txn_id rows are a feed replay, not a quality question, so we
# deduplicate before we even decide good vs bad.
dedup_rank = Window.partitionBy("txn_id").orderBy(F.monotonically_increasing_id())
deduped = (bronze
    .withColumn("rnk", F.row_number().over(dedup_rank))
    .filter("rnk = 1").drop("rnk"))
duplicates_removed = bronze_count - deduped.count()
print("exact duplicate rows removed:", duplicates_removed)

# Clean the two dirty columns this feed is known for.
cleaned = (deduped
    .withColumn("channel", F.upper(F.trim(F.col("channel"))))               # " upi " -> "UPI"
    .withColumn("merchant_category", F.when(F.col("merchant_category") == "", "UNKNOWN")
                                       .otherwise(F.col("merchant_category")))
    .withColumn("posting_date", F.to_date("txn_ts")))                       # business date

# accounts.csv tells us which account_ids are real, and which branch owns each one.
accounts = (spark.read.option("header", True).schema(ACCOUNTS_SCHEMA).csv(f"{RAW}/accounts.csv")
    .select("account_id", "branch_code"))
checked = cleaned.join(accounts, "account_id", "left")   # left join, on purpose: orphans must survive to be caught

# A bad row gets a reason instead of being dropped. bad_reason is null for good rows.
tagged = checked.withColumn("bad_reason",
    F.when(F.col("amount") < 0, "NEGATIVE_AMOUNT")
     .when(F.col("branch_code").isNull(), "ORPHAN_ACCOUNT")   # left join found no matching account
     .otherwise(F.lit(None).cast("string")))
quarantine = tagged.filter(F.col("bad_reason").isNotNull())
# Quarantine is small and read as a whole by an analyst, so it is NOT partitioned.
quarantine.select("txn_id", "account_id", "amount", "posting_date", "bad_reason") \
    .write.mode("overwrite").parquet(f"{WAREHOUSE}/quarantine/transactions")
quarantine_count = quarantine.count()
print("quarantined rows:", quarantine_count, "| reasons:")
quarantine.groupBy("bad_reason").count().show()


# ====================================================================
step(3, "Silver: join to branches, one row per txn_id")
# ====================================================================

branches = spark.read.option("header", True).schema(BRANCHES_SCHEMA).csv(f"{RAW}/branches.csv")

silver = (tagged.filter(F.col("bad_reason").isNull())              # only the good rows reach silver
    .join(F.broadcast(branches), "branch_code")                    # 36 rows: always broadcast, never shuffle
    .select("txn_id", "account_id", "branch_code", "region", "posting_date",
            "amount", "currency", "channel", "merchant_category", "txn_type", "status"))
# Silver partitions by POSTING date, the business date, not the ingest date.
# That is the date analysts and gold aggregates actually filter on.
silver.write.mode("overwrite").partitionBy("posting_date").parquet(f"{WAREHOUSE}/silver/transactions")
silver_count = silver.count()
print("silver rows:", silver_count)


# ====================================================================
step(4, "Gold: one row per branch per day")
# ====================================================================

gold = (silver.groupBy("branch_code", "posting_date")
    .agg(F.count("*").alias("txn_count"),
         # cast to decimal so money prints as 44934702.80, not 4.49347028E7
         F.sum("amount").cast("decimal(18,2)").alias("total_amount"),
         F.sum(F.when(F.col("txn_type") == "DEBIT", F.col("amount")).otherwise(0)).cast("decimal(18,2)").alias("debit_amount"),
         F.sum(F.when(F.col("txn_type") == "CREDIT", F.col("amount")).otherwise(0)).cast("decimal(18,2)").alias("credit_amount")))
# Gold is 36 branches x 3 days, about 100 rows. Partitioning a table that
# small only adds small files with no scan to speed up, so gold has none.
gold.write.mode("overwrite").parquet(f"{WAREHOUSE}/gold/branch_daily")
print("gold rows:", gold.count())
gold.orderBy("posting_date", "branch_code").show(5)


# ====================================================================
step(5, "Reprocess one day only, dynamic partition overwrite")
# ====================================================================

# Corrections arrived for one day. We must fix that day's silver partition
# WITHOUT rewriting the other two days.
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
REDO_DAY = "2026-09-01"
other_days_before = silver.filter(f"posting_date <> '{REDO_DAY}'").count()   # snapshot to compare after
updates = spark.read.option("header", True).schema(TXN_SCHEMA).csv(f"{RAW}/txn_updates.csv") \
    .withColumn("posting_date", F.to_date("txn_ts")).filter(f"posting_date = '{REDO_DAY}'")
day_original = bronze.filter(f"ingest_date = '{REDO_DAY}'")
# Corrections win over the original row for the same txn_id.
priority = day_original.withColumn("src_rank", F.lit(1)) \
    .unionByName(updates.withColumn("src_rank", F.lit(2)), allowMissingColumns=True)
pick = Window.partitionBy("txn_id").orderBy(F.col("src_rank").desc())
redo_clean = (priority.withColumn("rnk", F.row_number().over(pick)).filter("rnk = 1")
    .withColumn("channel", F.upper(F.trim(F.col("channel"))))
    .withColumn("merchant_category", F.when(F.col("merchant_category") == "", "UNKNOWN").otherwise(F.col("merchant_category")))
    .withColumn("posting_date", F.to_date("txn_ts"))
    .filter("amount >= 0")                                          # same quarantine rule, simplified for the demo
    .join(accounts, "account_id").join(F.broadcast(branches), "branch_code")
    .select("txn_id", "account_id", "branch_code", "region", "posting_date",
            "amount", "currency", "channel", "merchant_category", "txn_type", "status"))
# Dynamic mode replaces only the posting_date=2026-09-01 partition. The rest stay untouched.
redo_clean.write.mode("overwrite").partitionBy("posting_date").parquet(f"{WAREHOUSE}/silver/transactions")
after = spark.read.parquet(f"{WAREHOUSE}/silver/transactions")
other_days_after = after.filter(f"posting_date <> '{REDO_DAY}'").count()
redo_day_count = after.filter(f"posting_date = '{REDO_DAY}'").count()
print(f"other two days, row count before: {other_days_before}  after: {other_days_after}  (must match)")
print(f"reprocessed day {REDO_DAY}, new row count: {redo_day_count}")
# One day of silver just changed, so gold, built from silver, is now stale.
# Gold has no partitions, so refreshing it is one full recompute, not 36 small ones.
gold = (after.groupBy("branch_code", "posting_date")
    .agg(F.count("*").alias("txn_count"),
         # cast to decimal so money prints as 44934702.80, not 4.49347028E7
         F.sum("amount").cast("decimal(18,2)").alias("total_amount"),
         F.sum(F.when(F.col("txn_type") == "DEBIT", F.col("amount")).otherwise(0)).cast("decimal(18,2)").alias("debit_amount"),
         F.sum(F.when(F.col("txn_type") == "CREDIT", F.col("amount")).otherwise(0)).cast("decimal(18,2)").alias("credit_amount")))
gold.write.mode("overwrite").parquet(f"{WAREHOUSE}/gold/branch_daily")
print("gold refreshed, rows:", gold.count())


# ====================================================================
step(6, "Reconciliation: numbers that must tie between layers")
# ====================================================================

# Layer 1: bronze in, silver and quarantine out. Nothing should go missing.
check_1 = (bronze_count - duplicates_removed) == (silver_count + quarantine_count)
print(f"bronze - duplicates == silver + quarantine ? "
      f"{bronze_count} - {duplicates_removed} == {silver_count} + {quarantine_count}  -> {check_1}")
# Layer 2: silver in, gold out, both read fresh after the step 5 refresh.
silver_sum = after.agg(F.sum("amount")).first()[0]
gold_sum = gold.agg(F.sum("total_amount")).first()[0]
# gold totals are decimal, silver amounts are double, so compare as floats
check_2 = round(float(silver_sum), 2) == round(float(gold_sum), 2)
print(f"sum(silver.amount) == sum(gold.total_amount) ? {silver_sum:.2f} == {gold_sum:.2f}  -> {check_2}")
check_3 = after.count() == gold.agg(F.sum("txn_count")).first()[0]
print(f"count(silver) == sum(gold.txn_count) ? -> {check_3}")

spark.stop()
print("\nLab 04 done. Wrote bronze/, quarantine/, silver/ and gold/ under data/warehouse/")
