"""Lab 02: Spark architecture.

Run it:  ./run.sh labs/02_lab_architecture.py

Keep the Spark UI open in a browser tab while this runs: http://localhost:4040
Every step below tells you exactly what to look at there.

What you will see:
  1. The session, the driver and the Spark UI
  2. Partitions: the unit of parallel work
  3. Transformations are lazy, actions trigger jobs
  4. Narrow vs wide transformations, and the shuffle
  5. Adaptive Query Execution coalesces shuffle partitions
  6. Caching avoids recomputing the same data
  7. Reading the Spark UI: jobs and stages
"""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from bank_session import get_spark, step, RAW

spark = get_spark("lab-02")   # shuffle_partitions=8, see src/bank_session.py
sc = spark.sparkContext

schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()),
    StructField("txn_ts", StringType()), StructField("amount", DoubleType()),
    StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()), StructField("status", StringType()),
    StructField("device_id", StringType()), StructField("city", StringType())])
df = spark.read.option("header", True).schema(schema).csv(f"{RAW}/transactions/*.csv")


# ====================================================================
step(1, "The session, the driver and the Spark UI")
# ====================================================================

# This Python process IS the driver. It plans the work and asks the executors
# (here: local threads, one per core) to run it. There is no separate cluster.
print("Spark version      :", spark.version)
print("application id      :", sc.applicationId)
print("cores in this run   :", sc.defaultParallelism)     # = local[*], one thread per core
print("Spark UI            :", sc.uiWebUrl)
print("\nOpen http://localhost:4040 now.")
print("Go to the Executors tab. The 'Cores' column should match the number above.")


# ====================================================================
step(2, "Partitions: the unit of parallel work")
# ====================================================================

# A DataFrame is split into partitions. Spark runs one task per partition,
# spread across the cores it has. For a plain file read, partition count
# follows the input files, not any config setting.
print("transactions partitions (3 daily files):", df.rdd.getNumPartitions())

acc_schema = StructType([
    StructField("account_id", StringType()), StructField("customer_id", StringType()),
    StructField("account_type", StringType()), StructField("branch_code", StringType()),
    StructField("open_date", StringType()), StructField("status", StringType()),
    StructField("balance", DoubleType()), StructField("currency", StringType())])
accounts = spark.read.option("header", True).schema(acc_schema).csv(f"{RAW}/accounts.csv")
print("accounts partitions (1 file)           :", accounts.rdd.getNumPartitions())


# ====================================================================
step(3, "Transformations are lazy, actions trigger jobs")
# ====================================================================

# filter() and select() only build a plan. Nothing runs yet, no matter how
# many transformations you chain, so building this plan costs almost no time.
t0 = time.time()
plan = df.filter("status = 'SUCCESS'").select("txn_id", "amount", "channel")
build_time = time.time() - t0

# count() is an ACTION. Only now does Spark actually read the files and run the plan.
t0 = time.time()
row_count = plan.count()
run_time = time.time() - t0
print(f"building the plan took   : {build_time:.4f} s  (nothing ran, just planning)")
print(f"count(), the action, took: {run_time:.4f} s  (this is when files were actually read)")


# ====================================================================
step(4, "Narrow vs wide transformations, and the shuffle")
# ====================================================================

# Narrow: filter() needs only its own partition. No data crosses partitions.
narrow = df.filter("status = 'SUCCESS'")
print("--- narrow plan (filter), look for NO 'Exchange' line ---")
narrow.explain()

# Wide: groupBy() needs every 'UPI' row next to every other 'UPI' row, so
# Spark must shuffle: write, then re-read, partitioned by the group key.
wide = df.groupBy("channel").count()
print("--- wide plan (groupBy), look for the 'Exchange' line ---")
wide.explain()

t0 = time.time()
narrow.count()
narrow_time = time.time() - t0
t0 = time.time()
wide.collect()
wide_time = time.time() - t0
print(f"narrow filter+count took: {narrow_time:.2f} s")
print(f"wide groupBy+collect took: {wide_time:.2f} s  (the shuffle adds real cost)")
print("Open the UI Stages tab: the filter job has 1 stage, the groupBy job has 2,")
print("the extra one is the shuffle re-read after the Exchange.")


# ====================================================================
step(5, "Adaptive Query Execution coalesces shuffle partitions")
# ====================================================================

# The plan above shuffled into 8 partitions (our shuffle_partitions setting).
# But the result is only a handful of channels, so 8 partitions is overkill.
# AQE looks at the actual shuffled data size and merges small partitions.
print("AQE on : result partitions after groupBy :", wide.rdd.getNumPartitions())

spark.conf.set("spark.sql.adaptive.enabled", "false")   # turn AQE off, just for this one comparison
wide_no_aqe = df.groupBy("channel").count()
wide_no_aqe.collect()
print("AQE off: result partitions after groupBy :", wide_no_aqe.rdd.getNumPartitions(), "(stays at 8)")
spark.conf.set("spark.sql.adaptive.enabled", "true")     # back to the default for the rest of the course


# ====================================================================
step(6, "Caching avoids recomputing the same data")
# ====================================================================

expensive = df.withColumn("amt_sq", F.col("amount") * F.col("amount")).filter("amt_sq > 0")

t0 = time.time()
expensive.count()
print("count, no cache, 1st run :", round(time.time() - t0, 2), "s (reads csv, computes amt_sq)")
t0 = time.time()
expensive.count()
print("count, no cache, 2nd run :", round(time.time() - t0, 2), "s (does the SAME work again)")

expensive.cache()
t0 = time.time()
expensive.count()   # this run reads and computes, then stores the result in memory
print("count, cache, 1st run    :", round(time.time() - t0, 2), "s (builds the cache)")
t0 = time.time()
expensive.count()
print("count, cache, 2nd run    :", round(time.time() - t0, 2), "s (reused from memory, no recompute)")


# ====================================================================
step(7, "Reading the Spark UI: jobs and stages")
# ====================================================================

total_jobs = len(sc.statusTracker().getJobIdsForGroup())
print("Open http://localhost:4040 and click the Jobs tab.")
print(f"You should see {total_jobs} completed jobs, one row per action this lab ran (some")
print("actions cost more than one job under the hood, which is normal).")
print("Find a groupBy job. Its Stages count should read 2, matching step 4 above.")
print("Click into a stage: the 'Shuffle Read'/'Shuffle Write' columns are the bytes")
print("that moved between partitions, the cost a wide transformation adds.")

spark.stop()
print("\nLab 02 done. No files written, this lab only reads data/raw/.")
