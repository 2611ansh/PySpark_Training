"""Generate the AtliQ Bank training dataset.

Pure Python. No Spark, no pandas, no network. Runs in about 10 seconds.

    python scripts/00_generate_banking_data.py

Everything the 3-day course uses comes from here, so the data is identical on
every laptop in the room. The seed is fixed, so two people who run it get
byte-identical files and their outputs match.

The data is DELIBERATELY DIRTY in specific, teachable ways:

  * duplicate txn_id rows                 -> dedup with row_number()
  * channel values with mixed case/spaces -> trim + upper in silver
  * null merchant_category                -> COALESCE / fillna
  * a few negative amounts on CREDIT      -> data quality rule
  * orphan account_ids not in accounts    -> left join vs inner join lesson
  * one badly skewed branch               -> salting / AQE demo
  * late-arriving corrections file        -> MERGE / upsert

Nothing here is real. No real customer, account, card or IFSC data is used.
"""

from __future__ import annotations

import csv
import os
import random
from datetime import date, datetime, timedelta
from pathlib import Path

SEED = 42
random.seed(SEED)

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"

# ---------------------------------------------------------------- dimensions
N_CUSTOMERS = 8_000
N_ACCOUNTS = 12_000
N_LOANS = 3_000
N_CARDS = 9_000
TXN_DAYS = 3
TXN_PER_DAY = 60_000
START_DAY = date(2026, 9, 1)

CITIES = [
    # (city, state, region)
    ("Mumbai", "Maharashtra", "West"),
    ("Pune", "Maharashtra", "West"),
    ("Ahmedabad", "Gujarat", "West"),
    ("Delhi", "Delhi", "North"),
    ("Gurugram", "Haryana", "North"),
    ("Jaipur", "Rajasthan", "North"),
    ("Bengaluru", "Karnataka", "South"),
    ("Chennai", "Tamil Nadu", "South"),
    ("Hyderabad", "Telangana", "South"),
    ("Kochi", "Kerala", "South"),
    ("Kolkata", "West Bengal", "East"),
    ("Bhubaneswar", "Odisha", "East"),
]

OCCUPATIONS = ["SALARIED", "SELF_EMPLOYED", "RETIRED", "STUDENT", "HOMEMAKER", "BUSINESS"]
INCOME_BANDS = ["0-3L", "3-6L", "6-12L", "12-25L", "25L+"]
SEGMENTS = ["RETAIL", "PRIORITY", "WEALTH", "NRI"]
ACCOUNT_TYPES = ["SAVINGS", "CURRENT", "SALARY", "NRE"]
CHANNELS = ["UPI", "ATM", "POS", "NEFT", "RTGS", "IMPS", "NETBANKING", "BRANCH"]
MERCHANT_CATS = [
    "GROCERY", "FUEL", "TRAVEL", "ECOMMERCE", "UTILITIES", "RESTAURANT",
    "HEALTHCARE", "EDUCATION", "INSURANCE", "JEWELLERY", "ELECTRONICS",
]
LOAN_PRODUCTS = ["HOME", "AUTO", "PERSONAL", "EDUCATION", "GOLD"]
CARD_NETWORKS = ["RUPAY", "VISA", "MASTERCARD"]
FRAUD_TYPES = ["CARD_NOT_PRESENT", "ACCOUNT_TAKEOVER", "MULE_ACCOUNT", "SKIMMING", "PHISHING"]

FIRST = ["Aarav", "Vivaan", "Aditya", "Diya", "Ananya", "Ishaan", "Kabir", "Meera",
         "Riya", "Rohan", "Saanvi", "Arjun", "Neha", "Kiran", "Priya", "Rahul",
         "Sneha", "Vikram", "Anjali", "Manish", "Pooja", "Sanjay", "Divya", "Nikhil"]
LAST = ["Sharma", "Verma", "Iyer", "Nair", "Reddy", "Patel", "Singh", "Gupta",
        "Bose", "Mehta", "Rao", "Joshi", "Kulkarni", "Desai", "Chatterjee", "Menon"]


def write_csv(path: Path, header: list[str], rows: list[list]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)
    print(f"  {path.relative_to(ROOT)}  ({len(rows):,} rows)")


def rand_date(start: date, end: date) -> date:
    return start + timedelta(days=random.randint(0, (end - start).days))


# ================================================================== BRANCHES
def gen_branches() -> list[list]:
    rows = []
    for i, (city, state, region) in enumerate(CITIES, start=1):
        for b in range(1, 4):                       # 3 branches per city = 36
            code = f"BR{i:02d}{b}"
            rows.append([
                code,
                f"{city} {['Main','North','South'][b-1]} Branch",
                city, state, region,
                f"ATLQ0{i:03d}{b:02d}",
            ])
    write_csv(RAW / "branches.csv",
              ["branch_code", "branch_name", "city", "state", "region", "ifsc"], rows)
    return rows


# ================================================================= CUSTOMERS
def gen_customers() -> list[list]:
    rows = []
    for i in range(N_CUSTOMERS):
        city, state, _ = random.choice(CITIES)
        rows.append([
            f"CUST{100000+i}",
            f"{random.choice(FIRST)} {random.choice(LAST)}",
            random.randint(1955, 2004),                       # dob_year only
            city, state,
            random.choice(OCCUPATIONS),
            random.choice(INCOME_BANDS),
            random.choices(["VERIFIED", "PENDING", "REJECTED"], [0.88, 0.10, 0.02])[0],
            random.choices(["LOW", "MEDIUM", "HIGH"], [0.7, 0.25, 0.05])[0],
            rand_date(date(2015, 1, 1), date(2026, 6, 30)).isoformat(),
            random.choices(SEGMENTS, [0.72, 0.15, 0.08, 0.05])[0],
        ])
    write_csv(RAW / "customers.csv",
              ["customer_id", "full_name", "dob_year", "city", "state", "occupation",
               "income_band", "kyc_status", "risk_rating", "onboarded_date", "segment"], rows)
    return rows


# ================================================================== ACCOUNTS
def gen_accounts(customers: list[list], branches: list[list]) -> list[list]:
    rows = []
    cust_ids = [c[0] for c in customers]
    # ONE branch gets a huge share of accounts on purpose -> skew demo
    hot_branch = branches[0][0]
    for i in range(N_ACCOUNTS):
        cid = random.choice(cust_ids)
        branch = hot_branch if random.random() < 0.22 else random.choice(branches)[0]
        rows.append([
            f"ACC{9000000+i}",
            cid,
            random.choices(ACCOUNT_TYPES, [0.55, 0.20, 0.20, 0.05])[0],
            branch,
            rand_date(date(2015, 1, 1), date(2026, 6, 30)).isoformat(),
            random.choices(["ACTIVE", "DORMANT", "CLOSED"], [0.9, 0.08, 0.02])[0],
            round(random.lognormvariate(10.5, 1.1), 2),
            "INR",
        ])
    write_csv(RAW / "accounts.csv",
              ["account_id", "customer_id", "account_type", "branch_code",
               "open_date", "status", "balance", "currency"], rows)
    return rows


# ===================================================================== LOANS
def gen_loans(customers: list[list]) -> None:
    rows = []
    cust_ids = [c[0] for c in customers]
    for i in range(N_LOANS):
        product = random.choices(LOAN_PRODUCTS, [0.25, 0.2, 0.3, 0.15, 0.1])[0]
        principal = {"HOME": 4_500_000, "AUTO": 900_000, "PERSONAL": 500_000,
                     "EDUCATION": 1_200_000, "GOLD": 250_000}[product]
        principal = round(principal * random.uniform(0.4, 1.6), 2)
        tenure = {"HOME": 240, "AUTO": 60, "PERSONAL": 48,
                  "EDUCATION": 84, "GOLD": 24}[product]
        rate = round(random.uniform(7.5, 16.5), 2)
        r = rate / 1200
        emi = round(principal * r * (1 + r) ** tenure / ((1 + r) ** tenure - 1), 2)
        dpd = random.choices([0, 15, 35, 65, 95], [0.82, 0.08, 0.05, 0.03, 0.02])[0]
        rows.append([
            f"LN{500000+i}", random.choice(cust_ids), product, principal, rate,
            tenure, emi,
            rand_date(date(2019, 1, 1), date(2026, 6, 30)).isoformat(),
            round(principal * random.uniform(0.1, 0.98), 2),
            dpd,
            "CLOSED" if random.random() < 0.08 else "ACTIVE",
        ])
    write_csv(RAW / "loans.csv",
              ["loan_id", "customer_id", "product", "principal", "interest_rate",
               "tenure_months", "emi", "disbursed_date", "outstanding", "dpd", "status"], rows)


# ===================================================================== CARDS
def gen_cards(accounts: list[list]) -> None:
    rows = []
    for i in range(N_CARDS):
        acc = random.choice(accounts)
        issue = rand_date(date(2020, 1, 1), date(2026, 6, 30))
        rows.append([
            f"CARD{700000+i}", acc[1], acc[0],
            random.choices(["DEBIT", "CREDIT"], [0.7, 0.3])[0],
            random.choice(CARD_NETWORKS),
            issue.isoformat(),
            (issue + timedelta(days=365 * 5)).isoformat(),
            random.choices(["ACTIVE", "BLOCKED", "EXPIRED"], [0.93, 0.04, 0.03])[0],
            random.choice([50_000, 100_000, 200_000, 500_000, 1_000_000]),
        ])
    write_csv(RAW / "cards.csv",
              ["card_id", "customer_id", "account_id", "card_type", "network",
               "issue_date", "expiry_date", "status", "credit_limit"], rows)


# ============================================================== FOREX RATES
def gen_forex() -> None:
    rows = [["INR", 1.0], ["USD", 83.25], ["EUR", 90.40], ["GBP", 105.80],
            ["AED", 22.67], ["SGD", 61.90]]
    write_csv(RAW / "forex_rates.csv", ["currency", "inr_rate"], rows)


# ============================================================== TRANSACTIONS
def gen_transactions(accounts: list[list]) -> list[list]:
    """Returns the flat list of all txn rows so fraud + graph can reuse them."""
    acc_ids = [a[0] for a in accounts]
    all_rows: list[list] = []
    txn_counter = 0

    for d in range(TXN_DAYS):
        day = START_DAY + timedelta(days=d)
        rows = []
        for _ in range(TXN_PER_DAY):
            txn_counter += 1
            acc = random.choice(acc_ids)

            # 0.5% orphan accounts -> not present in accounts.csv
            if random.random() < 0.005:
                acc = f"ACC{random.randint(1, 999999)}"

            channel = random.choices(
                CHANNELS, [0.42, 0.10, 0.18, 0.08, 0.02, 0.09, 0.09, 0.02])[0]
            # dirty on purpose: mixed case and padding
            if random.random() < 0.06:
                channel = f" {channel.lower()} "

            txn_type = random.choices(["DEBIT", "CREDIT"], [0.72, 0.28])[0]
            amount = round(random.lognormvariate(6.6, 1.35), 2)
            if channel.strip().upper() == "RTGS":
                amount = round(amount * 40, 2)           # RTGS is high value
            # a handful of bad rows
            if random.random() < 0.002:
                amount = -amount

            cat = random.choice(MERCHANT_CATS)
            if random.random() < 0.07:
                cat = ""                                  # null merchant_category

            hour = random.choices(range(24),
                                  [1, 1, 1, 1, 1, 2, 4, 6, 8, 9, 9, 8,
                                   7, 7, 8, 8, 9, 10, 11, 10, 8, 6, 4, 2])[0]
            ts = datetime(day.year, day.month, day.day, hour,
                          random.randint(0, 59), random.randint(0, 59))
            city, _, _ = random.choice(CITIES)

            rows.append([
                f"TXN{8000000+txn_counter}", acc, ts.strftime("%Y-%m-%d %H:%M:%S"),
                amount, "INR", channel, cat, txn_type,
                random.choice(acc_ids) if random.random() < 0.55 else "",
                random.choices(["SUCCESS", "FAILED", "PENDING"], [0.95, 0.04, 0.01])[0],
                f"DEV{random.randint(10000, 99999)}", city,
            ])

        # duplicates: replay 0.4% of the day's rows verbatim
        dupes = random.sample(rows, int(len(rows) * 0.004))
        rows.extend(dupes)
        random.shuffle(rows)

        write_csv(RAW / "transactions" / f"dt={day.isoformat()}.csv",
                  ["txn_id", "account_id", "txn_ts", "amount", "currency", "channel",
                   "merchant_category", "txn_type", "counterparty_account", "status",
                   "device_id", "city"], rows)
        all_rows.extend(rows)

    return all_rows


# ======================================================= LATE CORRECTIONS
def gen_txn_updates(all_txns: list[list]) -> None:
    """Corrections that arrive the next morning. Used for MERGE / upsert."""
    sample = random.sample(all_txns, 4_000)
    rows = []
    for r in sample[:3_000]:                       # 3,000 updates to existing rows
        r = list(r)
        r[9] = random.choice(["SUCCESS", "REVERSED"])
        rows.append(r)
    # 1,000 brand new rows that were missed in the original feed
    for i in range(1_000):
        base = list(random.choice(all_txns))
        base[0] = f"TXN{9900000+i}"
        rows.append(base)
    random.shuffle(rows)
    write_csv(RAW / "txn_updates.csv",
              ["txn_id", "account_id", "txn_ts", "amount", "currency", "channel",
               "merchant_category", "txn_type", "counterparty_account", "status",
               "device_id", "city"], rows)


# =============================================================== FRAUD LABELS
def gen_fraud(all_txns: list[list]) -> None:
    rows = []
    for r in all_txns:
        if r[0].startswith("TXN99"):
            continue
        amt = float(r[3])
        ch = r[5].strip().upper()
        # base rate ~0.4%, higher for big-ticket card-not-present style txns
        p = 0.003
        if amt > 50_000 and ch in ("POS", "NETBANKING", "IMPS"):
            p = 0.06
        if random.random() < p:
            rows.append([
                r[0], 1,
                r[2][:10],
                random.choice(FRAUD_TYPES),
            ])
    write_csv(RAW / "fraud_labels.csv",
              ["txn_id", "is_fraud", "reported_date", "fraud_type"], rows)


# ==================================================================== STREAM
def gen_stream_seed(all_txns: list[list]) -> None:
    """Small files a script drops one by one into data/stream_in/ for
    Structured Streaming. Only the seed pool is written here."""
    pool = random.sample(all_txns, 12_000)
    write_csv(RAW / "stream_pool.csv",
              ["txn_id", "account_id", "txn_ts", "amount", "currency", "channel",
               "merchant_category", "txn_type", "counterparty_account", "status",
               "device_id", "city"], pool)
    (ROOT / "data" / "stream_in").mkdir(parents=True, exist_ok=True)
    (ROOT / "data" / "stream_ckpt").mkdir(parents=True, exist_ok=True)


# ====================================================================== MAIN
def main() -> None:
    print(f"Generating AtliQ Bank dataset into {RAW}\n")
    branches = gen_branches()
    customers = gen_customers()
    accounts = gen_accounts(customers, branches)
    gen_loans(customers)
    gen_cards(accounts)
    gen_forex()
    txns = gen_transactions(accounts)
    gen_txn_updates(txns)
    gen_fraud(txns)
    gen_stream_seed(txns)

    total_mb = sum(f.stat().st_size for f in RAW.rglob("*.csv")) / 1024 / 1024
    print(f"\nDone. {len(txns):,} transaction rows, {total_mb:.1f} MB on disk.")
    print("Next:  python scripts/day1/01_first_dataframe.py")


if __name__ == "__main__":
    main()
