"""Lab 05: Data models for a lakehouse.

Run it:  ./run.sh labs/05_lab_data_models.py

What you will see:
  1. The grain of the transaction fact, and the star schema around it
  2. The three fact types, named, on real banking tables
  3. dim_customer: the initial SCD Type 2 load
  4. A changed extract lands: segment and risk_rating move for some customers
  5. Detecting NEW, CHANGED and UNCHANGED customers by hashing tracked columns
  6. Applying the SCD2 merge: expire, insert, keep
  7. Proving it: the same customer_id now has two versions with real dates
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

from bank_session import get_spark, step, RAW, WAREHOUSE

spark = get_spark("lab-05")

TODAY = "2026-09-14"    # the date we pretend this load runs on
LOAD_1 = "2026-01-01"   # the date the very first load ran on


# ====================================================================
step(1, "The grain, and the star schema around it")
# ====================================================================

# The grain is the one sentence every table in a warehouse must be able to
# answer: "what does one row mean?" Get it wrong and every join downstream
# double-counts or drops rows.
print("fact_transactions grain : one row per txn_id")
print("fact_branch_daily grain : one row per branch_code per posting_date")
print("fact_loan grain         : one row per loan_id, updated as it moves")

# A star schema puts one wide fact table in the middle, with narrow
# dimensions around it that the fact only holds a key for.
print("""
                 dim_customer
                      |
   dim_branch --- fact_transactions --- dim_date
                      |
                 dim_account
""")


# ====================================================================
step(2, "The three fact types, named, on real banking tables")
# ====================================================================

# TYPE 1: transaction fact. One row per event. Never updated, only appended.
# fact_transactions in this course is exactly this: one row per txn_id.
print("Type 1, TRANSACTION FACT: fact_transactions, one row per txn_id, append-only")

# TYPE 2: periodic snapshot. One row per (dimension, time bucket), even if
# nothing happened that day. Lab 04's gold table is a real one: one row per
# branch per day, always 36 rows a day whether the branch was busy or not.
gold_path = f"{WAREHOUSE}/gold/branch_daily"
if os.path.isdir(gold_path):
    snapshot = spark.read.parquet(gold_path)
    print("Type 2, PERIODIC SNAPSHOT: gold/branch_daily from Lab 04")
else:
    # Lab 04 has not run yet. Build three rows by hand so the idea still shows.
    print("NOTE: data/warehouse/gold/branch_daily not found. Run labs/04_lab_lakehouse.py "
          "first for the real table. Using 3 sample rows here instead.")
    snapshot = spark.createDataFrame(
        [("BR011", "2026-09-01", 412, 981000.50), ("BR011", "2026-09-02", 398, 875220.10),
         ("BR021", "2026-09-01", 120, 240500.00)],
        ["branch_code", "posting_date", "txn_count", "total_amount"])
snapshot.orderBy("posting_date", "branch_code").show(5)

# TYPE 3: accumulating snapshot. One row per case, with several milestone
# columns that fill in and change as the case moves. loans.csv is a real
# one: each loan gets one row that tracks outstanding and dpd over its life.
loan_schema = StructType([
    StructField("loan_id", StringType()), StructField("customer_id", StringType()),
    StructField("product", StringType()), StructField("principal", StringType()),
    StructField("interest_rate", StringType()), StructField("tenure_months", StringType()),
    StructField("emi", StringType()), StructField("disbursed_date", StringType()),
    StructField("outstanding", StringType()), StructField("dpd", IntegerType()),
    StructField("status", StringType())])
loans = spark.read.option("header", True).schema(loan_schema).csv(f"{RAW}/loans.csv")
print("Type 3, ACCUMULATING SNAPSHOT: one loan_id, outstanding and dpd change every month")
loans.select("loan_id", "disbursed_date", "outstanding", "dpd", "status").show(5)


# ====================================================================
step(3, "dim_customer: the initial SCD Type 2 load")
# ====================================================================

# These four columns are the ones the bank actually cares about tracking
# history for. A name typo is not worth a new dimension row; a segment
# upgrade is, because pricing and offers depend on it.
TRACKED = ["segment", "risk_rating", "kyc_status", "income_band"]

customer_schema = StructType([
    StructField("customer_id", StringType()), StructField("full_name", StringType()),
    StructField("dob_year", IntegerType()), StructField("city", StringType()),
    StructField("state", StringType()), StructField("occupation", StringType()),
    StructField("income_band", StringType()), StructField("kyc_status", StringType()),
    StructField("risk_rating", StringType()), StructField("onboarded_date", StringType()),
    StructField("segment", StringType())])
customers = spark.read.option("header", True).schema(customer_schema).csv(f"{RAW}/customers.csv")

# row_hash is a fingerprint of the tracked columns. Two rows with the same
# hash are, for SCD2 purposes, the same version of the customer.
dim_customer = (customers
    .withColumn("row_hash", F.sha2(F.concat_ws("|", *TRACKED), 256))
    .withColumn("surrogate_key", F.monotonically_increasing_id())  # a new key per VERSION, not per customer
    .withColumn("effective_from", F.lit(LOAD_1))                   # when this version became true
    .withColumn("effective_to", F.lit(None).cast(StringType()))    # NULL = still current
    .withColumn("is_current", F.lit(True)))
print("dim_customer, initial load, rows:", dim_customer.count())


# ====================================================================
step(4, "A changed extract lands")
# ====================================================================

# Simulate today's file from the source system: some customers moved
# segment or risk band. random seeds make this the same on every run.
extract = (customers
    .withColumn("segment", F.when(F.rand(42) < 0.05, "PRIORITY").otherwise(F.col("segment")))
    .withColumn("risk_rating", F.when(F.rand(43) < 0.03, "HIGH").otherwise(F.col("risk_rating")))
    .withColumn("row_hash", F.sha2(F.concat_ws("|", *TRACKED), 256)))
print("today's extract, rows:", extract.count())


# ====================================================================
step(5, "Detect NEW, CHANGED and UNCHANGED by comparing hashes")
# ====================================================================

current = dim_customer.filter("is_current")   # only compare against the live version
compared = extract.alias("e").join(current.alias("c"), "customer_id", "left")

new_customers = compared.filter(F.col("c.customer_id").isNull())
changed_customers = compared.filter(
    F.col("c.customer_id").isNotNull() & (F.col("e.row_hash") != F.col("c.row_hash")))
unchanged_count = compared.filter(
    F.col("c.customer_id").isNotNull() & (F.col("e.row_hash") == F.col("c.row_hash"))).count()

print("new customers    :", new_customers.count())
print("changed customers:", changed_customers.count())
print("unchanged         :", unchanged_count)


# ====================================================================
step(6, "Apply the merge: expire, insert, keep")
# ====================================================================

changed_ids = changed_customers.select("customer_id")

# CASE 1: rows that changed today. Close out the old version.
expired = (current.join(changed_ids, "customer_id")
    .withColumn("effective_to", F.lit(TODAY))
    .withColumn("is_current", F.lit(False)))

# CASE 2: new versions for changed customers, plus brand new customers.
new_versions = (changed_customers.select("e.*")
    .unionByName(new_customers.select("e.*"))
    .withColumn("surrogate_key", F.monotonically_increasing_id() + 1_000_000)  # keep keys away from load 1's
    .withColumn("effective_from", F.lit(TODAY))
    .withColumn("effective_to", F.lit(None).cast(StringType()))
    .withColumn("is_current", F.lit(True)))

# CASE 3: everyone else. Left untouched, this run does not concern them.
untouched = current.join(changed_ids, "customer_id", "left_anti")

dim_customer_v2 = untouched.unionByName(expired).unionByName(new_versions)
dim_customer_v2.write.mode("overwrite").parquet(f"{WAREHOUSE}/dim_customer")
print(f"dim_customer, rows before: {dim_customer.count()}  after: {dim_customer_v2.count()}")
print(f"  expired: {expired.count()}  new versions: {new_versions.count()}  untouched: {untouched.count()}")


# ====================================================================
step(7, "Prove it: one customer, two versions")
# ====================================================================

# Pick the first customer_id that actually changed and show both rows.
sample_id = changed_customers.select("customer_id").first()[0]
history = (dim_customer_v2.filter(F.col("customer_id") == sample_id)
    .select("customer_id", "segment", "risk_rating", "effective_from", "effective_to", "is_current")
    .orderBy("effective_from"))
print(f"history for {sample_id}:")
history.show(truncate=False)

spark.stop()
print("\nLab 05 done. Output written to data/warehouse/dim_customer/")
