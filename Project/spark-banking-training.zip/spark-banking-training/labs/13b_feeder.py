"""Feeder for Lab 13: drips rows from data/raw/stream_pool.csv into
data/stream_in/ one small CSV file at a time, simulating a live feed.

Not run by hand normally, 13_lab_streaming.py starts this as a background
process and stops it when the demo ends. Pure Python, no Spark, so it starts
in well under a second.

Each file is written to a hidden temp name in the SAME folder, then renamed
into place, so the streaming reader in Lab 13 never sees a half-written
file, the same trick a real ingestion pipeline uses.

Run standalone if you want to watch it alone:
    ./run.sh labs/13b_feeder.py --seconds 30
"""
import argparse
import csv
import os
import sys
import time
import uuid

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from bank_session import RAW, STREAM_IN

HEADER = ["txn_id", "account_id", "txn_ts", "amount", "currency", "channel",
          "merchant_category", "txn_type", "counterparty_account", "status",
          "device_id", "city"]

parser = argparse.ArgumentParser()
parser.add_argument("--seconds", type=float, default=30)     # stop dripping after this long
parser.add_argument("--batch-size", type=int, default=150)   # rows per file
parser.add_argument("--interval", type=float, default=1.0)   # seconds between files
args = parser.parse_args()

os.makedirs(STREAM_IN, exist_ok=True)

# Load the whole pool once, pure Python csv, no Spark needed for this part.
with open(os.path.join(RAW, "stream_pool.csv"), newline="", encoding="utf-8") as f:
    reader = csv.reader(f)
    next(reader)                                    # skip the header row
    pool_rows = list(reader)

print(f"[feeder] {len(pool_rows):,} rows loaded, dripping {args.batch_size} rows "
      f"every {args.interval}s for up to {args.seconds}s", flush=True)

start = time.time()
offset = 0
files_written = 0
while time.time() - start < args.seconds and offset < len(pool_rows):
    batch = pool_rows[offset: offset + args.batch_size]
    offset += args.batch_size
    if not batch:
        break
    name = f"part-{files_written:04d}-{uuid.uuid4().hex[:8]}.csv"
    tmp_path = os.path.join(STREAM_IN, f".{name}.tmp")
    final_path = os.path.join(STREAM_IN, name)
    with open(tmp_path, "w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        writer.writerow(HEADER)
        writer.writerows(batch)
    os.rename(tmp_path, final_path)                 # atomic within the same folder
    files_written += 1
    time.sleep(args.interval)

print(f"[feeder] done: wrote {files_written} files, {min(offset, len(pool_rows)):,} rows, "
      f"in {time.time() - start:.1f}s", flush=True)
