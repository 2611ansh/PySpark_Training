"""Lab 10: Window functions.

Run it:  ./run.sh labs/10_lab_windows.py

What you will see:
  1. A window spec and its frame: ROWS vs RANGE, on tied values
  2. The default frame trap: adding ORDER BY silently changes the frame
  3. Deduplicating the duplicate txn_id rows with row_number()
  4. Running account balance
  5. Velocity check: transactions per account in the last 10 minutes
  6. One more case: reactivation after a dormancy gap, with lag()
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import Window
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType

from bank_session import get_spark, step, RAW

spark = get_spark("lab-10")

# TimestampType here, not StringType: every step in this lab orders or
# measures time gaps, so txn_ts needs to be a real timestamp, not text.
txn_schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()), StructField("txn_ts", TimestampType()),
    StructField("amount", DoubleType()), StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()), StructField("counterparty_account", StringType()),
    StructField("status", StringType()), StructField("device_id", StringType()), StructField("city", StringType())])
# Read RAW, not silver: silver is already deduplicated, and step 3 needs
# the duplicate txn_id rows still in there to dedup them ourselves.
txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/*.csv")


# ====================================================================
step(1, "A window spec and its frame: ROWS vs RANGE, on tied values")
# ====================================================================

# A window spec is PARTITION BY (which rows see each other) + ORDER BY
# (what order) + a FRAME (how far back and forward from the current row).
sample = spark.createDataFrame([("A", 100), ("A", 100), ("A", 200), ("A", 300)], ["account_id", "amount"])
w_rows = Window.partitionBy("account_id").orderBy("amount").rowsBetween(Window.unboundedPreceding, Window.currentRow)
w_range = Window.partitionBy("account_id").orderBy("amount").rangeBetween(Window.unboundedPreceding, Window.currentRow)
# ROWS counts PHYSICAL rows up to this one. RANGE counts every row whose
# ORDER BY VALUE is <= this one, so tied values (100, 100) both get the
# same, larger total under RANGE.
(sample.withColumn("sum_rows", F.sum("amount").over(w_rows))
       .withColumn("sum_range", F.sum("amount").over(w_range))
       .show())


# ====================================================================
step(2, "The default frame trap: ORDER BY silently changes the frame")
# ====================================================================

# With NO ORDER BY, the default frame is the WHOLE partition: avg_all is
# the same for every row of an account, as you would expect from avg().
w_no_order = Window.partitionBy("account_id")
# The moment you ADD an ORDER BY, for example just to make ties stable,
# the default frame silently becomes RANGE UNBOUNDED PRECEDING TO CURRENT
# ROW. avg() quietly turns into a RUNNING average, not the account's average.
w_with_order = Window.partitionBy("account_id").orderBy("txn_ts")
one_account = txns.filter("account_id = 'ACC9000000'")
(one_account.withColumn("avg_all", F.round(F.avg("amount").over(w_no_order), 2))
            .withColumn("avg_running_TRAP", F.round(F.avg("amount").over(w_with_order), 2))
            .select("txn_ts", "amount", "avg_all", "avg_running_TRAP")
            .orderBy("txn_ts").show(5))
print("Fix: be explicit. Add .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)")


# ====================================================================
step(3, "Deduplicating the duplicate txn_id rows with row_number()")
# ====================================================================

before = txns.count()
dedup_window = Window.partitionBy("txn_id").orderBy(F.monotonically_increasing_id())
deduped = (txns.withColumn("rn", F.row_number().over(dedup_window))
    .filter("rn = 1").drop("rn").cache())
print(f"rows before: {before:,}  after dedup: {deduped.count():,}  duplicates removed: {before - deduped.count():,}")


# ====================================================================
step(4, "Running account balance")
# ====================================================================

# CREDIT adds to the balance, DEBIT subtracts. Order by time, run the sum
# from the start of the account's history up to and including this row.
w_balance = Window.partitionBy("account_id").orderBy("txn_ts").rowsBetween(Window.unboundedPreceding, Window.currentRow)
signed = deduped.withColumn("signed_amount",
    F.when(F.col("txn_type") == "CREDIT", F.col("amount")).otherwise(-F.col("amount")))
balances = signed.withColumn("running_balance", F.round(F.sum("signed_amount").over(w_balance), 2))
balances.filter("account_id = 'ACC9000000'") \
    .select("txn_ts", "txn_type", "amount", "running_balance").orderBy("txn_ts").show(5)


# ====================================================================
step(5, "Velocity check: transactions per account in the last 10 minutes")
# ====================================================================

# RANGE with a number of SECONDS as the frame bound: "600 seconds before
# this row's timestamp, up to this row" is a real trailing time window,
# unlike ROWS, which would count a fixed number of ROWS regardless of gaps.
w_velocity = (Window.partitionBy("account_id").orderBy("txn_epoch").rangeBetween(-600, 0))
velocity = (deduped.withColumn("txn_epoch", F.col("txn_ts").cast("long"))
    .withColumn("txns_last_10min", F.count("*").over(w_velocity)))
alerts = velocity.filter("txns_last_10min >= 3")     # 3 or more transactions inside 10 minutes
print("accounts with a velocity alert:", alerts.select("account_id").distinct().count())
alerts.select("account_id", "txn_ts", "channel", "txns_last_10min").orderBy(F.desc("txns_last_10min")).show(5)


# ====================================================================
step(6, "One more case: reactivation after a dormancy gap")
# ====================================================================

# lag() looks at THIS account's previous transaction, in time order. The
# gap since then is a real signal: a large one means the account just came
# back to life, which some banks treat as worth a second look.
w_account_time = Window.partitionBy("account_id").orderBy("txn_ts")
gaps = deduped.withColumn("prev_txn_ts", F.lag("txn_ts").over(w_account_time)) \
    .withColumn("gap_hours", F.round(
        (F.col("txn_ts").cast("long") - F.col("prev_txn_ts").cast("long")) / 3600, 1))
reactivations = gaps.filter("gap_hours > 24")        # silent for a full day, then active again
print("reactivation events (gap over 24 hours):", reactivations.count())
reactivations.select("account_id", "prev_txn_ts", "txn_ts", "gap_hours") \
    .orderBy(F.desc("gap_hours")).show(5)

spark.stop()
print("\nLab 10 done. No files written, this lab is analysis only.")
