"""Lab 06: RDDs and UDFs.

Run it:  ./run.sh labs/06_lab_rdd_udf.py

What you will see:
  1. What an RDD is: parallelize, map, filter, and a DataFrame's own .rdd
  2. reduceByKey vs groupByKey, with the shuffle bytes each one really moved
  3. The recurring example: a risk score, defined once
  4. Preference 1: a built-in function
  5. Preference 2: expr()
  6. Preference 3: a pandas UDF
  7. Preference 4, last resort: a plain Python UDF, then all four, timed
"""
import json
import os
import sys
import time
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pandas as pd
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from bank_session import get_spark, step, RAW

spark = get_spark("lab-06")
sc = spark.sparkContext


# ====================================================================
step(1, "What an RDD is")
# ====================================================================

# An RDD is a distributed list of Python objects, no columns, no types. A
# DataFrame is built on top of RDDs, but you rarely touch one directly,
# because DataFrames are optimised by Spark's planner and RDDs are not.
numbers = sc.parallelize(range(1, 11), 4)          # 10 numbers, spread over 4 partitions
evens = numbers.filter(lambda n: n % 2 == 0)        # keep even numbers
squared = evens.map(lambda n: n * n)                # square each one
print("squares of evens:", squared.collect())       # .collect() pulls everything to the driver

# Every DataFrame has one underneath. df.rdd gives you Python Row objects,
# which is why it is slow: Spark leaves its fast columnar format to box
# every row as a Python object.
sample_df = spark.range(5).withColumn("sq", F.col("id") * F.col("id"))
print("same thing via df.rdd:", sample_df.rdd.map(lambda row: row["sq"]).collect())

# When you still reach for an RDD: a format that is not rows and columns,
# for example a fixed-width mainframe extract, one field per character
# range. There is no DataFrame reader for that.
mainframe_line = "AC100234SAVINGS   00125000"                    # account, type, balance, no delimiters
account_id, balance = mainframe_line[0:8], int(mainframe_line[18:]) / 100
print(f"parsed mainframe line: account={account_id} balance={balance}")


# ====================================================================
step(2, "reduceByKey vs groupByKey, with real shuffle bytes")
# ====================================================================

# Read the raw feed as plain text, the way an RDD program would.
lines = sc.textFile(f"{RAW}/transactions/*.csv")
rows = lines.filter(lambda l: not l.startswith("txn_id"))          # drop the header from every file
pairs = rows.map(lambda l: l.split(","))                           # naive split, this feed has no embedded commas
account_amount = pairs.map(lambda f: (f[1], float(f[3])))          # (account_id, amount)
account_amount.cache()
account_amount.count()                                              # force the cache to fill, outside the timing

ui, app_id = sc.uiWebUrl, sc.applicationId                          # Spark's own UI, this run's application

# reduceByKey: each partition sums its own keys FIRST, so only one number
# per key per partition crosses the network.
after = json.load(urllib.request.urlopen(f"{ui}/api/v1/applications/{app_id}/stages"))
before_max = max((s["stageId"] for s in after), default=-1)
t0 = time.time()
reduced = account_amount.reduceByKey(lambda a, b: a + b).collect()
reduce_secs = time.time() - t0
after = json.load(urllib.request.urlopen(f"{ui}/api/v1/applications/{app_id}/stages"))
reduce_shuffle = sum(s.get("shuffleWriteBytes", 0) for s in after if s["stageId"] > before_max)

# groupByKey: every row for a key crosses the network first, summed after.
before_max = max((s["stageId"] for s in after), default=-1)
t0 = time.time()
grouped = account_amount.groupByKey().mapValues(sum).collect()
group_secs = time.time() - t0
after2 = json.load(urllib.request.urlopen(f"{ui}/api/v1/applications/{app_id}/stages"))
group_shuffle = sum(s.get("shuffleWriteBytes", 0) for s in after2 if s["stageId"] > before_max)

print(f"{'method':<14}{'seconds':>10}{'shuffle bytes':>16}")
print(f"{'reduceByKey':<14}{reduce_secs:>10.2f}{reduce_shuffle:>16,}")
print(f"{'groupByKey':<14}{group_secs:>10.2f}{group_shuffle:>16,}")
# Round before comparing: the two methods add the same numbers in a different
# order, so the last few decimal places of a float total can differ.
same_totals = sorted((k, round(v, 2)) for k, v in reduced) == sorted((k, round(v, 2)) for k, v in grouped)
print("same totals (rounded to paise)?", same_totals)


# ====================================================================
step(3, "The recurring example: a risk score, defined once")
# ====================================================================

# One rule, written four ways in the next four steps:
#   amount > 50000 AND channel in (POS, NETBANKING, IMPS)  ->  HIGH, else LOW
txn_schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()), StructField("txn_ts", StringType()),
    StructField("amount", DoubleType()), StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()), StructField("counterparty_account", StringType()),
    StructField("status", StringType()), StructField("device_id", StringType()), StructField("city", StringType())])
txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/*.csv")
txns = txns.withColumn("channel", F.upper(F.trim(F.col("channel")))).cache()
txns.count()                                                        # force the cache to fill, outside the timing
HIGH_RISK_CHANNELS = ["POS", "NETBANKING", "IMPS"]


# ====================================================================
step(4, "Preference 1: a built-in function")
# ====================================================================

# Always try this first. Built-ins run inside the JVM in Spark's own
# columnar format: no serialising, no leaving the JVM, no per-row cost.
t0 = time.time()
n1 = txns.withColumn("risk", F.when(
        (F.col("amount") > 50000) & F.col("channel").isin(HIGH_RISK_CHANNELS), "HIGH")
        .otherwise("LOW")).count()
builtin_secs = time.time() - t0
print(f"built-in: {n1:,} rows in {builtin_secs:.2f}s")


# ====================================================================
step(5, "Preference 2: expr()")
# ====================================================================

# expr() writes the same built-ins as a SQL string: same plan, same speed
# as step 4, useful when the condition comes from a config file.
channels_sql = ",".join(f"'{c}'" for c in HIGH_RISK_CHANNELS)
t0 = time.time()
n2 = txns.withColumn("risk",
        F.expr(f"CASE WHEN amount > 50000 AND channel IN ({channels_sql}) "
               f"THEN 'HIGH' ELSE 'LOW' END")).count()
expr_secs = time.time() - t0
print(f"expr(): {n2:,} rows in {expr_secs:.2f}s")


# ====================================================================
step(6, "Preference 3: a pandas UDF")
# ====================================================================

# Reach for this only when the logic genuinely needs numpy or pandas.
# Spark hands each worker a whole pandas Series at once (via Arrow), not
# one row at a time, so it is far closer to built-in speed than a plain
# Python UDF.
@F.pandas_udf(StringType())
def risk_score_pandas(amount: pd.Series, channel: pd.Series) -> pd.Series:
    is_high_channel = channel.isin(HIGH_RISK_CHANNELS)
    return pd.Series(["HIGH" if h and a > 50000 else "LOW"
                       for a, h in zip(amount, is_high_channel)])

# Pandas UDFs need Apache Arrow, which is sensitive to your exact JDK build.
# Guard the call so one laptop's JDK does not stop the whole room.
try:
    t0 = time.time()
    n3 = txns.withColumn("risk", risk_score_pandas(F.col("amount"), F.col("channel"))).count()
    pandas_secs = time.time() - t0
    print(f"pandas UDF: {n3:,} rows in {pandas_secs:.2f}s")
except Exception:
    print("pandas UDF skipped: this JVM cannot run Arrow. Check your Java version, "
          "or add --add-opens=java.base/java.nio=ALL-UNNAMED and retry.")
    pandas_secs = None


# ====================================================================
step(7, "Preference 4, last resort: a plain Python UDF, then all four, timed")
# ====================================================================

# A plain Python UDF serialises EVERY ROW to Python and back, one at a
# time. Correct, but the slowest option. Use it only when nothing above
# can express the rule.
def risk_score_row(amount, channel):
    return "HIGH" if amount > 50000 and channel in HIGH_RISK_CHANNELS else "LOW"

risk_score_udf = F.udf(risk_score_row, StringType())
t0 = time.time()
n4 = txns.withColumn("risk", risk_score_udf(F.col("amount"), F.col("channel"))).count()
python_secs = time.time() - t0
print(f"python UDF: {n4:,} rows in {python_secs:.2f}s")

print(f"\n{'preference':<16}{'seconds':>10}")
print(f"{'1 built-in':<16}{builtin_secs:>10.2f}")
print(f"{'2 expr()':<16}{expr_secs:>10.2f}")
if pandas_secs is not None:
    print(f"{'3 pandas UDF':<16}{pandas_secs:>10.2f}")
else:
    print(f"{'3 pandas UDF':<16}{'skipped':>10}")
print(f"{'4 python UDF':<16}{python_secs:>10.2f}")
print("\nRule: built-in first, expr() next, pandas UDF for real vector math, "
      "plain Python UDF only when nothing else can express the logic.")

spark.stop()
print("\nLab 06 done. No files written, this lab is timing and comparison only.")
