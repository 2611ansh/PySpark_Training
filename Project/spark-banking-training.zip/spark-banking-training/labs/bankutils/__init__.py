"""bankutils: a tiny real package, so "package" stops being an abstract word."""
