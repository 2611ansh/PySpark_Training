"""Small business rules used across the labs."""


def risk_band(dpd):
    """Days-past-due -> a risk band, the kind of rule a bank keeps in code."""
    if dpd == 0:
        return "STANDARD"
    if dpd <= 30:
        return "WATCH"
    return "SUBSTANDARD" if dpd <= 90 else "NPA"
