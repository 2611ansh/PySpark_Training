"""Formatting helpers for money."""


def as_rupees(amount):
    """Format a number as an INR string, e.g. 125000 -> 'Rs 1,25,000.00'."""
    # Split into whole and paise so we control the digit grouping ourselves.
    whole, paise = f"{amount:.2f}".split(".")
    sign = ""
    if whole.startswith("-"):
        sign, whole = "-", whole[1:]
    # Indian grouping: last 3 digits, then groups of 2 to the left.
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return f"{sign}Rs {whole}.{paise}"
