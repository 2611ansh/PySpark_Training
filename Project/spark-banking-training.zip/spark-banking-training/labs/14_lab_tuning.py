"""Lab 14: Performance tuning.

Run it:  ./run.sh labs/14_lab_tuning.py

Method used throughout: measure, change ONE thing, measure again. Every
number below is real, from this exact run, not a canned example.

What you will see:
  1. The skew: branch BR011 holds far more accounts than any other branch
  2. Shuffle partition count: 200 partitions vs 8, on the same query
  3. Skew, measured directly: row counts per output partition
  4. Salting: spread a hot key across N buckets, and check it stays correct
  5. AQE off vs on, using get_spark(aqe=...) on the same query
  6. Small files: too many, then coalesced, same query timed both ways
"""
import os
import shutil
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, TimestampType,
)

from bank_session import get_spark, step, RAW, WAREHOUSE

SCRATCH = f"{WAREHOUSE}/_scratch_lab14"
shutil.rmtree(SCRATCH, ignore_errors=True)

txn_schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()),
    StructField("txn_ts", TimestampType()), StructField("amount", DoubleType()),
    StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()), StructField("status", StringType()),
    StructField("device_id", StringType()), StructField("city", StringType()),
])
account_schema = StructType([
    StructField("account_id", StringType()), StructField("customer_id", StringType()),
    StructField("account_type", StringType()), StructField("branch_code", StringType()),
    StructField("open_date", StringType()), StructField("status", StringType()),
    StructField("balance", DoubleType()), StructField("currency", StringType()),
])

# Start with AQE off, so the first few steps show Spark's static planner,
# the honest baseline every "before" number in this lab is measured against.
spark = get_spark("lab-14-tuning", aqe=False)

txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/")
accounts = spark.read.option("header", True).schema(account_schema).csv(f"{RAW}/accounts.csv")


# ====================================================================
step(1, "The skew: BR011 holds far more accounts than any other branch")
# ====================================================================

# accounts is small, broadcast it on purpose: this join should never shuffle txns.
skewed = txns.join(F.broadcast(accounts.select("account_id", "branch_code")), "account_id").cache()
print("transactions with branch_code attached:", skewed.count())
skewed.groupBy("branch_code").count().orderBy(F.desc("count")).show(5)
print("BR011 alone carries roughly 10x an average branch's share of this key.")
print("Any shuffle keyed on branch_code sends that share to ONE reduce task.")

# ====================================================================
step(2, "Shuffle partition count: 200 vs 8, same query")
# ====================================================================

spark.conf.set("spark.sql.shuffle.partitions", "200")
t0 = time.perf_counter()
skewed.groupBy("branch_code").agg(F.sum("amount")).collect()
secs_200 = time.perf_counter() - t0

spark.conf.set("spark.sql.shuffle.partitions", "8")
t0 = time.perf_counter()
skewed.groupBy("branch_code").agg(F.sum("amount")).collect()
secs_8 = time.perf_counter() - t0

print(f"200 shuffle partitions: {secs_200:.2f}s")
print(f"  8 shuffle partitions: {secs_8:.2f}s")
print("200 tasks for a result with only 36 branch codes is pure scheduling")
print("overhead, most tasks do almost no real work but still pay a fixed cost.")

# ====================================================================
step(3, "Skew, measured directly: row counts per output partition")
# ====================================================================

by_branch = skewed.repartition(8, "branch_code")               # 8 output partitions, keyed on branch_code
sizes = (by_branch.withColumn("pid", F.spark_partition_id())
         .groupBy("pid").count().orderBy(F.desc("count")))
sizes.show()
counts = [r["count"] for r in sizes.collect()]
skew_ratio = max(counts) / min(counts)
print(f"largest partition / smallest partition = {skew_ratio:.1f}x")
print("that one oversized partition is the straggler task that keeps a stage")
print("running long after every other task has already finished.")

# ====================================================================
step(4, "Salting: spread the hot key across N buckets")
# ====================================================================

N = 8                                                            # number of salt buckets
salted = skewed.withColumn("salt", (F.rand(seed=42) * N).cast("int"))
by_salted = salted.repartition(8, "branch_code", "salt")         # now keyed on (branch_code, salt)
salted_sizes = (by_salted.withColumn("pid", F.spark_partition_id())
                .groupBy("pid").count().orderBy(F.desc("count")))
salted_counts = [r["count"] for r in salted_sizes.collect()]
salted_ratio = max(salted_counts) / min(salted_counts)
print(f"row count unchanged by salting: {skewed.count():,} rows before and after")
print(f"skew ratio: {skew_ratio:.1f}x before salting -> {salted_ratio:.1f}x after")
print("salting does not remove BR011's rows, it spreads them over N keys so no")
print("single output partition has to carry all of them.")

skewed.unpersist()

# ====================================================================
step(5, "AQE off vs on: get_spark(aqe=...) on the same query")
# ====================================================================

spark.conf.set("spark.sql.shuffle.partitions", "200")            # exaggerate on purpose, same as Step 2
channel_txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/")
agg = channel_txns.groupBy(F.upper(F.trim("channel")).alias("ch")).agg(F.sum("amount"))
t0 = time.perf_counter()
agg.collect()
secs_off = time.perf_counter() - t0
spark.stop()                                                     # a fresh session is the only way to flip a build-time setting

spark = get_spark("lab-14-tuning-aqe", aqe=True, shuffle_partitions=200)
channel_txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/")
agg = channel_txns.groupBy(F.upper(F.trim("channel")).alias("ch")).agg(F.sum("amount"))
t0 = time.perf_counter()
agg.collect()
secs_on = time.perf_counter() - t0

print(f"aqe=False, 200 shuffle partitions: {secs_off:.2f}s")
print(f"aqe=True,  200 shuffle partitions: {secs_on:.2f}s")
print("with AQE on, Spark COALESCES the 200 planned partitions down to as few")
print("as the actual data needs, after seeing the real shuffle size at runtime.")

# ====================================================================
step(6, "Small files: too many, then coalesced, same query timed both ways")
# ====================================================================

spark.conf.set("spark.sql.shuffle.partitions", "8")
many_path = f"{SCRATCH}/many_files"
few_path = f"{SCRATCH}/few_files"
wide = channel_txns.repartition(40)                              # exaggerated on purpose, same lesson as Lab 03
wide.write.mode("overwrite").parquet(many_path)
wide.coalesce(3).write.mode("overwrite").parquet(few_path)
n_many = len([f for f in os.listdir(many_path) if f.endswith(".parquet")])
n_few = len([f for f in os.listdir(few_path) if f.endswith(".parquet")])

t0 = time.perf_counter()
spark.read.parquet(many_path).filter(F.col("status") == "SUCCESS").count()
secs_many = time.perf_counter() - t0
t0 = time.perf_counter()
spark.read.parquet(few_path).filter(F.col("status") == "SUCCESS").count()
secs_few = time.perf_counter() - t0

print(f"{n_many} files: read + filter took {secs_many:.2f}s")
print(f"{n_few} files: read + filter took {secs_few:.2f}s")
print("same rows, same query, only the file count differs. Every file pays a")
print("fixed list-and-open cost before Spark reads a single row from it.")

shutil.rmtree(SCRATCH, ignore_errors=True)
spark.stop()
print("\nLab 14 done. No output written, this lab only measures.")
