"""Lab 11a: Delta Lake.

Run it:  ./run.sh labs/11_lab_delta.py

FIRST RUN NEEDS INTERNET. get_spark(delta=True) downloads about 60 MB of
Delta Lake jars from Maven Central the first time, then caches them in
~/.ivy2 and every run after that works offline. This sandbox has no Maven
access, so this lab CANNOT run here. It was checked to compile
(python -m py_compile) and every call in it is copied from a pipeline that
ran successfully on the client's own laptop. Run it for real there.

What you will see:
  1. Write transactions as a Delta table, version 0
  2. Look at the _delta_log metadata files Delta wrote on disk
  3. MERGE the late corrections from txn_updates.csv
  4. Time travel back to version 0 and compare row counts
  5. OPTIMIZE to compact small files, then VACUUM to drop old ones
"""
import os
import sys

# Make `import bank_session` work no matter where you run this from.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from delta.tables import DeltaTable                # Delta's own table handle, only exists once the jar is loaded
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, TimestampType,
)

from bank_session import get_spark, step, RAW, WAREHOUSE

# delta=True tells get_spark() to add the Delta jar, extension and catalog.
# Never configure Spark by hand inside a lab, bank_session.py is the one place.
spark = get_spark("lab-11-delta", delta=True)

DELTA_PATH = f"{WAREHOUSE}/delta/txns"              # a plain folder on disk, no metastore needed

# Same explicit schema every raw CSV read uses in this course.
txn_schema = StructType([
    StructField("txn_id", StringType()),
    StructField("account_id", StringType()),
    StructField("txn_ts", TimestampType()),
    StructField("amount", DoubleType()),
    StructField("currency", StringType()),
    StructField("channel", StringType()),
    StructField("merchant_category", StringType()),
    StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()),
    StructField("status", StringType()),
    StructField("device_id", StringType()),
    StructField("city", StringType()),
])


# ====================================================================
step(1, "Write the transactions as a Delta table")
# ====================================================================

txns = (spark.read.option("header", True).schema(txn_schema)
        .csv(f"{RAW}/transactions/")
        .dropDuplicates(["txn_id"]))                # same dedup rule as Lab 04's silver layer

(txns.write.format("delta").mode("overwrite")
 .partitionBy("status")                             # SUCCESS / FAILED / PENDING, one folder each
 .save(DELTA_PATH))

print("rows written, version 0:", spark.read.format("delta").load(DELTA_PATH).count())

# ====================================================================
step(2, "Look at the metadata Delta wrote on disk")
# ====================================================================

log_dir = f"{DELTA_PATH}/_delta_log"
log_files = sorted(os.listdir(log_dir))
print("files in _delta_log/:", log_files)
# 00000000000000000000.json is the commit for version 0. Every later write
# adds one more JSON file here, in order. That log IS the table, there is no
# separate central database recording what a Delta table contains.
print("this is the transaction log every reader checks before trusting a file")

# ====================================================================
step(3, "MERGE the late corrections from txn_updates.csv")
# ====================================================================

updates = (spark.read.option("header", True).schema(txn_schema)
           .csv(f"{RAW}/txn_updates.csv")
           .dropDuplicates(["txn_id"]))

target = DeltaTable.forPath(spark, DELTA_PATH)      # Delta's handle for MERGE, not a plain DataFrame
before = target.toDF().count()

(target.alias("t")
 .merge(updates.alias("s"), "t.txn_id = s.txn_id")
 .whenMatchedUpdate(set={"status": "s.status"})     # a matching txn_id only ever gets a status correction
 .whenNotMatchedInsertAll()                         # a new txn_id (the missed rows) is inserted whole
 .execute())

after = target.toDF().count()
print(f"rows before MERGE: {before:,}  after MERGE: {after:,}")

# ====================================================================
step(4, "Time travel: read an earlier version")
# ====================================================================

target.history().select("version", "timestamp", "operation").show(5, truncate=False)

v0 = spark.read.format("delta").option("versionAsOf", 0).load(DELTA_PATH)
latest = spark.read.format("delta").load(DELTA_PATH)
print("version 0 row count :", v0.count())          # the table exactly as it was before the MERGE
print("latest row count    :", latest.count())

# ====================================================================
step(5, "Maintenance: OPTIMIZE then VACUUM")
# ====================================================================

target.optimize().executeCompaction()               # merges many small part-files into fewer big ones
spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")
target.vacuum(0)                                     # 0 hours is for THIS DEMO only, never in production

print("OPTIMIZE compacted the small files, VACUUM removed files no version still needs.")

spark.stop()
print("\nLab 11a done. Delta table written to data/warehouse/delta/txns/")
