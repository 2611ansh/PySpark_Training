"""Lab 17: a three-step pipeline, driven by arguments.

Run it:  ./run.sh labs/17_lab_pipeline.py --step ingest --run-date 2026-09-01
         ./run.sh labs/17_lab_pipeline.py --step curate --run-date 2026-09-01
         ./run.sh labs/17_lab_pipeline.py --step publish --run-date 2026-09-01

This is the script module 18's Airflow DAGs orchestrate. It has no
SparkSession-per-lab pattern like the labs before it: one script, one
--step argument, because that is exactly the shape a scheduler needs to
call it three times in order.

What each step does:
  ingest   raw CSV for one day       -> bronze Parquet, partitioned by dt
  curate   bronze                    -> dedup, clean, a DATA QUALITY GATE,
                                         then silver Parquet
  publish  silver                    -> a small gold summary, per channel per day

Every write uses dynamic partition overwrite: rerunning a step for the
same --run-date replaces only that date's partition, never any other
date's. That is what makes a rerun, or an Airflow backfill, safe.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType, StringType, StructField, StructType

from bank_session import RAW, WAREHOUSE, get_spark, step

PIPELINE_DIR = f"{WAREHOUSE}/pipeline"          # this lab's own area, separate from Lab 04's bronze/silver/gold

TXN_SCHEMA = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()),
    StructField("txn_ts", StringType()), StructField("amount", DoubleType()),
    StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()), StructField("status", StringType()),
    StructField("device_id", StringType()), StructField("city", StringType()),
])


# ====================================================================
step(1, "Parse arguments, the same three the Airflow DAGs will pass")
# ====================================================================

parser = argparse.ArgumentParser()
parser.add_argument("--step", required=True, choices=["ingest", "curate", "publish"])
parser.add_argument("--run-date", required=True, help="YYYY-MM-DD, the business date this run is FOR")
parser.add_argument("--dq-threshold", type=float, default=1.0, help="max allowed %% of negative-amount rows")
args = parser.parse_args()
print(f"step={args.step} run_date={args.run_date} dq_threshold={args.dq_threshold}")

spark = get_spark(f"lab-17-{args.step}")
# Dynamic mode: writing dt=<run_date> only replaces that ONE partition.
# Without this, .mode("overwrite") on a partitioned table wipes every
# partition, not just the one you gave it data for.
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")


# ====================================================================
if args.step == "ingest":
    step(2, "Ingest: raw CSV for one day -> bronze Parquet")
# ====================================================================
    raw_file = f"{RAW}/transactions/dt={args.run_date}.csv"
    if not os.path.exists(raw_file):
        print(f"ERROR: no raw file for {args.run_date} at {raw_file}")
        spark.stop()
        sys.exit(1)                                          # a missing input day fails loudly, not silently

    txns = spark.read.option("header", True).schema(TXN_SCHEMA).csv(raw_file)
    bronze = txns.withColumn("dt", F.lit(args.run_date)).withColumn("ingest_ts", F.current_timestamp())
    bronze.write.mode("overwrite").partitionBy("dt").parquet(f"{PIPELINE_DIR}/bronze")
    print(f"bronze: wrote {bronze.count()} rows for dt={args.run_date}")


# ====================================================================
elif args.step == "curate":
    step(2, "Curate: dedup, clean, then the data quality gate")
# ====================================================================
    bronze = spark.read.parquet(f"{PIPELINE_DIR}/bronze").filter(F.col("dt") == args.run_date)
    deduped = bronze.dropDuplicates(["txn_id"])                # exact duplicate txn_id rows, same defect Lab 04 teaches
    cleaned = (
        deduped
        .withColumn("channel", F.upper(F.trim(F.col("channel"))))
        .fillna({"merchant_category": "UNKNOWN"})
    )

    total = cleaned.count()
    negative = cleaned.filter(F.col("amount") < 0).count()
    reject_pct = (negative / total * 100) if total else 0.0
    print(f"rows={total} negative_amount_rows={negative} reject_pct={reject_pct:.3f}%")

    if reject_pct > args.dq_threshold:
        # The GATE is nothing more than this exit code. Airflow (module 18)
        # reads it and skips the publish step downstream, no extra operator.
        print(f"DQ GATE FAILED: {reject_pct:.3f}% negative-amount rows exceeds {args.dq_threshold}%")
        spark.stop()
        sys.exit(1)

    print("DQ GATE PASSED")
    cleaned.write.mode("overwrite").partitionBy("dt").parquet(f"{PIPELINE_DIR}/silver")
    print(f"silver: wrote {cleaned.count()} rows for dt={args.run_date}")


# ====================================================================
elif args.step == "publish":
    step(2, "Publish: silver -> a small gold summary, per channel per day")
# ====================================================================
    silver = spark.read.parquet(f"{PIPELINE_DIR}/silver").filter(F.col("dt") == args.run_date)
    gold = (
        silver.groupBy("dt", "channel")
        .agg(F.count("txn_id").alias("txn_count"), F.round(F.sum("amount"), 2).alias("total_amount"))
        .orderBy("channel")
    )
    gold.write.mode("overwrite").partitionBy("dt").parquet(f"{PIPELINE_DIR}/gold")
    gold.show(10)
    print(f"gold: wrote {gold.count()} rows for dt={args.run_date}")


spark.stop()
print(f"\nLab 17 step={args.step} done, finished OK (exit 0).")
