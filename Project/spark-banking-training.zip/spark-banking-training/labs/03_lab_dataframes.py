"""Lab 03: DataFrames.

Run it:  ./run.sh labs/03_lab_dataframes.py

What you will see:
  1. Read the transactions with an explicit schema
  2. inferSchema: why we do not use it
  3. Read modes: PERMISSIVE, DROPMALFORMED, FAILFAST
  4. Clean the dirty columns in this feed
  5. Joins: the orphan-account lesson
  6. Broadcast join to the 36-row branch table
  7. Aggregations
  8. Writing Parquet
"""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from bank_session import get_spark, step, RAW, WAREHOUSE

spark = get_spark("lab-03")
sc = spark.sparkContext

TXN_SCHEMA = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()),
    StructField("txn_ts", StringType()), StructField("amount", DoubleType()),
    StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()), StructField("status", StringType()),
    StructField("device_id", StringType()), StructField("city", StringType())])


# ====================================================================
step(1, "Read the transactions with an explicit schema")
# ====================================================================

# Always declare the schema. inferSchema reads the whole file an extra time
# just to guess, and it guesses differently when next month's file changes.
txns = spark.read.option("header", True).schema(TXN_SCHEMA).csv(f"{RAW}/transactions/*.csv")
print("rows read:", txns.count())


# ====================================================================
step(2, "inferSchema: why we do not use it")
# ====================================================================

# Building the DataFrame is normally free (lazy), zero jobs. Watch what
# inferSchema costs BEFORE we have even asked for a single row.
jobs_before = len(sc.statusTracker().getJobIdsForGroup())
t0 = time.time()
guessed = spark.read.option("header", True).option("inferSchema", True).csv(f"{RAW}/transactions/*.csv")
build_time = time.time() - t0
jobs_after = len(sc.statusTracker().getJobIdsForGroup())
print(f"jobs used just to BUILD the DataFrame: explicit schema = 0, inferSchema = {jobs_after - jobs_before}")
print(f"time spent before we even called an action: {build_time:.1f} s")


# ====================================================================
step(3, "Read modes: PERMISSIVE, DROPMALFORMED, FAILFAST")
# ====================================================================

# A tiny file with one well-formed row and one row with an extra column,
# the kind of feed error a schema mismatch upstream can cause.
sample_path = f"{WAREHOUSE}/_scratch/bad_sample.csv"
os.makedirs(os.path.dirname(sample_path), exist_ok=True)
with open(sample_path, "w") as f:
    f.write("txn_id,account_id,txn_ts,amount,currency,channel,merchant_category,txn_type,"
            "counterparty_account,status,device_id,city\n")
    f.write("TXN1,ACC1,2026-09-01 10:00:00,100.0,INR,UPI,GROCERY,DEBIT,,SUCCESS,DEV1,Mumbai\n")
    f.write("TXN2,ACC2,2026-09-01 10:01:00,250.0,INR,ATM,GROCERY,DEBIT,,SUCCESS,DEV2,Pune,EXTRA\n")

# .collect() forces every column to be parsed, which is what actually makes
# a row count as malformed. count() alone can skip that check, so always
# read a full row (or write the file) before trusting a read mode's result.
permissive = spark.read.option("header", True).schema(TXN_SCHEMA).option("mode", "PERMISSIVE").csv(sample_path)
print("PERMISSIVE (default), keeps every row it can:", len(permissive.collect()))

dropped = spark.read.option("header", True).schema(TXN_SCHEMA).option("mode", "DROPMALFORMED").csv(sample_path)
print("DROPMALFORMED, silently drops the bad row  :", len(dropped.collect()))

sc.setLogLevel("FATAL")   # quiet the expected Java error for this one demo
try:
    failfast = spark.read.option("header", True).schema(TXN_SCHEMA).option("mode", "FAILFAST").csv(sample_path)
    failfast.collect()
except Exception:
    print("FAILFAST, stops the whole job on the bad row: raised an exception, as designed")
sc.setLogLevel("ERROR")


# ====================================================================
step(4, "Clean the dirty columns in this feed")
# ====================================================================

# channel arrives padded and mixed case about 6% of the time.
# merchant_category arrives empty about 7% of the time.
cleaned = (txns
    .withColumn("channel", F.upper(F.trim(F.col("channel"))))
    .withColumn("merchant_category", F.when(F.col("merchant_category") == "", "UNKNOWN")
                                       .otherwise(F.col("merchant_category"))))
cleaned.select("channel", "merchant_category").show(5)


# ====================================================================
step(5, "Joins: the orphan-account lesson")
# ====================================================================

acc_schema = StructType([
    StructField("account_id", StringType()), StructField("customer_id", StringType()),
    StructField("account_type", StringType()), StructField("branch_code", StringType()),
    StructField("open_date", StringType()), StructField("status", StringType()),
    StructField("balance", DoubleType()), StructField("currency", StringType())])
accounts = spark.read.option("header", True).schema(acc_schema).csv(f"{RAW}/accounts.csv") \
    .select("account_id", "branch_code")

inner = cleaned.join(accounts, "account_id", "inner")     # silently drops orphan account_ids
left = cleaned.join(accounts, "account_id", "left")       # keeps them, branch_code comes back null
orphans = left.filter(F.col("branch_code").isNull())
print(f"cleaned rows: {cleaned.count()}  inner join: {inner.count()}  left join: {left.count()}")
print(f"orphan transactions, account_id not in accounts.csv: {orphans.count()}")
print("an inner join here would have DELETED these rows with no warning")


# ====================================================================
step(6, "Broadcast join to the 36-row branch table")
# ====================================================================

branch_schema = StructType([
    StructField("branch_code", StringType()), StructField("branch_name", StringType()),
    StructField("city", StringType()), StructField("state", StringType()),
    StructField("region", StringType()), StructField("ifsc", StringType())])
branches = spark.read.option("header", True).schema(branch_schema).csv(f"{RAW}/branches.csv") \
    .select("branch_code", "branch_name", "region")

# 36 rows fits easily in memory on every executor. F.broadcast() sends the
# whole table to every task instead of shuffling the much bigger left side.
with_branch = inner.join(F.broadcast(branches), "branch_code")
print("--- look for 'BroadcastHashJoin', not 'SortMergeJoin' ---")
with_branch.select("txn_id", "branch_name", "amount").explain()


# ====================================================================
step(7, "Aggregations")
# ====================================================================

by_channel = (with_branch.groupBy("channel")
    .agg(F.count("*").alias("txn_count"),
         F.round(F.sum("amount") / 100000, 2).alias("total_amount_lakh"),
         F.round(F.avg("amount"), 2).alias("avg_amount"))
    .orderBy(F.desc("txn_count")))
by_channel.show(5)


# ====================================================================
step(8, "Writing Parquet")
# ====================================================================

# This is a PRACTICE write for this lab only. Lab 04 builds the real,
# reconciled silver layer that the rest of the course reads from.
out_path = f"{WAREHOUSE}/_scratch/lab03_clean_transactions"
with_branch.select("txn_id", "account_id", "branch_code", "region", "channel",
                    "merchant_category", "amount", "txn_type", "status") \
    .write.mode("overwrite").parquet(out_path)

spark.stop()
print(f"\nLab 03 done. Practice output written to {out_path}")
