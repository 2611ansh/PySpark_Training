"""Lab 11b: Apache Iceberg.

Run it:  ./run.sh labs/11b_lab_iceberg.py

FIRST RUN NEEDS INTERNET. get_spark(iceberg=True) downloads about 60 MB of
Iceberg jars from Maven Central the first time, then caches them in
~/.ivy2 and every run after that works offline. This sandbox has no Maven
access, so this lab CANNOT run here. It was checked to compile
(python -m py_compile) and every call in it is copied from a pipeline that
ran successfully on the client's own laptop. Run it for real there.

Iceberg tables live in a catalog, so almost everything below is SQL against
`local.silver.txns`, not DataFrame writer calls. `local` is the Hadoop
catalog bank_session.py already points at data/warehouse/iceberg/.

What you will see:
  1. Create the table with CREATE TABLE ... AS SELECT
  2. Look at the metadata folder Iceberg wrote on disk
  3. MERGE INTO the late corrections from txn_updates.csv
  4. List snapshots and time travel to the first one
  5. Maintenance: rewrite_data_files and expire_snapshots
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, TimestampType,
)

from bank_session import get_spark, step, RAW

# iceberg=True tells get_spark() to add the Iceberg jar, extension and the
# `local` catalog. Never configure Spark by hand inside a lab.
spark = get_spark("lab-11b-iceberg", iceberg=True)

txn_schema = StructType([
    StructField("txn_id", StringType()),
    StructField("account_id", StringType()),
    StructField("txn_ts", TimestampType()),
    StructField("amount", DoubleType()),
    StructField("currency", StringType()),
    StructField("channel", StringType()),
    StructField("merchant_category", StringType()),
    StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()),
    StructField("status", StringType()),
    StructField("device_id", StringType()),
    StructField("city", StringType()),
])

spark.sql("CREATE DATABASE IF NOT EXISTS local.silver")   # a database is just a folder under the catalog


# ====================================================================
step(1, "Create the table with CREATE TABLE ... AS SELECT")
# ====================================================================

(spark.read.option("header", True).schema(txn_schema)
 .csv(f"{RAW}/transactions/")
 .dropDuplicates(["txn_id"])                        # same dedup rule as Lab 04's silver layer
 .createOrReplaceTempView("raw_txns"))

spark.sql("""
CREATE OR REPLACE TABLE local.silver.txns
USING iceberg
PARTITIONED BY (days(txn_ts))
AS SELECT * FROM raw_txns
""")
# days(txn_ts) is HIDDEN partitioning: there is no extra "dt" column to
# remember to filter on, Iceberg tracks the partition value from txn_ts
# itself and prunes files for you.

spark.sql("SELECT count(*) AS rows_in_table FROM local.silver.txns").show()

# ====================================================================
step(2, "Look at the metadata Iceberg wrote on disk")
# ====================================================================

meta_dir = f"{spark.conf.get('spark.sql.catalog.local.warehouse')}/silver/txns/metadata"
meta_files = sorted(os.listdir(meta_dir))
print("files in metadata/:", meta_files[:6], "...")
# a v1/v2.metadata.json snapshot pointer, plus .avro manifest lists and
# manifest files. The CURRENT metadata.json is what every reader opens first
# to find the current snapshot, the same job _delta_log/*.json does for Delta.
print("metadata.json points at the current snapshot; manifests list its data files")

# ====================================================================
step(3, "MERGE INTO the late corrections from txn_updates.csv")
# ====================================================================

(spark.read.option("header", True).schema(txn_schema)
 .csv(f"{RAW}/txn_updates.csv")
 .dropDuplicates(["txn_id"])
 .createOrReplaceTempView("txn_updates"))

before = spark.table("local.silver.txns").count()

spark.sql("""
MERGE INTO local.silver.txns t
USING txn_updates s
ON t.txn_id = s.txn_id
WHEN MATCHED THEN UPDATE SET t.status = s.status
WHEN NOT MATCHED THEN INSERT *
""")

after = spark.table("local.silver.txns").count()
print(f"rows before MERGE: {before:,}  after MERGE: {after:,}")

# ====================================================================
step(4, "Snapshots and time travel")
# ====================================================================

spark.sql("""
SELECT snapshot_id, committed_at, operation
FROM local.silver.txns.snapshots
ORDER BY committed_at
""").show(truncate=False)

first_snapshot = spark.sql(
    "SELECT snapshot_id FROM local.silver.txns.snapshots "
    "ORDER BY committed_at LIMIT 1"
).collect()[0][0]

old = spark.read.option("snapshot-id", first_snapshot).table("local.silver.txns")
print("first snapshot row count:", old.count())     # the table before the MERGE
print("latest row count        :", spark.table("local.silver.txns").count())

# ====================================================================
step(5, "Maintenance: rewrite_data_files then expire_snapshots")
# ====================================================================

spark.sql("CALL local.system.rewrite_data_files(table => 'silver.txns')").show()
spark.sql("""
CALL local.system.expire_snapshots(
  table => 'silver.txns',
  older_than => TIMESTAMP '2026-09-01 00:00:00',
  retain_last => 1
)
""").show()
print("rewrite_data_files compacted small files, expire_snapshots dropped old ones.")

spark.stop()
print("\nLab 11b done. Iceberg table: local.silver.txns "
      "under data/warehouse/iceberg/")
