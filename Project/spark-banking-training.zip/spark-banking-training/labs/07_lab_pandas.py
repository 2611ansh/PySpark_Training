"""Lab 07: Using pandas from PySpark.

Run it:  ./run.sh labs/07_lab_pandas.py

What you will see:
  1. toPandas() driver memory, the actual arithmetic before you run it
  2. A toPandas() that is safe, because the result is small
  3. applyInPandas: a per-branch reconciliation, one pandas call per group
  4. A short look at the Pandas API on Spark
  5. Decision guide: which tool, for which job
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pandas as pd
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from bank_session import get_spark, step, RAW

spark = get_spark("lab-07")

txn_schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()), StructField("txn_ts", StringType()),
    StructField("amount", DoubleType()), StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()), StructField("counterparty_account", StringType()),
    StructField("status", StringType()), StructField("device_id", StringType()), StructField("city", StringType())])
txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/*.csv")


# ====================================================================
step(1, "toPandas() driver memory, the actual arithmetic")
# ====================================================================

# toPandas() pulls every row to the driver's memory, as ONE Python object.
# There is no partitioning once it lands, so the whole thing must fit.
row_count = txns.count()
avg_bytes_per_row = 130            # rough: ~12 columns, mostly short strings, one double
estimated_mb = row_count * avg_bytes_per_row / (1024 * 1024)
driver_memory_mb = 2048            # a typical laptop's default Spark driver heap
print(f"rows: {row_count:,}  x  ~{avg_bytes_per_row} bytes/row  =  {estimated_mb:.0f} MB as a pandas DataFrame")
print(f"driver memory (typical default): {driver_memory_mb} MB")
if estimated_mb > driver_memory_mb * 0.5:
    print("WARNING: this would use over half the driver's heap. Aggregate first, do not toPandas() this.")

# The fix is never "give the driver more memory". It is "make Spark do the
# reduction first", so only a small result ever reaches the driver.


# ====================================================================
step(2, "A toPandas() that is safe, because the result is small")
# ====================================================================

# Aggregate BEFORE calling toPandas(). One row per day is a handful of
# rows, not 180,720, so this is exactly the safe case.
daily = (txns.withColumn("posting_date", F.to_date("txn_ts"))
    .groupBy("posting_date")
    .agg(F.count("*").alias("txn_count"), F.round(F.sum("amount"), 2).alias("total_amount"))
    .orderBy("posting_date"))
daily_pdf = daily.toPandas()          # safe: 3 rows, not 180,720
print(type(daily_pdf))
print(daily_pdf)


# ====================================================================
step(3, "applyInPandas: a per-branch reconciliation")
# ====================================================================

accounts_schema = StructType([
    StructField("account_id", StringType()), StructField("customer_id", StringType()),
    StructField("account_type", StringType()), StructField("branch_code", StringType())])
accounts = (spark.read.option("header", True).schema(accounts_schema).csv(f"{RAW}/accounts.csv")
    .select("account_id", "branch_code"))
by_branch = txns.join(F.broadcast(accounts), "account_id")      # add branch_code to every transaction

# applyInPandas hands each GROUP to Python as one pandas DataFrame, so you
# can use real pandas methods, not just Spark's built-in aggregates.
result_schema = "branch_code string, txn_count long, total_amount double, avg_amount double"

def reconcile_branch(pdf: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame([{
        "branch_code": pdf["branch_code"].iloc[0],
        "txn_count": len(pdf),
        "total_amount": round(pdf["amount"].sum(), 2),
        "avg_amount": round(pdf["amount"].mean(), 2),
    }])

# Every worker needs Arrow to hand pandas its group, same JDK sensitivity
# as a pandas UDF. Guard it so one laptop's JDK does not stop the room.
try:
    pandas_summary = by_branch.groupBy("branch_code").applyInPandas(reconcile_branch, schema=result_schema)
    pandas_summary.orderBy(F.desc("txn_count")).show(5)
    # Reconcile: Spark's own native aggregate must give the same totals.
    native_summary = by_branch.groupBy("branch_code").agg(
        F.count("*").alias("txn_count"), F.round(F.sum("amount"), 2).alias("total_amount"))
    same_count = pandas_summary.count() == native_summary.count()
    print("same number of branches in both summaries?", same_count)
except Exception:
    print("applyInPandas skipped: this JVM cannot run Arrow. Check your Java version, "
          "or add --add-opens=java.base/java.nio=ALL-UNNAMED and retry.")


# ====================================================================
step(4, "A short look at the Pandas API on Spark")
# ====================================================================

# pyspark.pandas gives you pandas SYNTAX (.mean(), column indexing, no
# .select()/.groupBy()) while the work still runs as distributed Spark
# jobs underneath. It needs a pandas version that matches this Spark
# build, so guard the import the same way.
try:
    import pyspark.pandas as ps
    psdf = ps.DataFrame({"branch_code": ["BR011", "BR021"], "txn_count": [14824, 1152]})
    print(psdf.sort_values("txn_count", ascending=False))
except Exception:
    print("Pandas API on Spark skipped: needs a pandas version this Spark build supports. "
          "The code above is correct once the versions line up.")


# ====================================================================
step(5, "Decision guide: which tool, for which job")
# ====================================================================

print(f"{'need':<38}{'use':<22}")
print(f"{'a small final result on the driver':<38}{'toPandas() after aggregating':<22}")
print(f"{'a pandas-only op, per group, at scale':<38}{'applyInPandas':<22}")
print(f"{'pandas syntax over the full dataset':<38}{'pyspark.pandas':<22}")
print(f"{'everything else':<38}{'the native DataFrame API':<22}")

spark.stop()
print("\nLab 07 done. No files written, this lab is comparison only.")
