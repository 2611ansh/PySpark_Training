"""Lab 16: MLlib overview.

Run it:  ./run.sh labs/16_lab_mllib.py

A short survey lab: one small, real fraud classifier, built with
StringIndexer, VectorAssembler and LogisticRegression inside a Pipeline.
The point is not the model's accuracy, it is seeing the Pipeline API once,
end to end, and reading the metrics honestly.

What you will see:
  1. Reading transactions and joining to fraud_labels
  2. The fraud rate, and why that number matters more than any model score
  3. Building features: StringIndexer, VectorAssembler
  4. A Pipeline: indexer -> assembler -> LogisticRegression
  5. Fitting the Pipeline and scoring the held-out test set
  6. Reading the metrics honestly: accuracy vs PR-AUC
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.ml import Pipeline
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType, IntegerType, StringType, StructField, StructType

from bank_session import RAW, get_spark, step

spark = get_spark("lab-16")


# ====================================================================
step(1, "Read transactions and join to fraud_labels")
# ====================================================================

# The same explicit schema every lab in this course uses.
txn_schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()),
    StructField("txn_ts", StringType()), StructField("amount", DoubleType()),
    StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()), StructField("status", StringType()),
    StructField("device_id", StringType()), StructField("city", StringType()),
])
txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/")

# fraud_labels.csv ONLY lists the fraud cases, there is no "not fraud" row
# in it. A left join, then filling the missing side with 0, is how the
# full labelled set gets built.
fraud_schema = StructType([
    StructField("txn_id", StringType()), StructField("is_fraud", IntegerType()),
    StructField("reported_date", StringType()), StructField("fraud_type", StringType()),
])
fraud = spark.read.option("header", True).schema(fraud_schema).csv(f"{RAW}/fraud_labels.csv")

labelled = (
    txns.join(fraud.select("txn_id", "is_fraud"), "txn_id", "left")
    .withColumn("is_fraud", F.coalesce(F.col("is_fraud"), F.lit(0)).cast(DoubleType()))
)
print("total transactions:", labelled.count())


# ====================================================================
step(2, "The fraud rate, the number that matters most")
# ====================================================================

total = labelled.count()
fraud_count = labelled.filter(F.col("is_fraud") == 1.0).count()
fraud_rate = fraud_count / total
print(f"labelled fraud    : {fraud_count:,} ({fraud_rate:.3%})")
print(f"'always not fraud' would already score {1 - fraud_rate:.3%} accuracy, doing nothing")


# ====================================================================
step(3, "Build features: StringIndexer, VectorAssembler")
# ====================================================================

# hour_of_day and a cleaned channel: cheap, sensible features for a first model.
featured = (
    labelled
    .withColumn("channel_clean", F.upper(F.trim(F.col("channel"))))
    .withColumn("hour_of_day", F.hour(F.to_timestamp("txn_ts")))
    .fillna({"merchant_category": "UNKNOWN"})
)

# StringIndexer is an ESTIMATOR: it has to see the data once to learn the
# string-to-number mapping. handleInvalid="keep" sends any category the
# model never saw in training to one extra "unknown" index, instead of
# crashing on it at test time.
channel_idx = StringIndexer(inputCol="channel_clean", outputCol="channel_idx", handleInvalid="keep")
category_idx = StringIndexer(inputCol="merchant_category", outputCol="category_idx", handleInvalid="keep")
type_idx = StringIndexer(inputCol="txn_type", outputCol="type_idx", handleInvalid="keep")

# VectorAssembler is a plain TRANSFORMER: it just packs columns into one
# "features" vector column, the shape every pyspark.ml model expects.
assembler = VectorAssembler(
    inputCols=["channel_idx", "category_idx", "type_idx", "amount", "hour_of_day"],
    outputCol="features",
)


# ====================================================================
step(4, "A Pipeline: indexer -> assembler -> LogisticRegression")
# ====================================================================

lr = LogisticRegression(featuresCol="features", labelCol="is_fraud", maxIter=20)
pipeline = Pipeline(stages=[channel_idx, category_idx, type_idx, assembler, lr])

# .fit() on a whole Pipeline runs every stage's fit/transform in order and
# wraps the result as one PipelineModel, a Transformer you can call
# .transform() on as many times as you like without re-learning anything.
train_df, test_df = featured.randomSplit([0.75, 0.25], seed=42)
print("train rows:", train_df.count(), " test rows:", test_df.count())


# ====================================================================
step(5, "Fit the Pipeline, score the held-out test set")
# ====================================================================

model = pipeline.fit(train_df)
scored = model.transform(test_df)
scored.select("txn_id", "is_fraud", "prediction").show(5)


# ====================================================================
step(6, "Reading the metrics honestly")
# ====================================================================

accuracy = MulticlassClassificationEvaluator(
    labelCol="is_fraud", predictionCol="prediction", metricName="accuracy",
).evaluate(scored)

pr_auc = BinaryClassificationEvaluator(
    labelCol="is_fraud", rawPredictionCol="rawPrediction", metricName="areaUnderPR",
).evaluate(scored)

roc_auc = BinaryClassificationEvaluator(
    labelCol="is_fraud", rawPredictionCol="rawPrediction", metricName="areaUnderROC",
).evaluate(scored)

test_fraud_rate = test_df.filter(F.col("is_fraud") == 1.0).count() / test_df.count()

print(f"accuracy (looks great, means almost nothing here) : {accuracy:.4f}")
print(f"area under ROC (also flattered by the imbalance)  : {roc_auc:.4f}")
print(f"area under PR  (the honest number for this data)  : {pr_auc:.4f}")
print(f"test set base rate (PR-AUC of a useless model)    : {test_fraud_rate:.4f}")
print()
print("Fraud is about 0.3% of rows here, so accuracy is close to meaningless:")
print("a model that predicts 'not fraud' for everything already scores over 99%.")
print("PR-AUC sitting close to the base rate means this small, untuned model")
print("is barely better than random. That is expected for a first attempt with")
print("weak features and very few confirmed fraud cases, not a bug in the code.")

spark.stop()
print("\nLab 16 done. No files written, this lab only trains and scores in memory.")
