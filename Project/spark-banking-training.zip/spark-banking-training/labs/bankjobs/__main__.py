"""The ONLY place argument parsing, logging setup and exit codes live.

Run it two ways, both shown in docs/15_packaging.md:

  python -m bankjobs --job daily_kpi
  spark-submit --py-files bankjobs.zip bankjobs/__main__.py --job daily_kpi

Exit codes, the whole contract between this package and whatever schedules
it (cron, Airflow, module 17/18):

  0   job ran and wrote its output
  1   job raised an exception, caught and logged here
  2   bad command line argument, argparse's own code, never even builds a
      SparkSession
"""
import argparse
import logging
import sys
import time
import uuid

from pyspark.sql import SparkSession

from bankjobs.config import load_config
from bankjobs.jobs import JOB_REGISTRY


def parse_args(argv):
    parser = argparse.ArgumentParser(prog="bankjobs")
    parser.add_argument("--job", required=True, choices=list(JOB_REGISTRY))
    parser.add_argument("--env", default="dev", choices=["dev", "uat", "prod"])
    parser.add_argument("--raw-path", default=None)              # overrides config.py's default, see load_config()
    parser.add_argument("--warehouse-path", default=None)
    parser.add_argument("--shuffle-partitions", type=int, default=None)
    return parser.parse_args(argv)


def configure_logging(correlation_id: str) -> None:
    # Every line carries the same id, so one run's lines can be pulled out
    # of a shared log file by grep, even with a hundred other jobs logging
    # to the same place.
    logging.basicConfig(
        level=logging.INFO,
        format=f"%(asctime)s level=%(levelname)s correlation_id={correlation_id} logger=%(name)s msg=%(message)s",
        stream=sys.stdout,
    )


def main(argv=None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])
    correlation_id = uuid.uuid4().hex[:12]
    configure_logging(correlation_id)
    log = logging.getLogger("bankjobs.main")

    config = load_config(
        env=args.env,
        raw_path=args.raw_path,
        warehouse_path=args.warehouse_path,
        shuffle_partitions=args.shuffle_partitions,
    )
    log.info("job=%s env=%s raw_path=%s warehouse_path=%s", args.job, config.env, config.raw_path, config.warehouse_path)

    spark = (
        SparkSession.builder
        .appName(f"bankjobs-{args.job}")
        .master("local[*]")
        .config("spark.sql.shuffle.partitions", config.shuffle_partitions)
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("ERROR")

    job_module = JOB_REGISTRY[args.job]
    t0 = time.perf_counter()
    try:
        row_count = job_module.run(spark, config)
    except Exception:
        log.exception("job=%s FAILED after %.2fs", args.job, time.perf_counter() - t0)
        spark.stop()                # never leave a SparkSession running on the failure path
        return 1
    else:
        log.info("job=%s SUCCEEDED, %d rows, %.2fs", args.job, row_count, time.perf_counter() - t0)
        spark.stop()
        return 0


if __name__ == "__main__":
    sys.exit(main())
