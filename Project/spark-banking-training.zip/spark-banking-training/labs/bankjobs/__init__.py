"""bankjobs: AtliQ Bank's packaged production jobs.

A real installable package, not a loose script. See docs/15_packaging.md
for why that difference matters once a job has to run somewhere other than
the author's own laptop.
"""

__version__ = "0.1.0"
