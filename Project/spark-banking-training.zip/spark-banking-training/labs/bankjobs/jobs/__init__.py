"""JOB_REGISTRY: job name (the --job argument) to job module.

__main__.py never hardcodes "if args.job == 'daily_kpi'". It looks the name
up here instead, so adding a second job means adding one line to this
dict, never touching __main__.py at all.
"""
from bankjobs.jobs import daily_kpi

JOB_REGISTRY = {
    "daily_kpi": daily_kpi,
}
