"""daily_kpi: one row per branch per day, txn count, total amount, active
accounts. The same shape of report a branch ops team pulls every morning.

Split into two functions on purpose:

  transform()   pure. DataFrame in, DataFrame out. No file path, no config.
  run()         does the IO: reads using config, calls transform(), writes.

Only transform() is unit tested (tests/test_bankjobs.py), with five
hand-built rows, no file on disk, no SparkSession config. That split is
what makes it possible to test the AGGREGATION without a real file every
time. See docs/15_packaging.md, section on testing.
"""
import logging
import os

from pyspark.sql import DataFrame, SparkSession, functions as F
from pyspark.sql.types import StringType, StructField, StructType, DoubleType

from bankjobs.config import JobConfig

log = logging.getLogger("bankjobs.daily_kpi")

# Explicit schemas. Same reason every lab in this course declares one:
# inferSchema reads the file twice and can guess differently next month.
TXN_SCHEMA = StructType([
    StructField("txn_id", StringType()),
    StructField("account_id", StringType()),
    StructField("txn_ts", StringType()),
    StructField("amount", DoubleType()),
    StructField("currency", StringType()),
    StructField("channel", StringType()),
    StructField("merchant_category", StringType()),
    StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()),
    StructField("status", StringType()),
    StructField("device_id", StringType()),
    StructField("city", StringType()),
])

ACCOUNT_SCHEMA = StructType([
    StructField("account_id", StringType()),
    StructField("customer_id", StringType()),
    StructField("account_type", StringType()),
    StructField("branch_code", StringType()),
    StructField("open_date", StringType()),
    StructField("status", StringType()),
    StructField("balance", DoubleType()),
    StructField("currency", StringType()),
])


def transform(txns: DataFrame, accounts: DataFrame) -> DataFrame:
    """Pure: no file path, no config, no IO. Easy to hand a Spark session
    and five rows and check the answer, exactly what the test suite does.
    """
    settled = txns.filter(F.col("status") == "SUCCESS")           # only completed transactions count
    joined = settled.join(accounts.select("account_id", "branch_code"), "account_id", "inner")
    dated = joined.withColumn("txn_date", F.substring("txn_ts", 1, 10))   # "2026-09-01 10:15:00" -> "2026-09-01"

    return (
        dated.groupBy("branch_code", "txn_date")
        .agg(
            F.count("txn_id").alias("txn_count"),
            F.round(F.sum("amount"), 2).alias("total_amount"),
            F.countDistinct("account_id").alias("active_accounts"),
        )
        .orderBy("branch_code", "txn_date")                        # deterministic output, safe to compare in a test
    )


def run(spark: SparkSession, config: JobConfig) -> int:
    """The IO half. Reads using config, calls transform(), writes, returns
    the row count so __main__.py can log it.
    """
    txn_path = config.transactions_path()
    if not os.path.isdir(txn_path):
        # Never crash with a raw stack trace on a missing input, tell the
        # operator exactly what to do next.
        log.error(
            "no transactions found at %s. Run this from the project root, "
            "or pass --raw-path explicitly.", txn_path,
        )
        raise FileNotFoundError(txn_path)

    log.info("reading transactions from %s", txn_path)
    txns = spark.read.option("header", True).schema(TXN_SCHEMA).csv(txn_path)
    accounts = spark.read.option("header", True).schema(ACCOUNT_SCHEMA).csv(config.accounts_path())

    result = transform(txns, accounts)
    out_path = config.output_path("daily_kpi")
    result.write.mode("overwrite").parquet(out_path)
    row_count = result.count()
    log.info("wrote %d rows to %s", row_count, out_path)
    return row_count
