"""The ONLY place a path or environment default lives.

Every job asks load_config() for its configuration. Nothing in jobs/
hardcodes a path, an environment name, or a threshold.
"""
import os
from dataclasses import dataclass
from pathlib import Path

# Per-environment defaults. dev is real and runnable, this course's own
# data. uat and prod are ILLUSTRATIVE s3a:// placeholders, never runnable
# in this sandbox, they only show the shape a real bank deployment takes.
ENV_DEFAULTS = {
    "dev": {"raw_path": "data/raw", "warehouse_path": "data/warehouse"},
    "uat": {"raw_path": "s3a://atliq-uat/raw", "warehouse_path": "s3a://atliq-uat/warehouse"},
    "prod": {"raw_path": "s3a://atliq-prod/raw", "warehouse_path": "s3a://atliq-prod/warehouse"},
}


@dataclass(frozen=True)                    # frozen: nothing downstream can mutate a running job's config
class JobConfig:
    env: str
    raw_path: str
    warehouse_path: str
    shuffle_partitions: int = 8

    def transactions_path(self) -> str:
        return str(Path(self.raw_path) / "transactions")

    def accounts_path(self) -> str:
        return str(Path(self.raw_path) / "accounts.csv")

    def output_path(self, table: str) -> str:
        return str(Path(self.warehouse_path) / "gold" / table)


def load_config(env="dev", raw_path=None, warehouse_path=None, shuffle_partitions=None) -> JobConfig:
    """Build a JobConfig. Precedence, lowest to highest:

    1. the per-environment default above
    2. an environment variable (BANKJOBS_RAW_PATH, BANKJOBS_WAREHOUSE_PATH,
       BANKJOBS_SHUFFLE_PARTITIONS)
    3. an explicit argument, always wins

    Paths are relative to the current working directory on purpose: this
    package is designed to be run FROM the project root, exactly like
    spark-submit is in docs/15_packaging.md. That keeps this file free of
    any __file__ arithmetic, which is the kind of "clever" path logic that
    breaks the moment code ships inside a zip.
    """
    if env not in ENV_DEFAULTS:
        raise ValueError(f"unknown env {env!r}, choose one of {list(ENV_DEFAULTS)}")
    defaults = ENV_DEFAULTS[env]

    raw = raw_path or os.environ.get("BANKJOBS_RAW_PATH") or defaults["raw_path"]
    warehouse = warehouse_path or os.environ.get("BANKJOBS_WAREHOUSE_PATH") or defaults["warehouse_path"]
    shuffle = shuffle_partitions or int(os.environ.get("BANKJOBS_SHUFFLE_PARTITIONS", "8"))

    return JobConfig(env=env, raw_path=raw, warehouse_path=warehouse, shuffle_partitions=shuffle)
