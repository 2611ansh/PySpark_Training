"""Lab 13: Structured Streaming.

Run it:  ./run.sh labs/13_lab_streaming.py

This lab starts its own feeder (13b_feeder.py) as a background process,
reads the files it drops with the file source, runs for a bounded time
(about 50 seconds total), prints progress as it goes, then stops every
query and the feeder cleanly. It never waits forever: everything is bounded
by a wall-clock deadline.

What you will see:
  1. Start the feeder, open the stream with an explicit schema
  2. A watermark, so late data has a clear cutoff instead of none at all
  3. A tumbling window: count transactions per channel per 20 seconds
  4. foreachBatch: write large-amount alerts to Parquet, checkpointed
  5. Run bounded, printing real progress, then stop everything
  6. Output modes and exactly-once, in one table
"""
import os
import shutil
import subprocess
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, TimestampType,
)

from bank_session import get_spark, step, RAW, STREAM_CKPT, STREAM_IN, WAREHOUSE

FEED_SECONDS = 25                                    # the feeder stops dripping files after this long
DRAIN_SECONDS = 20                                   # extra time for the queries to catch up, then stop
ALERTS_PATH = f"{WAREHOUSE}/streaming/large_amount_alerts"
LARGE_AMOUNT = 500_000                                # RTGS-scale, see Module 00's data generator

txn_schema = StructType([
    StructField("txn_id", StringType()),
    StructField("account_id", StringType()),
    StructField("txn_ts", TimestampType()),
    StructField("amount", DoubleType()),
    StructField("currency", StringType()),
    StructField("channel", StringType()),
    StructField("merchant_category", StringType()),
    StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()),
    StructField("status", StringType()),
    StructField("device_id", StringType()),
    StructField("city", StringType()),
])

# Start clean: an old checkpoint from a previous run would confuse this run's state.
shutil.rmtree(STREAM_IN, ignore_errors=True)
shutil.rmtree(STREAM_CKPT, ignore_errors=True)
shutil.rmtree(ALERTS_PATH, ignore_errors=True)
os.makedirs(STREAM_IN, exist_ok=True)
os.makedirs(STREAM_CKPT, exist_ok=True)

spark = get_spark("lab-13-streaming", shuffle_partitions=4)


# ====================================================================
step(1, "Start the feeder, then open the stream")
# ====================================================================

feeder_script = os.path.join(os.path.dirname(__file__), "13b_feeder.py")
feeder = subprocess.Popen(
    [sys.executable, feeder_script, "--seconds", str(FEED_SECONDS),
     "--batch-size", "150", "--interval", "1.0"],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
)
print(f"feeder started (pid {feeder.pid}), it will drip files for {FEED_SECONDS}s")
time.sleep(3)                                         # let a few files land before the stream opens

raw_stream = (spark.readStream
              .schema(txn_schema)                     # never inferSchema on a stream, see Lab 03
              .option("header", True)
              .option("timestampFormat", "yyyy-MM-dd HH:mm:ss")
              .option("maxFilesPerTrigger", 5)         # caps how much one micro-batch reads at once
              .csv(STREAM_IN))
print("stream opened, treating data/stream_in/ as an ever-growing table")

# ====================================================================
step(2, "A watermark: a clear, explicit cutoff for late data")
# ====================================================================

watermarked = raw_stream.withWatermark("txn_ts", "2 minutes")
print("withWatermark(txn_ts, 2 minutes): once the newest txn_ts seen so far")
print("passes T, any row older than T minus 2 minutes is assumed to never")
print("arrive and is DROPPED, not queued. That is what keeps a streaming")
print("job's memory of old keys from growing forever.")

# ====================================================================
step(3, "A tumbling window: transactions per channel, every 20 seconds")
# ====================================================================

windowed = (watermarked
            .groupBy(F.window("txn_ts", "20 seconds"), "channel")
            .agg(F.count("*").alias("txn_count")))

window_query = (windowed.writeStream
                 .outputMode("update")                # only re-emit windows whose count just changed
                 .format("memory")
                 .queryName("channel_activity")
                 .trigger(processingTime="5 seconds")
                 .start())
print("window_query writes to an in-memory table, queryable with SQL below,")
print("only for this demo: a real job would use foreachBatch, like Step 4.")

# ====================================================================
step(4, "foreachBatch: write large-amount alerts to Parquet, checkpointed")
# ====================================================================

def write_alerts(batch_df, batch_id):
    # a plain, static DataFrame inside here, any batch-style write is legal
    large = batch_df.filter(F.col("amount") > LARGE_AMOUNT)
    n_large = large.count()
    if n_large > 0:
        large.write.mode("append").parquet(ALERTS_PATH)
    print(f"  [alerts batch {batch_id}] rows={batch_df.count():,}  large_amount={n_large}")


alert_query = (watermarked.writeStream
               .foreachBatch(write_alerts)
               .option("checkpointLocation", f"{STREAM_CKPT}/alerts")
               .trigger(processingTime="5 seconds")
               .start())
print("checkpointLocation records exactly which files fed each micro-batch,")
print("so a restart never reprocesses or skips a file. This is one half of")
print("exactly-once, see Step 6 for the other half.")

# ====================================================================
step(5, "Run bounded, print real progress, then stop everything")
# ====================================================================

deadline = time.time() + DRAIN_SECONDS
while time.time() < deadline:
    time.sleep(5)
    progress = alert_query.lastProgress
    if progress:
        print(f"  batchId={progress.get('batchId')} "
              f"numInputRows={progress.get('numInputRows')} "
              f"inputRowsPerSecond={progress.get('inputRowsPerSecond', 0.0):.1f}")
    print(f"  ... {max(0, int(deadline - time.time()))}s remaining")

for q in (window_query, alert_query):
    if q.isActive:
        q.stop()                                       # always stop what you started, never rely on GC

try:
    feeder.wait(timeout=10)
except subprocess.TimeoutExpired:
    feeder.terminate()
print("\n" + (feeder.stdout.read() or "").strip())

spark.sql("SELECT * FROM channel_activity ORDER BY txn_count DESC LIMIT 5").show(truncate=False)

if os.path.isdir(ALERTS_PATH):
    n_alerts = spark.read.parquet(ALERTS_PATH).count()
    print(f"large-amount alerts written: {n_alerts}")
else:
    print("no large-amount alerts crossed the threshold in this short run")

# ====================================================================
step(6, "Output modes and exactly-once")
# ====================================================================

print("""
| Output mode | Meaning                                             |
|-------------|------------------------------------------------------|
| append      | only new rows since the last batch, ever              |
| update      | rows that changed since the last batch                |
| complete    | the whole result table, re-emitted every batch         |

Exactly-once here comes from two things together: the checkpoint remembers
exactly which input files produced a given batch, so a restart reproduces
the same batch, not a different one. And the Parquet append in Step 4 is
naturally idempotent because Lab 04's dedup habit (dropDuplicates on
txn_id) would already have run upstream in a real pipeline. A sink that is
NOT naturally idempotent, a JDBC counter for example, needs its own key to
get the same guarantee.
""")

spark.stop()
print("Lab 13 done. Streaming queries and feeder stopped, nothing left running.")
