"""Lab 09: SQL, Python and Spark.

Run it:  ./run.sh labs/09_lab_sql.py

What you will see:
  1. Proof: the DataFrame API and SQL compile to the same plan
  2. Temp views, and the catalog that tracks them
  3. Managed vs external tables, and what DROP TABLE really deletes
  4. No QUALIFY in open source Spark, and the row_number() workaround
  5. GROUPING SETS: three breakdowns in one query
  6. TRY_CAST and NULL semantics
  7. ANSI mode: the same bad query, two different outcomes
"""
import os
import re
import shutil
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from bank_session import get_spark, step, RAW, WAREHOUSE

spark = get_spark("lab-09")

txn_schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()), StructField("txn_ts", StringType()),
    StructField("amount", DoubleType()), StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()), StructField("counterparty_account", StringType()),
    StructField("status", StringType()), StructField("device_id", StringType()), StructField("city", StringType())])
txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/*.csv")
txns.createOrReplaceTempView("v_txns")


# ====================================================================
step(1, "Proof: the DataFrame API and SQL compile to the same plan")
# ====================================================================

df_way = txns.groupBy("channel").agg(F.count("*").alias("n"))
sql_way = spark.sql("SELECT channel, COUNT(*) AS n FROM v_txns GROUP BY channel")

# Every column gets a unique internal id, e.g. "n#42", and the two queries
# were compiled separately so their ids differ even when the plan is
# identical. Strip the ids before comparing the plan text.
strip_ids = lambda plan: re.sub(r"#\d+", "", plan)
df_plan = strip_ids(df_way._jdf.queryExecution().optimizedPlan().toString())
sql_plan = strip_ids(sql_way._jdf.queryExecution().optimizedPlan().toString())
print("same optimized plan?", df_plan == sql_plan)
print(df_plan)


# ====================================================================
step(2, "Temp views, and the catalog that tracks them")
# ====================================================================

# v_txns already exists, from createOrReplaceTempView above. It lives for
# this SparkSession only: close Spark, and it is gone, nothing was written.
print("tables the catalog knows about:")
for t in spark.catalog.listTables():
    print(f"  {t.name:<12} temporary={t.isTemporary}")
spark.sql("SELECT channel, COUNT(*) AS n FROM v_txns GROUP BY channel ORDER BY n DESC").show(5)


# ====================================================================
step(3, "Managed vs external tables, and what DROP TABLE deletes")
# ====================================================================

daily = txns.withColumn("posting_date", F.to_date("txn_ts")).groupBy("posting_date").count()

# MANAGED: Spark picks the location, under spark.sql.warehouse.dir.
daily.write.mode("overwrite").saveAsTable("lab09_managed_daily")
managed_location = spark.sql("DESCRIBE FORMATTED lab09_managed_daily") \
    .filter("col_name = 'Location'").first()["data_type"]
print("managed table files at:", managed_location)

# EXTERNAL: WE pick the location, with an explicit path.
external_path = f"{WAREHOUSE}/lab09_external_daily"
daily.write.mode("overwrite").option("path", external_path).saveAsTable("lab09_external_daily")

# DROP TABLE on a MANAGED table deletes the metadata AND the data files.
spark.sql("DROP TABLE lab09_managed_daily")
print("managed table files still on disk after DROP?", os.path.isdir(managed_location.replace("file:", "")))

# DROP TABLE on an EXTERNAL table deletes only the metadata. The files,
# and anyone else's pipeline reading that path, are untouched.
spark.sql("DROP TABLE lab09_external_daily")
print("external table files still on disk after DROP?", os.path.isdir(external_path))
shutil.rmtree(external_path, ignore_errors=True)          # clean up, this lab does not need it any more


# ====================================================================
step(4, "No QUALIFY in open source Spark, and the row_number() workaround")
# ====================================================================

# Teradata and Oracle let you write QUALIFY row_number() OVER (...) = 1
# straight after WHERE. Open source Spark SQL has no QUALIFY keyword: wrap
# the window function in a subquery and filter the OUTER query instead.
spark.sql("""
    SELECT account_id, amount, channel, rn
    FROM (
        SELECT account_id, amount, channel,
               ROW_NUMBER() OVER (PARTITION BY account_id ORDER BY amount DESC) AS rn
        FROM v_txns
    )
    WHERE rn = 1
    ORDER BY amount DESC
""").show(5)


# ====================================================================
step(5, "GROUPING SETS: three breakdowns in one query")
# ====================================================================

# One scan of the data produces: totals by channel, totals by txn_type,
# and the grand total, all in one result set. Three separate GROUP BY
# queries would each read the data again. Clean channel first, so UPI
# and " upi " land in the same group instead of sixteen dirty ones.
txns.withColumn("channel", F.upper(F.trim(F.col("channel")))).createOrReplaceTempView("v_txns_clean")
spark.sql("""
    SELECT COALESCE(channel, '(all channels)') AS channel,
           COALESCE(txn_type, '(all types)') AS txn_type,
           COUNT(*) AS n, ROUND(SUM(amount), 2) AS total
    FROM v_txns_clean
    GROUP BY GROUPING SETS ((channel), (txn_type), ())
    ORDER BY channel, txn_type
""").show(20, truncate=False)


# ====================================================================
step(6, "TRY_CAST and NULL semantics")
# ====================================================================

# CAST on a bad value fails the whole query in ANSI mode. TRY_CAST never
# fails: a bad value just becomes NULL, which is usually what a feed needs.
spark.sql("SELECT TRY_CAST('12.5' AS DOUBLE) AS good, TRY_CAST('abc' AS DOUBLE) AS bad").show()

# NULL is "unknown", not zero or empty. col = NULL is never TRUE, not even
# when col IS NULL, so it matches nothing. Use IS NULL instead.
spark.sql("""
    SELECT SUM(CASE WHEN merchant_category = NULL THEN 1 ELSE 0 END) AS matched_with_equals,
           SUM(CASE WHEN merchant_category IS NULL THEN 1 ELSE 0 END) AS matched_with_is_null
    FROM v_txns
""").show()


# ====================================================================
step(7, "ANSI mode: the same bad query, two different outcomes")
# ====================================================================

spark.conf.set("spark.sql.ansi.enabled", "false")
lenient = spark.sql("SELECT 1/0 AS divide_by_zero, CAST('abc' AS INT) AS bad_cast").first()
print("ANSI off, a bad expression quietly returns NULL:", lenient.asDict())

spark.conf.set("spark.sql.ansi.enabled", "true")
try:
    spark.sql("SELECT 1/0 AS divide_by_zero").collect()
except Exception as e:
    print("ANSI on, the SAME kind of expression raises:", type(e).__name__)
spark.conf.set("spark.sql.ansi.enabled", "false")     # leave the session as we found it

spark.stop()
print("\nLab 09 done. No files kept, the demo tables were dropped in step 3.")
