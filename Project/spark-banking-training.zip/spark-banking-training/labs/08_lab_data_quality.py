"""Lab 08: Data quality and profiling.

Run it:  ./run.sh labs/08_lab_data_quality.py

What you will see:
  1. Profile the feed: counts, blanks, distincts, date range
  2. Quantify this feed's five deliberate defects as real numbers
  3. A small, copyable data quality rule table
  4. Run every rule in one pass, write dq_results
  5. Reconcile bronze against silver: counts and sums that must tie
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from bank_session import get_spark, step, RAW, WAREHOUSE

spark = get_spark("lab-08")

txn_schema = StructType([
    StructField("txn_id", StringType()), StructField("account_id", StringType()), StructField("txn_ts", StringType()),
    StructField("amount", DoubleType()), StructField("currency", StringType()), StructField("channel", StringType()),
    StructField("merchant_category", StringType()), StructField("txn_type", StringType()), StructField("counterparty_account", StringType()),
    StructField("status", StringType()), StructField("device_id", StringType()), StructField("city", StringType())])
txns = spark.read.option("header", True).schema(txn_schema).csv(f"{RAW}/transactions/*.csv").cache()


# ====================================================================
step(1, "Profile the feed")
# ====================================================================

total = txns.count()
print("total rows:", f"{total:,}")
for c in ["account_id", "channel", "merchant_category", "status"]:
    blanks = txns.filter(F.col(c).isNull() | (F.col(c) == "")).count()
    print(f"  blank/null {c:<18}: {blanks:,} ({blanks / total * 100:.2f}%)")
print("distinct channels (raw, still dirty):", txns.select("channel").distinct().count())
date_min, date_max = txns.select(F.min("txn_ts"), F.max("txn_ts")).first()
print(f"date range: {date_min} to {date_max}")


# ====================================================================
step(2, "Quantify this feed's five deliberate defects")
# ====================================================================

accounts_schema = StructType([
    StructField("account_id", StringType()), StructField("customer_id", StringType()),
    StructField("account_type", StringType()), StructField("branch_code", StringType())])
known_accounts = (spark.read.option("header", True).schema(accounts_schema).csv(f"{RAW}/accounts.csv")
    .select("account_id").withColumn("account_known", F.lit(True)))
tagged = txns.join(known_accounts, "account_id", "left").fillna({"account_known": False}).cache()

dup_n = total - txns.select("txn_id").distinct().count()
orphan_n = tagged.filter(~F.col("account_known")).count()
negative_n = txns.filter("amount < 0").count()
dirty_channel_n = txns.filter(F.col("channel") != F.upper(F.trim(F.col("channel")))).count()
empty_category_n = txns.filter((F.col("merchant_category") == "") | F.col("merchant_category").isNull()).count()

defects = [("duplicate txn_id", dup_n), ("orphan account_id", orphan_n), ("negative amount", negative_n),
           ("dirty channel", dirty_channel_n), ("empty merchant_category", empty_category_n)]
print(f"{'defect':<26}{'rows':>10}{'pct of feed':>14}")
for name, n in defects:
    print(f"{name:<26}{n:>10,}{n / total * 100:>13.2f}%")


# ====================================================================
step(3, "A small, copyable data quality rule table")
# ====================================================================

# Each rule is: a name, and a SQL condition that GOOD rows must satisfy.
# Add a bank rule here by adding one line, nothing else changes.
RULES = [
    ("no_negative_amount", "amount >= 0"),
    ("account_is_known", "account_known"),
    ("channel_is_clean", "channel = upper(trim(channel))"),
    ("category_not_empty", "merchant_category IS NOT NULL AND merchant_category != ''"),
    ("status_is_valid", "status IN ('SUCCESS', 'FAILED', 'PENDING')"),
]
for name, condition in RULES:
    print(f"  {name:<22} {condition}")


# ====================================================================
step(4, "Run every rule in one pass, write dq_results")
# ====================================================================

# One aggregate expression per rule, all evaluated in the SAME scan of the
# data. That is "one pass": Spark reads tagged once, not once per rule.
fail_exprs = [F.sum(F.when(~F.expr(cond), 1).otherwise(0)).alias(name) for name, cond in RULES]
totals = tagged.agg(F.count("*").alias("total_rows"), *fail_exprs).first()

FAIL_THRESHOLD_PCT = 1.0     # a rule failing on more than 1% of rows blocks the job
rows = []
for name, condition in RULES:
    fail_count = totals[name]
    fail_pct = round(fail_count / totals["total_rows"] * 100, 3)
    rows.append((name, condition, fail_count, totals["total_rows"], fail_pct,
                 "FAIL" if fail_pct > FAIL_THRESHOLD_PCT else "PASS"))

dq_results = spark.createDataFrame(
    rows, ["rule_name", "condition", "fail_count", "total_rows", "fail_pct", "verdict"])
dq_results.write.mode("overwrite").parquet(f"{WAREHOUSE}/dq_results")
dq_results.select("rule_name", "fail_count", "fail_pct", "verdict").show(truncate=False)
any_failed = dq_results.filter("verdict = 'FAIL'").count() > 0
print("any rule over threshold?", any_failed)


# ====================================================================
step(5, "Reconcile bronze against silver")
# ====================================================================

bronze_path = f"{WAREHOUSE}/bronze/transactions"
if os.path.isdir(bronze_path):
    bronze = spark.read.parquet(bronze_path)                       # the real bronze layer from Lab 04
else:
    print("NOTE: data/warehouse/bronze not found. Run labs/04_lab_lakehouse.py first "
          "for the real bronze layer. Using the raw feed as bronze here instead.")
    bronze = txns

bronze_n = bronze.count()
deduped = bronze.dropDuplicates(["txn_id"])
duplicates_removed = bronze_n - deduped.count()

# Rebuild silver and quarantine with the SAME rule this lab already checked
# in step 4, so every deduped row lands in exactly one of the two.
clean = deduped.join(known_accounts, "account_id", "left").fillna({"account_known": False})
silver_here = clean.filter("amount >= 0 AND account_known")
quarantine_here = clean.filter("amount < 0 OR NOT account_known")

silver_n, quarantine_n = silver_here.count(), quarantine_here.count()
tie = (bronze_n - duplicates_removed) == (silver_n + quarantine_n)
print(f"bronze rows: {bronze_n:,}  duplicates removed: {duplicates_removed:,}")
print(f"silver rows: {silver_n:,}  quarantine rows: {quarantine_n:,}")
print(f"bronze - duplicates == silver + quarantine ? -> {tie}")

spark.stop()
print("\nLab 08 done. Output written to data/warehouse/dq_results/")
