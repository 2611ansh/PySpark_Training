"""Lab 01: Python essentials for Spark.

Run it:  ./run.sh labs/01_lab_python.py

This lab is PURE PYTHON. No Spark, no SparkSession. Spark's DataFrame API
is just Python objects and methods, so the Python underneath has to be solid
first.

What you will see:
  1. Variables, lists and dicts, a quick recap
  2. List comprehension, with the for-loop version next to it
  3. Functions: arguments, defaults, return, *args and **kwargs
  4. A class: attributes, __init__, self
  5. Instance, class and static methods
  6. The four OOP concepts, one tiny banking example each
  7. Modules and packages: importing from bankutils
  8. Logging instead of print
"""
import logging
import sys

# `bankutils` is a folder next to this file with an __init__.py in it.
# That is all it takes to make a folder a package.
from bankutils import formatting
from bankutils.rules import risk_band


# ====================================================================
print("\nSTEP 1: Variables, lists, dicts")
# ====================================================================

# A variable. Python does not need a declared type.
branch_name = "Mumbai Main Branch"

# A list: an ordered, changeable collection.
amounts = [1200.0, -50.0, 999.5, 30000.0, 15.75]
print("amounts:", amounts)
print("first amount:", amounts[0])
print("last amount:", amounts[-1])

# A dict: key to value, like a one-row lookup table.
account = {"account_id": "ACC9000001", "balance": 79760.71, "status": "ACTIVE"}
print("account dict:", account)
print("balance:", account["balance"])


# ====================================================================
print("\nSTEP 2: List comprehension")
# ====================================================================

# The for-loop way: build an empty list, then append to it.
positive_forloop = []
for a in amounts:
    if a > 0:
        positive_forloop.append(a)
print("positive (for loop):", positive_forloop)

# The same result as one list comprehension: [expression for item in list if condition]
positive_comp = [a for a in amounts if a > 0]
print("positive (comprehension):", positive_comp)

# A comprehension can also transform each item, not just filter it.
doubled = [a * 2 for a in positive_comp]
print("doubled:", doubled)


# ====================================================================
print("\nSTEP 3: Functions, then *args and **kwargs")
# ====================================================================

def apply_interest(balance, rate=0.03):
    """rate has a default, so most calls only pass balance."""
    return round(balance * (1 + rate), 2)

print("default rate:", apply_interest(10000))
print("custom rate :", apply_interest(10000, rate=0.05))

def total_of(*amounts_in):
    """*args collects any number of positional arguments into a tuple."""
    return sum(amounts_in)

print("total_of(100, 200, 300):", total_of(100, 200, 300))

def open_account(**details):
    """**kwargs collects any number of named arguments into a dict."""
    return f"opening {details['account_type']} account for {details['customer']}"

print(open_account(customer="Priya Rao", account_type="SAVINGS"))


# ====================================================================
print("\nSTEP 4: A class")
# ====================================================================

class Account:
    """__init__ runs when Account(...) is called. self is this one instance."""

    def __init__(self, account_id, balance):
        self.account_id = account_id   # an attribute, stored on this instance
        self.balance = balance

    def deposit(self, amount):         # an instance method, takes self
        self.balance += amount

acc = Account("ACC1001", 5000.0)
acc.deposit(1500.0)
print("account:", acc.account_id, "balance:", acc.balance)


# ====================================================================
print("\nSTEP 5: Instance, class and static methods")
# ====================================================================

class SavingsAccount(Account):
    bank_name = "AtliQ Bank"           # a class attribute, shared by every instance

    def __init__(self, account_id, balance, rate):
        super().__init__(account_id, balance)   # let Account set up the basics
        self.rate = rate

    def add_interest(self):            # instance method: needs one specific account
        self.balance = round(self.balance * (1 + self.rate), 2)

    @classmethod
    def with_default_rate(cls, account_id, balance):   # cls is the class, not one instance
        return cls(account_id, balance, rate=0.035)

    @staticmethod
    def is_valid_rate(rate):           # no self, no cls, just a helper that belongs here
        return 0 <= rate <= 0.10

sav = SavingsAccount.with_default_rate("ACC1002", 20000.0)   # built via the classmethod
sav.add_interest()
print("savings balance after interest:", sav.balance)
print("is 0.20 a valid rate?", SavingsAccount.is_valid_rate(0.20))


# ====================================================================
print("\nSTEP 6: The four OOP concepts, one banking example each")
# ====================================================================

# Encapsulation: the balance is only changed through deposit(), never set directly.
# That means every deposit can be checked in one place.
class GuardedAccount:
    def __init__(self, balance):
        self._balance = balance        # the underscore signals "internal, don't touch"

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("deposit must be positive")
        self._balance += amount

# Inheritance: SavingsAccount above reused Account's __init__ and deposit for free.
print("inheritance: SavingsAccount already has deposit():", hasattr(sav, "deposit"))

# Polymorphism: the same method name, different behaviour per class.
class CurrentAccount(Account):
    def add_interest(self):            # current accounts earn no interest
        pass

for a in [sav, CurrentAccount("ACC1003", 8000.0)]:
    a.add_interest()                   # same call, correct behaviour for each type
    print(type(a).__name__, "balance:", a.balance)

# Abstraction: callers only need apply_interest()/deposit(). How the number is
# calculated inside is hidden from them, which is exactly what a function or a
# method does for you.
print("abstraction: caller just calls apply_interest(), the formula stays inside it")


# ====================================================================
print("\nSTEP 7: Modules and packages")
# ====================================================================

# formatting.py and rules.py are MODULES. The bankutils folder that holds them,
# with an __init__.py, is a PACKAGE. Both are imported at the top of this file.
print(formatting.as_rupees(125000))
print(formatting.as_rupees(sav.balance))
print("loan 65 days past due ->", risk_band(65))
print("loan 0 days past due  ->", risk_band(0))


# ====================================================================
print("\nSTEP 8: Logging")
# ====================================================================

# print() cannot be turned off, has no severity level, and has no timestamp.
# logging gives you all three, which matters once code runs unattended.
logging.basicConfig(
    level=logging.INFO,                                  # show INFO and above
    format="%(asctime)s %(levelname)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("lab01")

log.debug("this is DEBUG, hidden because level is INFO")
log.info("account %s opened with balance %s", acc.account_id, acc.balance)
log.warning("balance %.2f is below the minimum for %s", 100.0, "ACC9099")

print("\nLab 01 done. No files written, this lab is pure Python.")
