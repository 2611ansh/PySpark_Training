"""Lab 12: Polyglot persistence and file formats.

Run it:  ./run.sh labs/12_lab_file_formats.py

What you will see:
  1. Write the same rows as CSV, JSON and Parquet, compare size and time
  2. Look inside the Parquet file: row groups, columns, footer stats
  3. Predicate pushdown, proven in explain()
  4. Column pruning, proven in explain()
  5. The JDBC warning: never point Spark straight at the core banking database
"""
import glob
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pyarrow.parquet as pq                        # reads a Parquet footer directly, no Spark needed
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, TimestampType,
)

from bank_session import get_spark, step, RAW, WAREHOUSE

spark = get_spark("lab-12-file-formats")
SCRATCH = f"{WAREHOUSE}/_scratch_lab12"

txn_schema = StructType([
    StructField("txn_id", StringType()),
    StructField("account_id", StringType()),
    StructField("txn_ts", TimestampType()),
    StructField("amount", DoubleType()),
    StructField("currency", StringType()),
    StructField("channel", StringType()),
    StructField("merchant_category", StringType()),
    StructField("txn_type", StringType()),
    StructField("counterparty_account", StringType()),
    StructField("status", StringType()),
    StructField("device_id", StringType()),
    StructField("city", StringType()),
])

# One day's file is plenty to compare formats, no need for all 3 days.
txns = (spark.read.option("header", True).schema(txn_schema)
        .csv(f"{RAW}/transactions/dt=2026-09-01.csv")
        .limit(20000)
        .cache())
print("rows used for this lab:", txns.count())


# ====================================================================
step(1, "Same rows, three formats: compare size and write time")
# ====================================================================

# Written out one format at a time, on purpose: three short, obvious blocks
# read easier live than one clever loop over format names.
csv_path = f"{SCRATCH}/csv"
t0 = time.perf_counter()
txns.write.mode("overwrite").csv(csv_path, header=True)
csv_secs = time.perf_counter() - t0
csv_mb = sum(os.path.getsize(f) for f in glob.glob(f"{csv_path}/*") if os.path.isfile(f)) / 1024 / 1024

json_path = f"{SCRATCH}/json"
t0 = time.perf_counter()
txns.write.mode("overwrite").json(json_path)
json_secs = time.perf_counter() - t0
json_mb = sum(os.path.getsize(f) for f in glob.glob(f"{json_path}/*") if os.path.isfile(f)) / 1024 / 1024

parquet_path = f"{SCRATCH}/parquet"
t0 = time.perf_counter()
txns.write.mode("overwrite").parquet(parquet_path)
parquet_secs = time.perf_counter() - t0
parquet_mb = sum(os.path.getsize(f) for f in glob.glob(f"{parquet_path}/*") if os.path.isfile(f)) / 1024 / 1024

print(f"CSV     : {csv_mb:6.2f} MB written in {csv_secs:5.2f}s")
print(f"JSON    : {json_mb:6.2f} MB written in {json_secs:5.2f}s")
print(f"PARQUET : {parquet_mb:6.2f} MB written in {parquet_secs:5.2f}s")
print("\nParquet is columnar and compressed by default, CSV and JSON are row")
print("formats with no compression. That is the whole reason for the gap above.")

# ====================================================================
step(2, "Look inside the Parquet file: row groups, columns, footer stats")
# ====================================================================

one_file = glob.glob(f"{parquet_path}/*.parquet")[0]   # pick any one part file
meta = pq.ParquetFile(one_file).metadata
print("row groups :", meta.num_row_groups)
print("columns    :", meta.num_columns)
print("rows       :", meta.num_rows)

amount_col = meta.row_group(0).column(3)             # column index 3 is "amount" in our schema
stats = amount_col.statistics
print(f"\ncolumn 'amount', row group 0: min={stats.min:.2f}  max={stats.max:.2f}")
print("that min/max is what lets a filtered query skip a whole row group unread.")

# ====================================================================
step(3, "Predicate pushdown, proven in explain()")
# ====================================================================

parquet_txns = spark.read.parquet(parquet_path)
filtered = parquet_txns.filter(F.col("status") == "SUCCESS")
plan = filtered._jdf.queryExecution().executedPlan().toString()
print("PushedFilters appears in the plan:", "PushedFilters" in plan)
print("EqualTo(status,SUCCESS) appears in the plan:", "EqualTo(status,SUCCESS)" in plan)
print("\nThe filter travelled INTO the file scan, so Spark's Parquet reader,")
print("not a later Spark stage, is the thing deciding which rows to skip.")

# ====================================================================
step(4, "Column pruning, proven in explain()")
# ====================================================================

narrow = parquet_txns.select("txn_id", "amount")
plan_narrow = narrow._jdf.queryExecution().executedPlan().toString()
print("device_id mentioned in the narrow plan:", "device_id" in plan_narrow)
print("city mentioned in the narrow plan     :", "city" in plan_narrow)
print("\nColumns never selected are never even listed in the physical plan,")
print("Parquet's column chunks for them are never opened on disk.")

# ====================================================================
step(5, "The JDBC warning: read from a replica, never the live core")
# ====================================================================

print("""
This section is NOT runnable here: there is no database server in this
sandbox. On a real cluster it looks like this:

    spark.read.format("jdbc") \\
        .option("url", "jdbc:postgresql://core-banking-REPLICA:5432/ledger") \\
        .option("dbtable", "(SELECT txn_id, amount FROM transactions "
                            "WHERE txn_ts >= '2026-09-01') t") \\
        .option("numPartitions", "8") \\
        .option("fetchsize", "10000") \\
        .load()

A core banking database is sized for a steady stream of small online
transactions, not for Spark opening 8, 16 or 32 parallel connections and
scanning a whole table. Always read from a REPLICA, agree numPartitions and
fetchsize with the DBA who owns it, and push a filtering subquery into
dbtable instead of pulling everything and filtering inside Spark.
""")

txns.unpersist()
spark.stop()
print("\nLab 12 done. Scratch files written to data/warehouse/_scratch_lab12/")
