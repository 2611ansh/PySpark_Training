"""One place that builds the SparkSession for every lab.

Every lab file starts the same way:

    from bank_session import get_spark, RAW, WAREHOUSE, step
    spark = get_spark("lab-03")

Why one file? In a real team nobody configures Spark inside a pipeline
script. Config lives in one module, so changing a setting means changing it
once, not in eighteen places.
"""

import os
import sys
from pathlib import Path

from pyspark.sql import SparkSession

# ---------------------------------------------------------------- paths
# Worked out from this file, so the labs run from any folder.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
RAW = str(PROJECT_ROOT / "data" / "raw")                 # source CSV files
WAREHOUSE = str(PROJECT_ROOT / "data" / "warehouse")     # everything we write
STREAM_IN = str(PROJECT_ROOT / "data" / "stream_in")     # streaming source
STREAM_CKPT = str(PROJECT_ROOT / "data" / "stream_ckpt")  # streaming checkpoint

# Versions used by the optional Delta and Iceberg labs (module 11).
DELTA_VERSION = "3.1.0"
ICEBERG_VERSION = "1.5.2"


def get_spark(app_name="bank-lab", shuffle_partitions=8, aqe=True,
              delta=False, iceberg=False, extra=None):
    """Build the SparkSession.

    app_name            shows in the Spark UI, use the lab name
    shuffle_partitions  Spark's default is 200, far too many on a laptop
    aqe                 Adaptive Query Execution, turned off in one tuning demo
    delta / iceberg     only module 11 sets these, they download a jar once
    extra               extra settings for a single demo
    """
    builder = (
        SparkSession.builder
        .appName(app_name)
        .master("local[*]")                                  # all laptop cores
        .config("spark.sql.shuffle.partitions", shuffle_partitions)
        .config("spark.sql.adaptive.enabled", str(aqe).lower())
        .config("spark.sql.session.timeZone", "Asia/Kolkata")
        .config("spark.sql.warehouse.dir", WAREHOUSE)
        # Hide the [Stage 0:====>] progress bars. They scroll the teaching
        # output off the screen during a live session.
        .config("spark.ui.showConsoleProgress", "false")
    )

    # --- optional table formats, module 11 only -------------------------
    packages = []
    extensions = []

    if delta:
        packages.append(f"io.delta:delta-spark_2.12:{DELTA_VERSION}")
        extensions.append("io.delta.sql.DeltaSparkSessionExtension")
        builder = builder.config(
            "spark.sql.catalog.spark_catalog",
            "org.apache.spark.sql.delta.catalog.DeltaCatalog")

    if iceberg:
        packages.append(
            f"org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:{ICEBERG_VERSION}")
        extensions.append(
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
        # Iceberg tables are addressed as local.<database>.<table>
        builder = (builder
                   .config("spark.sql.catalog.local",
                           "org.apache.iceberg.spark.SparkCatalog")
                   .config("spark.sql.catalog.local.type", "hadoop")
                   .config("spark.sql.catalog.local.warehouse",
                           f"{WAREHOUSE}/iceberg"))

    if packages:
        builder = builder.config("spark.jars.packages", ",".join(packages))
    if extensions:
        builder = builder.config("spark.sql.extensions", ",".join(extensions))

    for key, value in (extra or {}).items():
        builder = builder.config(key, value)

    spark = builder.getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")   # keep the screen readable
    return spark


def step(number, title):
    """Print a clear section header so a live demo is easy to follow."""
    print("\n" + "=" * 70)
    print(f"  STEP {number}  {title}")
    print("=" * 70)


if __name__ == "__main__":
    spark = get_spark("smoke-test")
    step(1, "Environment check")
    print("Spark version :", spark.version)
    print("Python version:", sys.version.split()[0])
    print("Cores in use  :", spark.sparkContext.defaultParallelism)
    print("Raw data      :", RAW)
    print("Warehouse     :", WAREHOUSE)
    spark.range(5).show()
    spark.stop()
    print("\nSpark works. You are ready for Lab 01.")
