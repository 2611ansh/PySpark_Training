#!/usr/bin/env bash
# Runs any lab file. It only sets PYTHONPATH so `import bank_session` works.
#
#   ./run.sh labs/03_lab_dataframes.py
#
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$HERE/src:${PYTHONPATH:-}"
exec python "$@"
