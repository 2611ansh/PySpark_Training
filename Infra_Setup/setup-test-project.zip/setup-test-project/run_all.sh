#!/usr/bin/env bash
# Runs checks 1 to 4 and prints one summary at the end.
# Check 5 (Airflow) is separate because it uses a different virtual env.
#
#   bash run_all.sh

cd "$(dirname "${BASH_SOURCE[0]}")"
PASS=0; FAIL=0

for f in checks/01_environment.py checks/02_spark.py checks/03_delta.py checks/04_iceberg.py; do
  if python "$f"; then
    PASS=$((PASS+1))
  else
    FAIL=$((FAIL+1))
    echo ""
    echo "  >>> $f FAILED. Fix it before running the rest."
    break
  fi
done

echo ""
echo "======================================================"
echo "  SETUP CHECK SUMMARY:  $PASS passed, $FAIL failed"
echo "======================================================"
if [ "$FAIL" -eq 0 ]; then
  echo "  Now run check 5 in the Airflow venv:"
  echo "    source ~/airflow-venv/bin/activate"
  echo "    export AIRFLOW_HOME=~/airflow"
  echo "    python checks/05_airflow.py"
fi
exit $FAIL
