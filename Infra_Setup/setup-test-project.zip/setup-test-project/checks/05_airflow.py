"""Check 5: Apache Airflow.

IMPORTANT: run this from the AIRFLOW virtual environment, not the PySpark
one. Airflow and PySpark pin different versions of the same libraries, so
they must never share a venv.

Run:
    source ~/airflow-venv/bin/activate
    export AIRFLOW_HOME=~/airflow
    python checks/05_airflow.py

Proves: Airflow imports, its database is reachable, and it can parse a DAG.
"""
import os
import sys
from pathlib import Path

print("\n=== CHECK 5: AIRFLOW ===\n")

# ------------------------------------------------- is Airflow importable?
try:
    import airflow
except ImportError:
    print("  [FAIL] Airflow not found")
    print("\n  You are probably in the PySpark venv. Switch to the Airflow one:")
    print("    source ~/airflow-venv/bin/activate")
    sys.exit(1)

print(f"  [PASS] Airflow version         {airflow.__version__}")

# ------------------------------------------------- is PySpark absent?
# If PySpark is importable here, the two venvs got mixed. That breaks both.
try:
    import pyspark                                    # noqa: F401
    print("  [WARN] PySpark is in this venv too. Airflow and PySpark should")
    print("         live in separate virtual environments.")
except ImportError:
    print("  [PASS] PySpark not in this venv (correct)")

# ------------------------------------------------- AIRFLOW_HOME
home = os.environ.get("AIRFLOW_HOME") or str(Path.home() / "airflow")
print(f"  [PASS] AIRFLOW_HOME            {home}")

# ------------------------------------------------- can it parse a DAG?
dags = Path(__file__).resolve().parent.parent / "dags"
from airflow.models import DagBag                      # noqa: E402

bag = DagBag(dag_folder=str(dags), include_examples=False)

if bag.import_errors:
    print(f"  [FAIL] DAG parsing             {len(bag.import_errors)} error(s)")
    for path, err in bag.import_errors.items():
        print(f"         {path}\n         {err.splitlines()[-1]}")
    sys.exit(1)

print(f"  [PASS] DAG parsing             {len(bag.dags)} DAG found")
for dag_id, dag in bag.dags.items():
    print(f"         {dag_id}: {len(dag.tasks)} tasks "
          f"({', '.join(t.task_id for t in dag.tasks)})")

print("\nAirflow works. Your machine is ready for the course.")
