"""Check 4: Apache Iceberg.

Run:  python checks/04_iceberg.py

The FIRST run downloads about 30 MB of Iceberg jars from Maven Central and
caches them in ~/.ivy2. It needs internet and takes 1 to 3 minutes.

Proves: create an Iceberg table, MERGE an update in, and read its snapshots.

Iceberg tables are addressed by NAME, not by path:  local.bank.accounts
  local  = the catalog, a folder on disk here
  bank   = the database
  accounts = the table
"""
import shutil
import sys

from pyspark.sql import SparkSession

WAREHOUSE = "output/check04_iceberg"
print("\n=== CHECK 4: APACHE ICEBERG ===")
print("  first run downloads jars, please wait\n")

shutil.rmtree(WAREHOUSE, ignore_errors=True)

# ---------------------------------------------------------------- start
spark = (SparkSession.builder
         .appName("setup-check-iceberg")
         .master("local[*]")
         .config("spark.sql.shuffle.partitions", 4)
         .config("spark.ui.showConsoleProgress", "false")
         .config("spark.jars.packages",
                 "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.2")
         .config("spark.sql.extensions",
                 "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
         # a catalog named "local", stored as plain folders on disk
         .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
         .config("spark.sql.catalog.local.type", "hadoop")
         .config("spark.sql.catalog.local.warehouse", WAREHOUSE)
         .getOrCreate())
spark.sparkContext.setLogLevel("ERROR")
print(f"  [PASS] Iceberg jar loaded      Spark {spark.version}")

# ---------------------------------------------------------------- create
spark.sql("CREATE DATABASE IF NOT EXISTS local.bank")
spark.sql("""
    CREATE OR REPLACE TABLE local.bank.accounts (
        account_id STRING,
        balance    DOUBLE
    ) USING iceberg
""")
spark.sql("""
    INSERT INTO local.bank.accounts VALUES
        ('ACC001', 52000.0), ('ACC002', 180000.0), ('ACC003', 7400.0)
""")
count = spark.table("local.bank.accounts").count()
print(f"  [PASS] Iceberg table created   {count} rows")

# ---------------------------------------------------------------- merge
spark.createDataFrame(
    [("ACC002", 999999.0), ("ACC009", 4500.0)],
    ["account_id", "balance"]).createOrReplaceTempView("updates")

spark.sql("""
    MERGE INTO local.bank.accounts t
    USING updates s
    ON t.account_id = s.account_id
    WHEN MATCHED     THEN UPDATE SET t.balance = s.balance
    WHEN NOT MATCHED THEN INSERT *
""")
after = spark.table("local.bank.accounts").count()
print(f"  [PASS] MERGE completed         {after} rows after merge")

# ---------------------------------------------------------------- snapshots
# Every write creates a snapshot. This is Iceberg's version history.
snapshots = spark.sql("SELECT snapshot_id, operation FROM local.bank.accounts.snapshots")
n = snapshots.count()
print(f"  [PASS] Snapshots available     {n} snapshots\n")
snapshots.show(truncate=False)

if n < 2:
    print("  [FAIL] Snapshots               expected at least 2")
    spark.stop()
    sys.exit(1)

spark.stop()
print("\nIceberg works. Next: bash checks/05_airflow.sh")
