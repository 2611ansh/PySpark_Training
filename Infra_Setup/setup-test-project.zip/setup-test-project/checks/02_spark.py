"""Check 2: Spark itself.

Run:  python checks/02_spark.py

Starts a real SparkSession, builds a small DataFrame, writes Parquet,
reads it back, and runs a SQL query. If this passes, PySpark works.

Takes about 20 seconds. The first run is slower while the JVM warms up.
"""
import shutil
import sys

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

OUT = "output/check02"
print("\n=== CHECK 2: SPARK ===\n")

# ---------------------------------------------------------------- start
# local[*] means driver and executors all run in one JVM on this laptop.
spark = (SparkSession.builder
         .appName("setup-check-spark")
         .master("local[*]")
         .config("spark.sql.shuffle.partitions", 4)     # 200 is far too many here
         .config("spark.ui.showConsoleProgress", "false")
         .getOrCreate())
spark.sparkContext.setLogLevel("ERROR")

print(f"  [PASS] Spark version           {spark.version}")
print(f"  [PASS] Cores available         {spark.sparkContext.defaultParallelism}")
print(f"  [PASS] Spark UI                http://localhost:4040")

# ---------------------------------------------------------------- build
accounts = spark.createDataFrame(
    [("ACC001", "SAVINGS", 52000.0), ("ACC002", "CURRENT", 180000.0),
     ("ACC003", "SAVINGS", 7400.0), ("ACC004", "SALARY", 96000.0)],
    ["account_id", "account_type", "balance"])
print(f"  [PASS] DataFrame created       {accounts.count()} rows")

# ---------------------------------------------------------------- write
shutil.rmtree(OUT, ignore_errors=True)
accounts.write.mode("overwrite").parquet(OUT)
print(f"  [PASS] Parquet written         {OUT}")

# ---------------------------------------------------------------- read
back = spark.read.parquet(OUT)
if back.count() != accounts.count():
    print("  [FAIL] Parquet read back       row count does not match")
    spark.stop()
    sys.exit(1)
print(f"  [PASS] Parquet read back       {back.count()} rows")

# ---------------------------------------------------------------- sql
back.createOrReplaceTempView("accounts")
result = spark.sql("""
    SELECT account_type, COUNT(*) AS accounts, ROUND(SUM(balance), 2) AS total
    FROM accounts
    GROUP BY account_type
    ORDER BY total DESC
""")
print("  [PASS] SQL query ran\n")
result.show()

# ---------------------------------------------------------------- shuffle
# A groupBy is a wide transformation, so this proves a shuffle works too.
shuffled = back.groupBy("account_type").agg(F.avg("balance").alias("avg_balance"))
print(f"  [PASS] Shuffle completed       {shuffled.count()} groups")

spark.stop()
print("\nSpark works. Next: python checks/03_delta.py")
