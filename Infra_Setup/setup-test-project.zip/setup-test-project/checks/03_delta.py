"""Check 3: Delta Lake.

Run:  python checks/03_delta.py

The FIRST run downloads about 30 MB of Delta jars from Maven Central and
caches them in ~/.ivy2. It needs internet and takes 1 to 3 minutes. Every
run after that is fast.

Proves: create a Delta table, MERGE an update in, and time travel back.
"""
import shutil
import sys

from delta.tables import DeltaTable
from pyspark.sql import SparkSession

OUT = "output/check03_delta"
print("\n=== CHECK 3: DELTA LAKE ===")
print("  first run downloads jars, please wait\n")

# ---------------------------------------------------------------- start
# spark.jars.packages is what pulls the jar. The two extension settings
# teach Spark the Delta SQL syntax and the Delta catalog.
spark = (SparkSession.builder
         .appName("setup-check-delta")
         .master("local[*]")
         .config("spark.sql.shuffle.partitions", 4)
         .config("spark.ui.showConsoleProgress", "false")
         .config("spark.jars.packages", "io.delta:delta-spark_2.12:3.1.0")
         .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
         .config("spark.sql.catalog.spark_catalog",
                 "org.apache.spark.sql.delta.catalog.DeltaCatalog")
         .getOrCreate())
spark.sparkContext.setLogLevel("ERROR")
print(f"  [PASS] Delta jar loaded        Spark {spark.version}")

# ---------------------------------------------------------------- create
shutil.rmtree(OUT, ignore_errors=True)
accounts = spark.createDataFrame(
    [("ACC001", 52000.0), ("ACC002", 180000.0), ("ACC003", 7400.0)],
    ["account_id", "balance"])
accounts.write.format("delta").mode("overwrite").save(OUT)
print(f"  [PASS] Delta table written     {spark.read.format('delta').load(OUT).count()} rows")

# ---------------------------------------------------------------- merge
# One update to an existing account, one brand new account. This is the
# overnight corrections pattern every bank has.
updates = spark.createDataFrame(
    [("ACC002", 999999.0), ("ACC009", 4500.0)],
    ["account_id", "balance"])

table = DeltaTable.forPath(spark, OUT)
(table.alias("t")
 .merge(updates.alias("s"), "t.account_id = s.account_id")
 .whenMatchedUpdate(set={"balance": "s.balance"})
 .whenNotMatchedInsertAll()
 .execute())

after = spark.read.format("delta").load(OUT)
print(f"  [PASS] MERGE completed         {after.count()} rows after merge")

# ---------------------------------------------------------------- history
history = table.history().select("version", "operation")
print(f"  [PASS] History available       {history.count()} versions\n")
history.show(truncate=False)

# ---------------------------------------------------------------- travel
# Version 0 is the state before the merge. The old data is still readable.
v0 = spark.read.format("delta").option("versionAsOf", 0).load(OUT)
print(f"  [PASS] Time travel works       version 0 has {v0.count()} rows, "
      f"latest has {after.count()}")

if v0.count() >= after.count():
    print("  [FAIL] Time travel             version 0 should have fewer rows")
    spark.stop()
    sys.exit(1)

spark.stop()
print("\nDelta Lake works. Next: python checks/04_iceberg.py")
