"""Check 1: the environment, before Spark is involved.

Run:  python checks/01_environment.py

Checks Java, Python, the packages, disk space, and where the project sits.
No SparkSession is started here, so this one runs in about 2 seconds.
"""
import importlib
import os
import platform
import shutil
import subprocess
import sys

PASS, FAIL, WARN = "PASS", "FAIL", "WARN"
results = []


def record(name, status, detail):
    results.append((name, status, detail))
    print(f"  [{status}] {name:24s} {detail}")


print("\n=== CHECK 1: ENVIRONMENT ===\n")

# --- operating system -------------------------------------------------
release = platform.release()
if "microsoft" in release.lower() or "wsl" in release.lower():
    record("WSL2 Linux", PASS, release)
else:
    record("WSL2 Linux", WARN, f"{release}, expected a WSL2 kernel")

# --- java -------------------------------------------------------------
# Spark runs on the JVM. Spark 3.5 supports Java 8, 11 and 17. Java 21
# often starts but is not supported and fails in confusing ways later.
try:
    out = subprocess.run(["java", "-version"], capture_output=True, text=True)
    # java prints its version to stderr, and some setups print extra lines
    # first, so find the line that actually has a quoted version in it.
    lines = (out.stderr + out.stdout).splitlines()
    version = next((ln.split('"')[1] for ln in lines
                    if "version" in ln and '"' in ln), "unknown")
    major = version.split(".")[0]
    if major == "17":
        record("Java 17", PASS, version)
    elif major in ("1", "8", "11"):
        record("Java 17", WARN, f"{version}, works but 17 is what we test on")
    else:
        record("Java 17", FAIL, f"{version}, install openjdk-17-jre-headless")
except FileNotFoundError:
    record("Java 17", FAIL, "java not found, install openjdk-17-jre-headless")

# --- python -----------------------------------------------------------
py = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
if sys.version_info[:2] in [(3, 9), (3, 10), (3, 11), (3, 12)]:
    record("Python 3.9 to 3.12", PASS, py)
else:
    record("Python 3.9 to 3.12", FAIL, f"{py}, PySpark 3.5 does not support this")

# --- inside a virtual environment? -----------------------------------
in_venv = sys.prefix != sys.base_prefix
record("Virtual env active", PASS if in_venv else FAIL,
       sys.prefix if in_venv else "not active, run: source .venv/bin/activate")

# --- packages ---------------------------------------------------------
for module, label in [("pyspark", "pyspark"), ("delta", "delta-spark"),
                      ("pandas", "pandas"), ("pyarrow", "pyarrow")]:
    try:
        m = importlib.import_module(module)
        record(label, PASS, getattr(m, "__version__", "installed"))
    except ImportError:
        record(label, FAIL, f"missing, run: pip install -r requirements.txt")

# --- disk space -------------------------------------------------------
free_gb = shutil.disk_usage(os.path.expanduser("~")).free / 1024 ** 3
record("Free disk space", PASS if free_gb >= 10 else WARN, f"{free_gb:.1f} GB free")

# --- project location -------------------------------------------------
# Files on /mnt/c go through a translation bridge. Spark makes thousands of
# small reads, so a 2 minute job becomes a 20 minute job.
here = os.path.abspath(".")
if here.startswith("/mnt/"):
    record("Project location", FAIL, f"{here}, move it to your Linux home")
else:
    record("Project location", PASS, here)

# --- summary ----------------------------------------------------------
failed = [r for r in results if r[1] == FAIL]
print(f"\n{len(results) - len(failed)} of {len(results)} passed")
if failed:
    print("\nFix these before moving on:")
    for name, _, detail in failed:
        print(f"  - {name}: {detail}")
    sys.exit(1)

print("\nEnvironment is ready. Next: python checks/02_spark.py")
