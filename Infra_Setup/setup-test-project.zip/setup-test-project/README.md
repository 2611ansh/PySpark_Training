# Setup check project

Run this **before** the Spark training. It proves your laptop is ready.

It is not course content. It starts Spark, writes a Delta table, writes an
Iceberg table, and parses an Airflow DAG. Five checks, about 10 minutes.

Follow the setup guide document alongside this. It has the install steps and
a troubleshooting table.

## Quick version

```bash
# 1. PySpark side
cd ~/projects/setup-test-project
python3 -m venv .venv                    # or python3.12 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install --no-cache-dir -r requirements.txt

bash run_all.sh                          # checks 1 to 4

# 2. Airflow side, a SEPARATE virtual environment
deactivate
source ~/airflow-venv/bin/activate
export AIRFLOW_HOME=~/airflow
python checks/05_airflow.py              # check 5
```

## The five checks

| # | File | Proves | Time |
|---|---|---|---|
| 1 | `checks/01_environment.py` | Java, Python, packages, disk, folder location | 2 sec |
| 2 | `checks/02_spark.py` | Spark starts, Parquet round-trip, SQL, shuffle | 20 sec |
| 3 | `checks/03_delta.py` | Delta jar, MERGE, time travel | 1 to 3 min first run |
| 4 | `checks/04_iceberg.py` | Iceberg jar, MERGE, snapshots | 1 to 3 min first run |
| 5 | `checks/05_airflow.py` | Airflow imports and parses a DAG | 10 sec |

Run them in order. Each one tells you what to run next.

## Things to know

| Point | Detail |
|---|---|
| Keep this folder in `~/projects/` | never on `/mnt/c/`, Spark becomes very slow there |
| Checks 3 and 4 need internet on the first run | about 30 MB of jars each, cached in `~/.ivy2` after that |
| Airflow lives in its own virtual environment | it and PySpark pin conflicting library versions |
| `output/` is safe to delete | the checks recreate it |

## What good looks like

```text
======================================================
  SETUP CHECK SUMMARY:  4 passed, 0 failed
======================================================
```

then check 5:

```text
Airflow works. Your machine is ready for the course.
```

## If a check fails

Read the `[FAIL]` line. It names the problem and usually the fix. The setup
guide has a troubleshooting table covering every error we have seen on a
corporate Windows laptop.

Keep this folder after the checks pass. If something breaks mid-course,
rerunning it tells you in one minute whether the problem is your machine or
your code.
