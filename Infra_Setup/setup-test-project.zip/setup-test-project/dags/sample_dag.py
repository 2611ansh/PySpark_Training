"""A tiny DAG, used only by the setup check.

It does nothing useful. Its job is to prove that Airflow can parse a DAG
file on this machine, and that BashOperator can reach your PySpark venv.

Delete this file once the real course starts.
"""
import pendulum
from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="setup_check_dag",
    description="Proves Airflow parses a DAG and can call the PySpark venv",
    schedule=None,                                       # manual only
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    catchup=False,
    tags=["setup-check"],
) as dag:

    hello = BashOperator(
        task_id="hello",
        bash_command="echo 'Airflow can run a shell command'",
    )

    check_python = BashOperator(
        task_id="check_python",
        bash_command="python3 --version",
    )

    hello >> check_python
